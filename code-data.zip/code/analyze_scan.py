#!/usr/bin/env python3
"""Tests S1-S4 of PREREG_ADDENDUM.md on the layer scan (results/scan).  Run aggregate.py first.
Writes results/summary/scan_layers.csv and scan.json."""
import argparse, glob, json, os, sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fieldstats as FS  # noqa: E402
from aggregate import block_boot_spearman  # noqa: E402

TRUTH = ['cities', 'larger_than', 'sp_en_trans']


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='results')
    a = ap.parse_args()
    F = pd.read_csv(f'{a.root}/summary/fields_by_layer.csv')
    rows, repro = [], []
    for f in sorted(glob.glob(f'{a.root}/scan/steer_*.json')):
        if f.endswith('_verify.json'):
            continue
        meta = json.load(open(f))
        m, ds = meta['model'].split('/')[-1], meta['dataset']
        S = np.load(f.replace('.json', '.npz'))
        st = np.load(f'{a.root}/states/{m}_{ds}.npz')
        g, cf = st['groups'], st['Tb'] - st['Ta']
        cfm, cflo, cfhi = FS.group_bootstrap_mean(cf, g, 1000, 0)
        # gate: at the original steering layers the scan must reproduce the earlier steering run
        O = np.load(f'{a.root}/steer/steer_{m}_{ds}.npz')
        Om = json.load(open(f'{a.root}/steer/steer_{m}_{ds}.json'))
        for L in Om['layers']:
            for arm in ['global', 'local']:
                repro.append(float(np.abs(S[f'{L}|{arm}|1.0|T'] - O[f'{L}|{arm}|1.0|T']).max()))
        for L in meta['layers']:
            rec = dict(model=m, dataset=ds, layer=L, cf=cfm, cf_ci0=bool(cflo <= 0 <= cfhi))
            for arm in ['global', 'local']:
                dT = S[f'{L}|{arm}|1.0|T'] - S['T0']
                rec[f'frac_{arm}'] = float(dT.mean() / cfm)
                rec[f'R2_{arm}'] = 1 - float(((dT - cf) ** 2).sum() / ((cf - cf.mean()) ** 2).sum())
                rec[f'klo_{arm}'] = float(S[f'{L}|{arm}|1.0|kl_off'].mean())
            rows.append(rec)
    R = pd.DataFrame(rows).merge(F[['model', 'dataset', 'layer', 'depth', 'rho_glob', 'lam1', 'lam_naive']],
                                 on=['model', 'dataset', 'layer'], how='left')
    R['gain'] = R.frac_local - R.frac_global
    R['dR2'] = R.R2_local - R.R2_global
    R['dklo'] = R.klo_local - R.klo_global
    R.to_csv(f'{a.root}/summary/scan_layers.csv', index=False)
    out = dict(n_layer_cells=int(len(R)), repro_gate_max_abs_T_diff=float(max(repro)) if repro else None)
    # S1 onset
    on = []
    for (m, ds), g in R[R.dataset.isin(TRUTH)].groupby(['model', 'dataset']):
        g = g.sort_values('layer'); nl = int(round(g.layer.iloc[0] / g.depth.iloc[0]))
        Lr = g.layer[g.rho_glob >= 0.5].min(); Ls = g.layer[g.frac_global >= 0.5].min()
        on.append(dict(model=m, dataset=ds, n_layers=nl, L_rho=Lr, L_s=Ls, rho_start=float(g.rho_glob.iloc[0]),
                       d_onset=(Ls - Lr) / nl if np.isfinite(Lr) and np.isfinite(Ls) else np.nan, cf=float(g.cf.iloc[0])))
    O1 = pd.DataFrame(on)
    O1.to_csv(f'{a.root}/summary/scan_onset.csv', index=False)
    out['S1'] = dict(n_cells=int(len(O1)), n_defined=int(O1.d_onset.notna().sum()),
                     median=float(O1.d_onset.median()), min=float(O1.d_onset.min()), max=float(O1.d_onset.max()),
                     frac_abs_le_0_1=float((O1.d_onset.abs() <= 0.1).mean()),
                     max_rho_start=float(O1.rho_start.max()))
    # S2-S4 on leverage-bearing layers
    sel = R[(np.maximum(R.frac_global, R.frac_local) >= 0.5) & ~R.cf_ci0]
    out['n_leverage_cells'] = int(len(sel))
    out['leverage_rho_glob'] = sel.rho_glob.describe().round(3).to_dict()
    out['S2'] = block_boot_spearman(sel, 'rho_glob', 'gain')
    out['S2_median_gain'] = float(sel.gain.median())
    out['S3'] = block_boot_spearman(sel, 'rho_glob', 'dR2')
    out['S3_naive'] = block_boot_spearman(sel, 'lam_naive', 'dR2')
    out['S3_frac_local_better'] = float((sel.dR2 > 0).mean())
    out['S3_median_dR2'] = float(sel.dR2.median())
    out['S4_median_dklo'] = float(sel.dklo.median())
    out['S4_median_klo_global'] = float(sel.klo_global.median())
    json.dump(out, open(f'{a.root}/summary/scan.json', 'w'), indent=1, default=float)
    print(json.dumps(out, indent=1, default=float))
    print(O1.round(3).to_string())


if __name__ == '__main__':
    main()
