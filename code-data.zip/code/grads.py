#!/usr/bin/env python3
"""Readout gradients for PREREG_2.md: g_i^L = dT/dh_L at the readout position of every a-prompt, for every
saved layer L (hidden_states[L] = output of decoder block L-1, the convention of extract.py and steer.py).

The model runs exactly as in extract.py (same prompts, left padding, batch order, float32). The graph starts at
inputs_embeds, so parameters need no gradient. Gate G2: central finite differences along
v = unit(g/|g| + r) with r a random unit vector and step eps = 0.05/|g|, at three layers for the first four
prompts; it must agree with <g, v> to 5% relative error. T is saved for gate G1 (parity with the Marlowe T_a).
Output npz: g (N x nL x d float16, divided by scale), scale (N x nL float32, max |g| per vector), T, order, fd."""
import argparse, json, os, sys, time
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402


class Capture:
    def __init__(self):
        self.out = None

    def __call__(self, module, inp, out):
        h = out[0] if isinstance(out, tuple) else out
        h.retain_grad()
        self.out = h


class AddLast:
    def __init__(self):
        self.vec = None

    def __call__(self, module, inp, out):
        if self.vec is None:
            return out
        h = out[0] if isinstance(out, tuple) else out
        h = h.clone(); h[:, -1, :] += self.vec.to(device=h.device, dtype=h.dtype)
        return (h,) + tuple(out[1:]) if isinstance(out, tuple) else h


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--dataset', required=True)
    ap.add_argument('--data_dir', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--batch', type=int, default=8)
    ap.add_argument('--max_tokens', type=int, default=1024)
    ap.add_argument('--device', default='cuda')
    ap.add_argument('--dtype', default='float32', choices=['float32', 'bfloat16'])
    a = ap.parse_args()
    t0 = time.time()
    beh = C.BEHAVIOUR[a.dataset]
    pairs = C.load_pairs(os.path.join(a.data_dir, f'pairs_{a.dataset}.jsonl'))
    tok, model = C.load_model(a.model, a.device, a.dtype)
    for p in model.parameters():
        p.requires_grad_(False)
    ids = C.target_ids(tok, beh)
    layers = C.decoder_layers(model)
    nL = len(layers) - 1                       # saved layers L = 1..n_layers-1 -> blocks 0..n_layers-2
    caps = [Capture() for _ in range(nL)]
    handles = [layers[j].register_forward_hook(caps[j]) for j in range(nL)]
    emb = model.get_input_embeddings()
    prompts = [C.fmt(tok, beh, p['a']) for p in pairs]
    N = len(prompts); d = model.config.hidden_size
    G = np.zeros((N, nL, d), np.float16); S = np.zeros((N, nL), np.float32); T = np.zeros(N)
    order = np.argsort([len(p) for p in prompts])[::-1]
    for s in range(0, N, a.batch):
        idx = order[s:s + a.batch]
        enc = tok([prompts[i] for i in idx], return_tensors='pt', padding=True, truncation=True,
                  max_length=a.max_tokens).to(model.device)
        x = emb(enc.input_ids).detach().requires_grad_(True)
        out = model(inputs_embeds=x, attention_mask=enc.attention_mask)
        sc = C.target_score(out.logits[:, -1], beh, ids)
        sc.sum().backward()
        for j in range(nL):
            gj = caps[j].out.grad[:, -1, :].float()
            m = gj.abs().amax(-1).clamp(min=1e-30)
            G[idx, j] = (gj / m[:, None]).cpu().numpy().astype(np.float16)
            S[idx, j] = m.cpu().numpy()
        T[idx] = sc.detach().cpu().numpy()
        for c in caps:
            c.out = None
        if (s // a.batch) % 20 == 0:
            print(f'[{time.time() - t0:6.0f}s] {s}/{N}', flush=True)
    for h in handles:
        h.remove()
    # gate G2: finite differences at three layers for the first four prompts
    adder = AddLast()
    fd = []
    rng = np.random.default_rng(0)
    test_layers = sorted({int(round(f * (nL + 1))) for f in (0.25, 0.5, 0.75)})
    with torch.no_grad():
        for L in test_layers:
            h = layers[L - 1].register_forward_hook(adder)
            for i in range(min(4, N)):
                g = torch.tensor(G[i, L - 1].astype(np.float32) * S[i, L - 1], device=model.device)
                r = torch.tensor(rng.standard_normal(d), dtype=torch.float32, device=model.device)
                v = g / g.norm() + r / r.norm(); v = v / v.norm()
                eps = 0.05 / float(g.norm())
                enc = tok([prompts[i]], return_tensors='pt').to(model.device)
                vals = []
                for sgn in (1, -1):
                    adder.vec = sgn * eps * v
                    vals.append(float(C.target_score(model(**enc).logits[:, -1], beh, ids)[0]))
                adder.vec = None
                num = (vals[0] - vals[1]) / 2; ana = eps * float(g @ v)
                fd.append(dict(layer=L, item=i, numeric=num, analytic=ana, rel_err=abs(num - ana) / max(abs(ana), 1e-12)))
            h.remove()
    ok = all(f['rel_err'] <= 0.05 for f in fd)
    os.makedirs(os.path.dirname(a.out) or '.', exist_ok=True)
    np.savez(a.out + '.tmp.npz', g=G, scale=S, T=T, order=order)
    os.replace(a.out + '.tmp.npz', a.out + '.npz')
    meta = dict(model=a.model, dataset=a.dataset, dtype=a.dtype, n=N, nL=nL, d=d, fd=fd, fd_ok=ok, max_fd_rel_err=max(f['rel_err'] for f in fd),
                torch=torch.__version__, seconds=time.time() - t0, device=torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'cpu')
    import transformers
    meta['transformers'] = transformers.__version__
    json.dump(meta, open(a.out + '.tmp.json', 'w'), indent=1)
    os.replace(a.out + '.tmp.json', a.out + '.json')
    print(json.dumps({k: v for k, v in meta.items() if k != 'fd'}), flush=True)
    print('DONE' if ok else 'FD GATE FAILED', flush=True)
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
