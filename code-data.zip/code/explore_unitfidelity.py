#!/usr/bin/env python3
"""Exploratory (not pre-registered; written after the P1-P5 tests were run).

P4 scores the mean behavioural gain, so it cannot see whether an arm reproduces each unit's own counterfactual.
This script scores per-unit fidelity at alpha = 1 for every arm:
  r     = Pearson(dT_i, cf_i) across units,
  R2cf  = 1 - sum (dT_i - cf_i)^2 / sum (cf_i - mean cf)^2  (1 = every unit reproduced, 0 = no better than the mean cf),
plus off-target KL. Steering cells are kept only if the global or local arm moves T by >= 50% of the counterfactual
and the counterfactual's group-bootstrap CI excludes 0 ("sufficient" cells); the cutoff is reported with the result.
Writes results/summary/unit_fidelity.csv and unit_fidelity.json."""
import argparse, glob, json, os, sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fieldstats as FS  # noqa: E402
from aggregate import block_boot_spearman  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='results')
    ap.add_argument('--suff', type=float, default=0.5)
    a = ap.parse_args()
    F = pd.read_csv(f'{a.root}/summary/fields_by_layer.csv')
    rows = []
    for f in sorted(glob.glob(f'{a.root}/steer/steer_*.json')):
        if f.endswith('_verify.json'):
            continue
        meta = json.load(open(f))
        m, ds = meta['model'].split('/')[-1], meta['dataset']
        S = np.load(f.replace('.json', '.npz'))
        st = np.load(f'{a.root}/states/{m}_{ds}.npz')
        g, cf = st['groups'], st['Tb'] - st['Ta']
        cfm, cflo, cfhi = FS.group_bootstrap_mean(cf, g, 1000, 0)
        for L in meta['layers']:
            for arm in meta['arms']:
                key = f'{L}|{arm}|1.0'
                dT = S[f'{key}|T'] - S['T0']
                r = float(np.corrcoef(dT, cf)[0, 1]) if dT.std() > 0 else np.nan
                r2 = 1 - float(((dT - cf) ** 2).sum() / ((cf - cf.mean()) ** 2).sum())
                rows.append(dict(model=m, dataset=ds, layer=L, arm=arm, r=r, R2cf=r2, frac=float(dT.mean() / cfm),
                                 kl_off=float(S[f'{key}|kl_off'].mean()), cf=cfm, cf_ci0=bool(cflo <= 0 <= cfhi),
                                 cf_sd=float(cf.std()), cv_cf=float(cf.std() / abs(cfm))))
    U = pd.DataFrame(rows)
    U = U.merge(F[['model', 'dataset', 'layer', 'rho_glob', 'lam1', 'lam_naive', 'Eu_naive']], on=['model', 'dataset', 'layer'], how='left')
    U.to_csv(f'{a.root}/summary/unit_fidelity.csv', index=False)
    W = U.pivot_table(index=['model', 'dataset', 'layer', 'rho_glob', 'lam1', 'lam_naive', 'Eu_naive', 'cf_ci0', 'cv_cf'], columns='arm',
                      values=['r', 'R2cf', 'frac', 'kl_off']).reset_index()
    W.columns = ['_'.join(c).strip('_') for c in W.columns]
    W['suff'] = (np.maximum(W.frac_global, W.frac_local) >= a.suff) & ~W.cf_ci0
    W['dr'] = W.r_local - W.r_global
    W['dR2'] = W.R2cf_local - W.R2cf_global
    out = dict(suff_cutoff=a.suff, n_cells=int(len(W)), n_sufficient=int(W.suff.sum()))
    sw = W[W.suff]
    out['rho_glob_sufficient'] = sw.rho_glob.describe().round(3).to_dict()
    out['rho_glob_insufficient'] = W[~W.suff].rho_glob.describe().round(3).to_dict()
    for arm in ['global', 'local', 'linprobe', 'mlpgrad', 'random']:
        out[f'median_r_{arm}'] = float(sw[f'r_{arm}'].median())
        out[f'median_R2cf_{arm}'] = float(sw[f'R2cf_{arm}'].median())
        out[f'median_frac_{arm}'] = float(sw[f'frac_{arm}'].median())
        out[f'median_kl_off_{arm}'] = float(sw[f'kl_off_{arm}'].median())
    out['frac_local_r_gt_global'] = float((sw.dr > 0).mean())
    out['spearman_dr_vs_rho'] = block_boot_spearman(sw, 'rho_glob', 'dr')
    out['spearman_dR2_vs_rho'] = block_boot_spearman(sw, 'rho_glob', 'dR2')
    # does the naive (pair-noise-biased) index carry the same information?
    for x in ['lam1', 'lam_naive', 'Eu_naive']:
        out[f'spearman_dr_vs_{x}'] = block_boot_spearman(sw, x, 'dr')
    for x in ['rho_glob', 'lam1', 'lam_naive', 'Eu_naive']:
        out[f'spearman_r_global_vs_{x}'] = block_boot_spearman(sw, x, 'r_global')
    W.to_csv(f'{a.root}/summary/unit_fidelity_wide.csv', index=False)
    json.dump(out, open(f'{a.root}/summary/unit_fidelity.json', 'w'), indent=1, default=float)
    print(json.dumps(out, indent=1, default=float))
    cols = ['model', 'dataset', 'layer', 'rho_glob', 'cv_cf', 'frac_global', 'frac_local', 'r_global', 'r_local',
            'R2cf_global', 'R2cf_local', 'r_linprobe', 'r_mlpgrad', 'kl_off_global', 'kl_off_local']
    print(sw[cols].round(3).to_string())


if __name__ == '__main__':
    main()
