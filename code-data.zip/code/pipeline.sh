#!/bin/bash
# Per-model pipeline, run inside one GPU job: extract -> analyse -> verify -> steer for each
# dataset, then the advbench refusal pairs once data/pairs_advbench.jsonl exists, then the
# generation check.  Each step is skipped only if its final output (written by os.replace at the
# very end of that step) already exists, so a preempted job can be resubmitted safely.
# usage: pipeline.sh <hf model id> <batch>
set -u
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 MKL_NUM_THREADS=8
M=$1; BS=$2; b=$(basename $M)
cd /scratch/m000251/zongminl/cma_rev
mkdir -p results/states results/fields results/steer results/gen
step() { echo "##### $(date +%T) $*"; }
runpy() { "$@" 2>&1 | grep -v -i --line-buffered warn; return ${PIPESTATUS[0]}; }
run_ds() {
  D=$1
  if [ ! -f results/states/${b}_$D.json ]; then
    step extract $D
    runpy $PY -u code/extract.py --model $M --dataset $D --data_dir data --out results/states/${b}_$D --batch $BS || return 1
  fi
  if [ ! -f results/fields/fields_${b}_$D.json ]; then
    step analyse $D
    runpy $PY -u code/analyze_fields.py --states results/states/${b}_$D --out results/fields/fields_${b}_$D --threads 8 || return 1
  fi
  if [ ! -f results/steer/steer_${b}_${D}_verify.json ]; then
    step verify $D
    runpy $PY -u code/steer.py --model $M --dataset $D --data_dir data --fields results/fields/fields_${b}_$D --out results/steer/steer_${b}_$D --verify || return 1
  fi
  if [ ! -f results/steer/steer_${b}_$D.json ]; then
    step steer $D
    runpy $PY -u code/steer.py --model $M --dataset $D --data_dir data --fields results/fields/fields_${b}_$D --out results/steer/steer_${b}_$D --batch $BS || return 1
  fi
}
for D in cities larger_than sp_en_trans cad; do run_ds $D || echo "FAILED $D"; done
for i in $(seq 120); do [ -f data/pairs_advbench.jsonl ] && break; sleep 30; done
if [ -f data/pairs_advbench.jsonl ]; then
  run_ds advbench || echo "FAILED advbench"
  if [ ! -f results/gen/gen_${b}.json ]; then
    step gen_check
    runpy $PY -u code/gen_check.py --model $M --data_dir data --fields results/fields/fields_${b}_advbench --out results/gen/gen_${b} || echo "FAILED gen"
  fi
else
  echo "NO ADVBENCH PAIRS"
fi
step PIPELINE_DONE $b
