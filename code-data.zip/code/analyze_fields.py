#!/usr/bin/env python3
"""Paired-field analysis of one (model, dataset) state file produced by extract.py.

Per layer L:
  regime indices   rho_glob, lam1 (noise-robust, k = 8/16/32), naive lambda_max(E uu^T), ||E u||,
                   permutation null of rho_glob (k = 16)
  held-out field reproduction (group-disjoint 5-fold cross-fitting): for each test pair the
                   score <c_hat, d_i> of a unit predictor c_hat, which is unbiased for <c_hat, V(h_i)>
                   because d_i's pair noise is independent of the training fold.  Predictors:
                   global mean field, local kNN field (k by inner CV), linear-probe direction,
                   MLP-probe gradient at h_i (steering-vector-field style), random.
At the three pre-specified steering layers (relative depth 1/4, 1/2, 3/4) the out-of-fold unit
directions are saved for steer.py, together with support diagnostics (MLE intrinsic dimension,
local tangent stability, held-out chart-transition error, tangent fraction of the local field).
"""
import argparse, json, os, sys, time
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fieldstats as FS  # noqa: E402

K_INDEX = [8, 16, 32]
K_MAIN = 16
K_GRID = [4, 8, 16, 32, 64]
N_PERM = 200
N_FOLDS = 5
ARMS = ['global', 'local', 'linprobe', 'mlpgrad', 'random']


def unit(X):
    return X / np.maximum(np.linalg.norm(X, axis=-1, keepdims=True), 1e-12)


def local_field(Ztr, Dtr, Zte, k):
    nb = FS.knn_indices(Zte, Ztr, k)
    return Dtr[nb].mean(1)


def choose_k(Z, Dm, groups, seed):
    """Inner group-disjoint CV inside a training fold: k maximising mean <unit(local), d>."""
    inner = FS.group_folds(groups, 4, seed)
    sc = {k: [] for k in K_GRID}
    for f in range(4):
        tr, te = inner != f, inner == f
        if te.sum() == 0 or tr.sum() <= max(K_GRID):
            continue
        for k in K_GRID:
            L = unit(local_field(Z[tr], Dm[tr], Z[te], k))
            sc[k].append((L * Dm[te]).sum(1))
    means = {k: float(np.concatenate(v).mean()) for k, v in sc.items() if v}
    return max(means, key=means.get), means


def standardise(Xtr):
    """Centre and divide by one global RMS scale.  An isotropic scale keeps the Euclidean geometry
    of the residual stream, so the probe gradient is the raw-space gradient a steering-vector-field
    method would use (per-dimension standardisation would reweight massive-activation dimensions)."""
    mu = Xtr.mean(0)
    sd = np.full(Xtr.shape[1], np.sqrt(((Xtr - mu) ** 2).sum(1).mean() / Xtr.shape[1]))
    return mu, sd


def linprobe(Xa, Xb, l2=1e-2):
    X = np.r_[Xa, Xb]; y = np.r_[np.zeros(len(Xa)), np.ones(len(Xb))]
    mu, sd = standardise(X)
    w = FS.fit_logistic((X - mu) / sd, y, l2=l2)
    return w[:-1] / sd                                            # gradient w.r.t. raw state


def mlp_grad(Xa, Xb, Q, seed, hidden=256, epochs=300):
    """Train a 1-hidden-layer MLP concept scorer on a-vs-b states; return d logit / d h at Q."""
    torch.manual_seed(seed)
    X = np.r_[Xa, Xb].astype(np.float32); y = np.r_[np.zeros(len(Xa)), np.ones(len(Xb))].astype(np.float32)
    mu, sd = standardise(X)
    Xs = torch.tensor((X - mu) / sd); yt = torch.tensor(y)
    rng = np.random.default_rng(seed)
    perm = rng.permutation(len(X)); nv = max(1, len(X) // 10)
    va, tr = perm[:nv], perm[nv:]
    net = torch.nn.Sequential(torch.nn.Linear(X.shape[1], hidden), torch.nn.GELU(), torch.nn.Linear(hidden, 1))
    opt = torch.optim.AdamW(net.parameters(), lr=1e-3, weight_decay=1e-2)
    lossf = torch.nn.BCEWithLogitsLoss()
    best, best_state, bad = 1e9, None, 0
    for ep in range(epochs):
        net.train(); opt.zero_grad()
        loss = lossf(net(Xs[tr]).squeeze(1), yt[tr]); loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            vl = float(lossf(net(Xs[va]).squeeze(1), yt[va]))
        if vl < best - 1e-4:
            best, bad = vl, 0
            best_state = {k: v.clone() for k, v in net.state_dict().items()}
        else:
            bad += 1
            if bad > 30:
                break
    net.load_state_dict(best_state)
    q = torch.tensor(((Q - mu) / sd).astype(np.float32), requires_grad=True)
    net(q).sum().backward()
    with torch.no_grad():
        acc = float(((net(Xs[va]).squeeze(1) > 0).float() == yt[va]).float().mean())
    return q.grad.numpy() / sd, dict(val_loss=best, val_acc=acc, epochs=ep + 1)


def mle_dim(Z, k):
    nb = FS.knn_indices(Z, Z, k, exclude_self=True)
    d = np.linalg.norm(Z[nb] - Z[:, None, :], axis=2)
    d = np.maximum(d, 1e-12)
    inv = (np.log(d[:, -1:] / d[:, :-1])).mean(1)
    return float(1.0 / np.mean(inv)) if np.all(np.isfinite(inv)) else float('nan')   # MacKay-Ghahramani pooling


def tangent_stability(Z, m, k, n_q=200, seed=0):
    rng = np.random.default_rng(seed)
    q = rng.choice(len(Z), min(n_q, len(Z)), replace=False)
    out = []
    for kk in (k, 2 * k):
        nb = FS.knn_indices(Z[q], Z, kk)
        P = Z[nb] - Z[nb].mean(1, keepdims=True)
        _, _, Vt = np.linalg.svd(P, full_matrices=False)
        out.append(Vt[:, :m, :])
    C = np.einsum('qmd,qnd->qmn', out[0], out[1])
    s = np.linalg.svd(C, compute_uv=False)
    return float(np.sqrt(np.clip(1 - s.min(1) ** 2, 0, 1)).mean()), q, out[0]


def chart_transitions(Z, m, n_charts=16, seed=0):
    rng = np.random.default_rng(seed)
    cen = [int(rng.integers(len(Z)))]
    dmin = np.linalg.norm(Z - Z[cen[0]], axis=1)
    for _ in range(n_charts - 1):
        c = int(np.argmax(dmin)); cen.append(c)
        dmin = np.minimum(dmin, np.linalg.norm(Z - Z[c], axis=1))
    Dc = np.linalg.norm(Z[:, None, :] - Z[cen][None, :, :], axis=2)
    two = np.argsort(Dc, 1)[:, :2]                                # each point belongs to its 2 nearest charts
    basis = {}
    for i in range(n_charts):
        P = Z[(two == i).any(1)]
        if len(P) < 3 * m:
            continue
        mu = P.mean(0); _, _, Vt = np.linalg.svd(P - mu, full_matrices=False)
        basis[i] = (mu, Vt[:m].T)
    errs = []
    for i in basis:
        for j in basis:
            if j <= i:
                continue
            idx = np.nonzero(((two[:, 0] == i) & (two[:, 1] == j)) | ((two[:, 0] == j) & (two[:, 1] == i)))[0]
            if len(idx) < 4 * (m + 1):
                continue
            rng.shuffle(idx); a, b = idx[: len(idx) // 2], idx[len(idx) // 2:]
            xi = (Z - basis[i][0]) @ basis[i][1]; xj = (Z - basis[j][0]) @ basis[j][1]
            W = np.linalg.lstsq(np.c_[xi[a], np.ones(len(a))], xj[a], rcond=None)[0]
            pj = np.c_[xi[b], np.ones(len(b))] @ W
            sd = np.sqrt(((xj[b] - xj[b].mean(0)) ** 2).sum(1).mean())
            errs.append(float(np.sqrt(((pj - xj[b]) ** 2).sum(1).mean()) / sd))
    return (float(np.median(errs)) if errs else float('nan')), len(errs)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--states', required=True, help='path prefix of extract.py output')
    ap.add_argument('--out', required=True)
    ap.add_argument('--threads', type=int, default=16)
    a = ap.parse_args()
    torch.set_num_threads(a.threads)
    t0 = time.time()
    meta = json.load(open(a.states + '.json'))
    S = np.load(a.states + '.npz')
    Ha, Hb, groups = S['Ha'], S['Hb'], S['groups']
    N, nL, d = Ha.shape
    n_layers = nL + 1
    steer_layers = sorted({int(round(f * n_layers)) for f in (0.25, 0.5, 0.75)})
    folds = FS.group_folds(groups, N_FOLDS, seed=0)
    rng = np.random.default_rng(0)
    per_layer = []
    saved = {}
    for j in range(nL):
        L = j + 1
        H = Ha[:, j].astype(np.float32); Hbj = Hb[:, j].astype(np.float32)
        Dm = (Hbj - H).astype(np.float64)
        Z, _ = FS.center_cosine_feats(H.astype(np.float64))
        row = dict(layer=L, depth=L / n_layers, mean_norm_d=float(np.linalg.norm(Dm, axis=1).mean()),
                   mean_norm_h=float(np.linalg.norm(H, axis=1).mean()))
        for k in K_INDEX:
            ri = FS.regime_indices(Z, Dm, k, feats=Z)
            for key, v in ri.items():
                row[f'{key}_k{k}'] = v
        # excess neighbour coherence Delta = u_knn - u_all >= 0 under smooth state dependence; its
        # permutation null (displacements shuffled across pre-states) has mean zero.  The ratio
        # rho_glob is descriptive; its null is ill-conditioned when ||E V|| is small.
        # robustness: neighbours restricted to other near-duplicate families, so that noise shared
        # within a family cannot masquerade as locality
        nx = FS.knn_indices_other_groups(Z, groups, K_MAIN)
        ukx = FS.u_knn(Dm, nx)
        row['u_knn_xg'] = ukx
        row['rho_glob_xg'] = row[f'u_all_k{K_MAIN}'] / ukx if ukx > 0 else float('nan')
        row['lam1_xg'] = FS.lam1_lowrank(Dm, nx)[0] if d > 512 else FS.lam1_from_M(FS.m_knn(Dm, nx))
        nbr = FS.knn_indices(Z, Z, K_MAIN, exclude_self=True)
        delta = row[f'u_knn_k{K_MAIN}'] - row[f'u_all_k{K_MAIN}']
        prng = np.random.default_rng(L)
        null = np.array([FS.u_knn(Dm[p], nbr) for p in (prng.permutation(N) for _ in range(N_PERM))]) - row[f'u_all_k{K_MAIN}']
        row.update(delta_loc=float(delta), delta_null_sd=float(null.std()),
                   delta_z=float(delta / max(null.std(), 1e-30)),
                   delta_perm_p=float((1 + (null >= delta).sum()) / (1 + N_PERM)))
        # cross-fitted reproduction
        is_steer = L in steer_layers
        arms = ARMS if is_steer else ['global', 'local', 'linprobe', 'random']
        dirs = {arm: np.zeros((N, d), np.float32) for arm in arms}
        kchosen, probe_diag = [], []
        for f in range(N_FOLDS):
            tr, te = folds != f, folds == f
            g = Dm[tr].mean(0)
            dirs['global'][te] = unit(g)[None, :]
            k, _ = choose_k(Z[tr], Dm[tr], groups[tr], seed=f)
            kchosen.append(k)
            dirs['local'][te] = unit(local_field(Z[tr], Dm[tr], Z[te], k))
            dirs['linprobe'][te] = unit(linprobe(H[tr], Hbj[tr]))[None, :]
            r = rng.standard_normal((te.sum(), d)); gu = unit(g)
            r -= (r @ gu)[:, None] * gu[None, :]
            dirs['random'][te] = unit(r)
            if 'mlpgrad' in arms:
                gr, diag = mlp_grad(H[tr], Hbj[tr], H[te], seed=1000 * L + f)
                dirs['mlpgrad'][te] = unit(gr); probe_diag.append(diag)
        for arm in arms:
            sc = (dirs[arm].astype(np.float64) * Dm).sum(1)
            row[f'repro_{arm}'] = float(sc.mean())
            row[f'cos_{arm}'] = float((sc / np.maximum(np.linalg.norm(Dm, axis=1), 1e-12)).mean())
        diff = (dirs['local'].astype(np.float64) * Dm).sum(1) - (dirs['global'].astype(np.float64) * Dm).sum(1)
        m_, lo, hi = FS.group_bootstrap_mean(diff, groups, 1000, seed=L)
        row.update(repro_local_minus_global=m_, repro_lmg_lo=lo, repro_lmg_hi=hi, k_local=kchosen)
        if 'mlpgrad' in arms:
            diff2 = (dirs['local'].astype(np.float64) * Dm).sum(1) - (dirs['mlpgrad'].astype(np.float64) * Dm).sum(1)
            m2, lo2, hi2 = FS.group_bootstrap_mean(diff2, groups, 1000, seed=L + 7)
            row.update(repro_local_minus_mlp=m2, repro_lmm_lo=lo2, repro_lmm_hi=hi2, mlp_diag=probe_diag)
            # support diagnostics on pooled a/b states
            Zab, _ = FS.center_cosine_feats(np.r_[H, Hbj].astype(np.float64))
            dims = {k: mle_dim(Zab, k) for k in (10, 20, 40)}
            m = int(max(1, min(50, round(dims[20]))))
            stab, q, B = tangent_stability(Zab, m, 40)
            ct, nct = chart_transitions(Zab, m)
            # tangent fraction of the local field at the a-states (tangent basis of the pooled support)
            Za = Zab[:N]
            nbq = FS.knn_indices(Za[:200], Zab, 40)
            P = Zab[nbq] - Zab[nbq].mean(1, keepdims=True)
            _, _, Vt = np.linalg.svd(P, full_matrices=False)
            Lf = unit(dirs['local'][:200].astype(np.float64))
            # the field lives in raw space; push it through the centre-and-normalise map to first
            # order (tangent of the unit sphere at z) before projecting on the support tangent
            fr = []
            for i in range(len(Lf)):
                vf = Lf[i] - (Za[i] @ Lf[i]) * Za[i]
                fr.append(np.sum((Vt[i, :m] @ vf) ** 2) / max(vf @ vf, 1e-12))
            frac = float(np.mean(fr))
            row.update(mle_dim=dims, tangent_m=m, tangent_instability=stab, chart_nrmse=ct, n_chart_overlaps=nct,
                       local_field_tangent_frac=frac, random_tangent_frac=m / (d - 1))
            saved[L] = {arm: dirs[arm].astype(np.float16) for arm in arms}
            saved[L]['nu'] = np.array([np.median(np.linalg.norm(Dm[folds != f], axis=1)) for f in range(N_FOLDS)])
        per_layer.append(row)
        print(f'[{time.time() - t0:6.0f}s] L={L} rho={row[f"rho_glob_k{K_MAIN}"]:.3f} '
              f'lam1={row[f"lam1_k{K_MAIN}"]:.3f} naive={row[f"lam_naive_k{K_MAIN}"]:.3f} '
              f'rep g/l/lp={row["repro_global"]:.2f}/{row["repro_local"]:.2f}/{row["repro_linprobe"]:.2f}', flush=True)
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    res = dict(meta=meta, steer_layers=steer_layers, n_folds=N_FOLDS, k_index=K_INDEX, k_main=K_MAIN,
               k_grid=K_GRID, n_perm=N_PERM, layers=per_layer, seconds=time.time() - t0)
    json.dump(res, open(a.out + '.tmp.json', 'w'))
    os.replace(a.out + '.tmp.json', a.out + '.json')
    flat = {f'L{L}_{arm}': v for L, dd in saved.items() for arm, v in dd.items()}
    np.savez(a.out + '_dirs.tmp.npz', folds=folds, **flat)
    os.replace(a.out + '_dirs.tmp.npz', a.out + '_dirs.npz')
    print('DONE', time.time() - t0, flush=True)


if __name__ == '__main__':
    main()
