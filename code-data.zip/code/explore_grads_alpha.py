#!/usr/bin/env python3
"""Exploratory (after P6 failed its within-cell linearity criterion): is the weak per-unit first-order fit of the
global arm (median r = 0.23 at alpha = 1) a saturation effect? At the three original steering layers, on the cells where
steering reaches >= 50% of cf, compute the within-cell Pearson r(<g_i, s_i>, dT_i) for alpha = 0.5, 1, 2 and every arm,
and the ratio of the observed to the first-order mean effect. Writes results/summary/grads_alpha.csv."""
import argparse, glob, json, os
import numpy as np
import pandas as pd

ARMS = ['global', 'local', 'linprobe', 'mlpgrad', 'random']


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='results')
    a = ap.parse_args()
    W = pd.read_csv(f'{a.root}/summary/unit_fidelity_wide.csv')
    suff = set(map(tuple, W[W.suff][['model', 'dataset', 'layer']].values.tolist()))
    rows = []
    for gf in sorted(glob.glob(f'{a.root}/grads/grads_*.json')):
        meta = json.load(open(gf)); m, ds = meta['model'].split('/')[-1], meta['dataset']
        Gz = np.load(gf.replace('.json', '.npz')); g_all, sc_all = Gz['g'], Gz['scale']
        st = np.load(f'{a.root}/states/{m}_{ds}.npz'); cfm = (st['Tb'] - st['Ta']).mean()
        Fz = np.load(f'{a.root}/fields/fields_{m}_{ds}_dirs.npz'); Fs = np.load(f'{a.root}/steer/steer_{m}_{ds}.npz')
        Fm = json.load(open(f'{a.root}/steer/steer_{m}_{ds}.json'))
        for L in Fm['layers']:
            if (m, ds, L) not in suff:
                continue
            g = g_all[:, L - 1].astype(np.float64) * sc_all[:, L - 1][:, None]
            for arm in ARMS:
                u = Fz[f'L{L}_{arm}'].astype(np.float64) * Fz[f'L{L}_nu'][Fz['folds']][:, None]
                p1 = (g * u).sum(1)
                for al in Fm['alphas']:
                    dT = Fs[f'{L}|{arm}|{al}|T'] - Fs['T0']
                    p = al * p1
                    r = float(np.corrcoef(p, dT)[0, 1]) if p.std() > 0 and dT.std() > 0 else np.nan
                    rows.append(dict(model=m, dataset=ds, layer=L, arm=arm, alpha=al, r=r,
                                     obs_over_pred=float(dT.mean() / p.mean()) if abs(p.mean()) > 1e-9 else np.nan,
                                     frac_obs=float(dT.mean() / cfm), frac_pred=float(p.mean() / cfm)))
    R = pd.DataFrame(rows)
    R.to_csv(f'{a.root}/summary/grads_alpha.csv', index=False)
    print(R.groupby(['arm', 'alpha']).agg(n=('r', 'size'), median_r=('r', 'median'), median_obs_over_pred=('obs_over_pred', 'median'),
                                         frac_obs=('frac_obs', 'median'), frac_pred=('frac_pred', 'median')).round(3).to_string())


if __name__ == '__main__':
    main()
