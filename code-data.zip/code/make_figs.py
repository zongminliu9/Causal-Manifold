#!/usr/bin/env python3
"""Figures from results/summary (run aggregate.py first).  Print style, light surface."""
import argparse, json, os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

SER = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#6250d6', '#e34948']
GREY = '#8a8984'
INK, INK2 = '#0b0b0b', '#52514e'
ARM_COL = {'global': SER[0], 'local': SER[1], 'linprobe': SER[2], 'mlpgrad': SER[3], 'random': GREY}
ARM_LAB = {'global': 'global paired mean', 'local': 'local paired field', 'linprobe': 'linear-probe direction',
           'mlpgrad': 'MLP-probe gradient', 'random': 'random (orthogonal)'}
plt.rcParams.update({'font.size': 7, 'axes.titlesize': 7.5, 'axes.labelsize': 7, 'xtick.labelsize': 6.5,
                     'ytick.labelsize': 6.5, 'legend.fontsize': 6, 'axes.edgecolor': INK2, 'axes.labelcolor': INK,
                     'xtick.color': INK2, 'ytick.color': INK2, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.linewidth': 0.6, 'lines.linewidth': 1.4, 'font.family': 'DejaVu Sans',
                     'savefig.dpi': 300, 'pdf.fonttype': 42})


def tag(ax, s):
    ax.text(-0.18, 1.06, s, transform=ax.transAxes, fontsize=9, fontweight='bold', color=INK, va='bottom')


def sims_fig(S, out):
    fig, axs = plt.subplots(2, 3, figsize=(7.0, 4.3), constrained_layout=True)
    # A tangent recovery
    ax = axs[0, 0]; t = pd.read_csv(f'{S}/sims_tangent.csv')
    for j, man in enumerate(['circle', 'torus']):
        for sg, ls in [(0.01, '-'), (0.03, '--')]:
            d = t[(t.manifold == man) & (t.sigma == sg)]
            ax.errorbar(d.n, d['mean'], d['sd'], color=SER[j], ls=ls, marker='o', ms=3, capsize=1.5,
                        label=f'{man}, σ={sg}')
    ax.set_xscale('log', base=2); ax.set_xlabel('sample size n'); ax.set_ylabel('tangent-projector error')
    ax.set_title('Support: local-PCA tangents'); ax.legend(frameon=False); tag(ax, 'A')
    # B rotating field
    ax = axs[0, 1]; f = pd.read_csv(f'{S}/sims_field.csv'); f = f[f.n == 2048]
    x = np.arange(len(f)); w = 0.26
    ax.bar(x - w, f.cos_local, w, color=SER[1], label='local paired field')
    ax.bar(x, f.cos_global_abs, w, color=SER[0], label='global mean, |cos|')
    ax.bar(x + w, f.cos_global_signed, w, color=SER[0], alpha=0.45, label='global mean, signed cos')
    ax.set_xticks(x, [f'σ={s}' for s in f.sigma]); ax.set_ylim(-0.05, 1.08); ax.axhline(0, color=INK2, lw=0.5)
    ax.set_ylabel('cosine with true field'); ax.set_title('Causal field: rotating circle field'); ax.legend(frameon=False, loc='center right')
    tag(ax, 'B')
    # C transitions
    ax = axs[0, 2]; tr = pd.read_csv(f'{S}/sims_transition.csv')
    for j, man in enumerate(['circle', 'torus']):
        d = tr[tr.manifold == man]
        ax.errorbar(d.sigma, d.nrmse, d.nrmse_sd, color=SER[j], marker='o', ms=3, capsize=1.5, label=f'{man}: held-out NRMSE')
        ax.plot(d.sigma, d.roundtrip, color=SER[j], ls=':', marker='s', ms=2.5, label=f'{man}: round trip')
    ax.set_xlabel('ambient noise σ'); ax.set_ylabel('normalised error'); ax.set_title('Atlas: chart transitions on overlaps')
    ax.legend(frameon=False); tag(ax, 'C')
    # D radius law
    ax = axs[1, 0]; rr = json.load(open(os.path.join(os.path.dirname(S), 'sims', 'radius_seed_results.json')))
    rad = np.array(rr[0]['radii']); rs = pd.read_csv(f'{S}/sims_radius.csv')
    for j, sg in enumerate([0.0, 0.01]):
        E = np.array([x['err'] for x in rr if x['sigma'] == sg], float); m = np.nanmean(E, 0)
        sl = rs[rs.sigma == sg].slope.iloc[0]
        lbl = f'σ=0 (slope {sl:.2f}, r≤0.4)' if sg == 0 else f'σ={sg} (noise floor)'
        ax.loglog(rad, m, color=SER[j], marker='o', ms=3, label=lbl)
    ax.loglog(rad, 0.15 * rad ** 2, color=INK2, ls='--', lw=0.8, label='∝ r²')
    ax.set_xlabel('chart radius r'); ax.set_ylabel('RMS normal residual'); ax.set_title('Second-order local error')
    ax.legend(frameon=False); tag(ax, 'D')
    # E controls
    ax = axs[1, 1]; c = pd.read_csv(f'{S}/sims_controls.csv')
    lab = {'alternating': 'curved', 'linear': 'linear', 'random': 'random', 'template_iid': 'tmpl.\nIID',
           'template_family': 'tmpl.\nfamily'}
    x = np.arange(len(c)); w = 0.36
    ax.bar(x - w / 2, c.global_mean, w, yerr=c.global_sd, color=SER[0], capsize=1.5, label='global logistic')
    ax.bar(x + w / 2, c.local_mean, w, yerr=c.local_sd, color=SER[1], capsize=1.5, label='local kNN')
    ax.axhline(0.5, color=INK2, lw=0.6, ls=':')
    ax.set_xticks(x, [lab[k] for k in c.control]); ax.set_ylim(0.3, 1.05); ax.set_ylabel('held-out AUROC')
    ax.set_title('Matched controls'); ax.legend(frameon=False, loc='upper center', ncol=2, bbox_to_anchor=(0.5, 1.0)); ax.set_ylim(0.3, 1.15); tag(ax, 'E')
    # F regime indices under pair noise
    ax = axs[1, 2]; ix = pd.read_csv(f'{S}/sims_indices.csv')
    for j, fld in enumerate(['constant', 'mixed_b1', 'rotating']):
        d = ix[ix.field == fld]
        ax.plot(d.pair_noise, d.lam1, color=SER[j], marker='o', ms=3, label=fld)
        ax.plot(d.pair_noise, d.lam_naive, color=SER[j], ls='--', marker='x', ms=3)
        ax.plot(d.pair_noise, d.lam1_true, color=SER[j], ls=':', lw=0.8)
    ax.plot([], [], color=INK2, marker='o', ms=3, label='cross-pair λ₁ (this work)')
    ax.plot([], [], color=INK2, ls='--', marker='x', ms=3, label='naive λ_max(E uuᵀ)')
    ax.set_xscale('symlog', linthresh=0.1); ax.set_xlabel('pair noise s.d. per coordinate'); ax.set_ylabel('one-direction index')
    ax.set_ylim(-0.05, 1.12); ax.set_title('Orientation index under pair noise'); ax.legend(frameon=False, fontsize=5.5, loc='lower left')
    tag(ax, 'F')
    fig.savefig(f'{out}/fig1_simulations.pdf'); fig.savefig(f'{out}/fig1_simulations.png', dpi=200)
    plt.close(fig)


DS_ORDER = ['cad', 'cities', 'larger_than', 'sp_en_trans', 'advbench']
DS_LAB = {'cad': 'sentiment (CAD)', 'cities': 'truth: cities', 'larger_than': 'truth: larger-than',
          'sp_en_trans': 'truth: translation', 'advbench': 'refusal (AdvBench pairs)'}
MODEL_ORDER = ['Qwen2.5-0.5B-Instruct', 'Qwen2.5-1.5B-Instruct', 'Qwen2.5-3B-Instruct', 'Qwen2.5-7B-Instruct',
               'SmolLM2-1.7B-Instruct', 'OLMo-2-0425-1B-Instruct']
MODEL_LAB = {m: m.replace('-Instruct', '').replace('Qwen2.5-', 'Qwen ').replace('-0425', '') for m in MODEL_ORDER}


def fields_fig(S, out):
    F = pd.read_csv(f'{S}/fields_by_layer.csv')
    ds = [d for d in DS_ORDER if d in set(F.dataset)]
    fig, axs = plt.subplots(3, len(ds), figsize=(1.45 * len(ds) + 0.6, 5.3), constrained_layout=True, squeeze=False)
    for c, d in enumerate(ds):
        ax = axs[0, c]
        for j, m in enumerate(MODEL_ORDER):
            g = F[(F.dataset == d) & (F.model == m)].sort_values('depth')
            if len(g):
                ax.plot(g.depth, g.rho_glob, color=SER[j], lw=1.1, label=MODEL_LAB[m])
        ax.set_ylim(-0.05, 1.05); ax.set_title(DS_LAB[d]); ax.set_xlabel('relative depth')
        if c == 0:
            ax.set_ylabel('ρ_glob (constant-vector fraction)'); tag(ax, 'A')
        ax = axs[1, c]
        g = F[F.dataset == d].copy()
        for arm in ['global', 'local', 'linprobe']:
            g[f'n_{arm}'] = g[f'repro_{arm}'] / g.field_rms
        b = pd.cut(g.depth, np.linspace(0, 1, 11))
        agg = g.groupby(b, observed=True)[[f'n_{a}' for a in ['global', 'local', 'linprobe']]].median()
        mid = [iv.mid for iv in agg.index]
        for arm in ['global', 'local', 'linprobe']:
            ax.plot(mid, agg[f'n_{arm}'], color=ARM_COL[arm], marker='o', ms=2.5, label=ARM_LAB[arm])
        st = g[g.steer]
        ax.scatter(st.depth, st.repro_mlpgrad / st.field_rms, s=8, color=ARM_COL['mlpgrad'], zorder=3,
                   label=ARM_LAB['mlpgrad'] + ' (steering layers)')
        ax.axhline(0, color=INK2, lw=0.5); ax.set_xlabel('relative depth'); ax.set_xticks([0, 0.5, 1])
        if c == 0:
            ax.set_ylabel('held-out ⟨ĉ, d⟩ / field RMS'); tag(ax, 'B')
        ax = axs[2, c]
        for j, m in enumerate(MODEL_ORDER):
            g = F[(F.dataset == d) & (F.model == m)]
            ax.scatter(g.lam1, g.lam_naive, s=4, color=SER[j], lw=0)
        ax.plot([0, 1.05], [0, 1.05], color=INK2, lw=0.6, ls=':')
        ax.set_xlim(0, 1.05); ax.set_ylim(0, 1.05); ax.set_xlabel('cross-pair λ₁')
        if c == 0:
            ax.set_ylabel('naive λ_max(E uuᵀ)'); tag(ax, 'C')
    axs[0, -1].legend(frameon=False, loc='center left', bbox_to_anchor=(1.0, 0.5))
    axs[1, -1].legend(frameon=False, loc='center left', bbox_to_anchor=(1.0, 0.5))
    fig.savefig(f'{out}/fig2_fields.pdf'); fig.savefig(f'{out}/fig2_fields.png', dpi=200); plt.close(fig)


def steer_fig(S, out):
    T = pd.read_csv(f'{S}/steering.csv'); T = T[T.alpha == 1.0]
    P = pd.read_csv(f'{S}/steering_alpha1_pivot.csv')
    ds = [d for d in DS_ORDER if d in set(T.dataset)]
    arms = ['global', 'local', 'linprobe', 'mlpgrad', 'random']
    mk = ['o', 's', '^', 'D', 'v']
    fig = plt.figure(figsize=(7.0, 4.9), constrained_layout=True)
    sub = fig.subfigures(2, 1, height_ratios=[1, 1.05])
    top = sub[0].subplots(1, len(ds), sharey=True)
    for c, d in enumerate(ds):
        ax = top[c]; g = T[T.dataset == d]
        for i, p in enumerate(sorted(g.pos.unique())):
            for j, arm in enumerate(arms):
                v = g[(g.pos == p) & (g.arm == arm)].frac_cf
                x = i + (j - 2) * 0.16
                ax.bar(x, v.median(), 0.15, color=ARM_COL[arm], label=ARM_LAB[arm] if (c == 0 and i == 0) else None)
                ax.scatter(np.full(len(v), x), v.clip(-0.5, 1.6), s=3, color=INK, zorder=3, lw=0)
        ax.set_xticks(range(3), ['¼', '½', '¾']); ax.set_xlabel('steering depth'); ax.axhline(0, color=INK2, lw=0.5)
        ax.axhline(1, color=INK2, lw=0.5, ls=':'); ax.set_title(DS_LAB[d]); ax.set_ylim(-0.5, 1.6)
        if c == 0:
            ax.set_ylabel('ΔT / counterfactual (α=1)'); tag(ax, 'A')
    sub[0].legend(*top[0].get_legend_handles_labels(), loc='outside lower center', ncol=5, frameon=False)
    bot = sub[1].subplots(1, 3)
    ax = bot[0]
    for j, d in enumerate(ds):
        g = P[P.dataset == d]
        ax.scatter(g.rho_glob, g.beh_gain.clip(-0.4, 0.4), s=10, marker=mk[j], color=SER[j], label=DS_LAB[d], lw=0)
    ax.axhline(0, color=INK2, lw=0.5); ax.set_xlabel('ρ_glob at the steering layer'); ax.set_ylabel('(local − global) mean ΔT / |cf|')
    ax.set_title('Pre-registered P4: mean gain'); ax.legend(frameon=False, fontsize=5.2); tag(ax, 'B')
    ax = bot[1]
    if os.path.exists(f'{S}/unit_fidelity_wide.csv'):
        W = pd.read_csv(f'{S}/unit_fidelity_wide.csv'); W = W[W.suff]
        for j, d in enumerate(ds):
            g = W[W.dataset == d]
            ax.scatter(g.rho_glob, g.dR2, s=10, marker=mk[j], color=SER[j], lw=0)
        ax.axhline(0, color=INK2, lw=0.5)
    ax.set_xlabel('ρ_glob at the steering layer'); ax.set_ylabel('(local − global) per-unit R²')
    ax.set_title('Exploratory: per-unit fidelity\n(cells reaching ≥50% of cf)'); tag(ax, 'C')
    ax = bot[2]
    if os.path.exists(f'{S}/steering_deep_dose.csv'):
        D = pd.read_csv(f'{S}/steering_deep_dose.csv')
        for arm in arms:
            g = D[D.arm == arm].sort_values('alpha')
            ax.plot(g.kl_off, g.frac_cf, color=ARM_COL[arm], marker='o', ms=3)
            for _, r in (g.iterrows() if arm != 'local' else []):
                ax.annotate(f'{r.alpha:g}', (r.kl_off, r.frac_cf), fontsize=4.8, color=INK2, xytext=(2, -5), textcoords='offset points')
        ax.set_xscale('log')
    ax.set_xlabel('off-target KL (median, ¾ depth)'); ax.set_ylabel('ΔT / counterfactual (median)')
    ax.set_title('Effect vs collateral (labels: α)'); tag(ax, 'D')
    fig.savefig(f'{out}/fig3_steering.pdf'); fig.savefig(f'{out}/fig3_steering.png', dpi=200)
    plt.close(fig)


def gen_fig(S, out):
    G = pd.read_csv(f'{S}/generation.csv')
    G = G[G.run == 'gen2'] if (G.run == 'gen2').any() else G
    FL = pd.read_csv(f'{S}/generation_fluent.csv') if os.path.exists(f'{S}/generation_fluent.csv') else None
    models = [m for m in MODEL_ORDER if m in set(G.model)]
    conds = ['harmless_unsteered', 'global|1.0', 'local|1.0', 'mlpgrad|1.0', 'linprobe|1.0', 'random|1.0',
             'global|2.0', 'local|2.0', 'mlpgrad|2.0', 'linprobe|2.0', 'random|2.0', 'harmful_unsteered']
    poss = [p for p in ['mid', 'deep'] if p in set(G.pos)]
    fig, axs = plt.subplots(len(poss), 1, figsize=(7.0, 1.9 * len(poss) + 0.3), constrained_layout=True, squeeze=False)
    w = 0.8 / len(conds)
    for r, pos in enumerate(poss):
        ax = axs[r, 0]
        for i, m in enumerate(models):
            g = G[(G.model == m) & (G.pos == pos)].set_index('cond')
            for j, cnd in enumerate(conds):
                if cnd not in g.index:
                    continue
                arm = cnd.split('|')[0]
                col = ARM_COL.get(arm, GREY if 'harmless' in cnd else INK)
                alpha = 0.55 if cnd.endswith('|1.0') else 1.0
                x = i + (j - len(conds) / 2) * w
                ax.bar(x, g.loc[cnd, 'refusal'], w * 0.92, color=col, alpha=alpha)
                if FL is not None:
                    fr = FL[(FL.model == m) & (FL.pos == pos) & (FL.cond == cnd)].fluent_refusal
                    if len(fr):
                        ax.scatter(x, fr.iloc[0], s=5, color=INK, zorder=3, lw=0)
        ax.set_xticks(range(len(models)), [MODEL_LAB[m] for m in models]); ax.set_ylabel('refusal rate (100 prompts)')
        ax.set_ylim(0, 1.02)
        ax.set_title('middle steering layer (pre-registered)' if pos == 'mid' else '¾-depth steering layer (post hoc)')
        tag(ax, 'AB'[r])
    from matplotlib.patches import Patch
    h = [Patch(color=GREY, label='harmless, unsteered')] + [Patch(color=ARM_COL[a], label=ARM_LAB[a]) for a in
                                                            ['global', 'local', 'mlpgrad', 'linprobe', 'random']] + \
        [Patch(color=INK, label='harmful, unsteered')]
    h.append(plt.Line2D([], [], color=INK, marker='o', ms=2.5, lw=0, label='rule and not looping'))
    fig.legend(handles=h, frameon=False, ncol=4, loc='outside lower center', fontsize=5.5,
               title='bars: substring-rule refusal (light α=1, dark α=2)', title_fontsize=5.5)
    fig.savefig(f'{out}/fig4_generation.pdf'); fig.savefig(f'{out}/fig4_generation.png', dpi=200); plt.close(fig)


def scan_fig(S, out):
    R = pd.read_csv(f'{S}/scan_layers.csv')
    ds = [d for d in DS_ORDER if d in set(R.dataset)]
    fig, axs = plt.subplots(2, len(ds), figsize=(1.45 * len(ds) + 0.6, 3.7), constrained_layout=True, squeeze=False)
    for c, d in enumerate(ds):
        ax = axs[0, c]
        for j, m in enumerate(MODEL_ORDER):
            g = R[(R.dataset == d) & (R.model == m)].sort_values('depth')
            if len(g):
                ax.plot(g.depth, g.rho_glob, color=SER[j], lw=1.0, label=MODEL_LAB[m])
                ax.plot(g.depth, g.frac_global.clip(-0.2, 1.4), color=SER[j], lw=1.0, ls='--')
        ax.set_ylim(-0.2, 1.4); ax.set_title(DS_LAB[d]); ax.set_xlabel('relative depth'); ax.set_xticks([0, 0.5, 1])
        if c == 0:
            ax.set_ylabel('ρ_glob (—), global ΔT/cf (- -)'); tag(ax, 'A')
        ax = axs[1, c]
        for j, m in enumerate(MODEL_ORDER):
            g = R[(R.dataset == d) & (R.model == m)].sort_values('depth')
            if len(g):
                ax.plot(g.depth, g.gain.clip(-0.4, 0.4), color=SER[j], lw=1.0)
        ax.axhline(0, color=INK2, lw=0.5); ax.set_xlabel('relative depth'); ax.set_xticks([0, 0.5, 1]); ax.set_ylim(-0.4, 0.4)
        if c == 0:
            ax.set_ylabel('(local − global) ΔT / |cf|'); tag(ax, 'B')
    axs[0, -1].legend(frameon=False, loc='center left', bbox_to_anchor=(1.0, 0.5))
    fig.savefig(f'{out}/fig5_layer_scan.pdf'); fig.savefig(f'{out}/fig5_layer_scan.png', dpi=200); plt.close(fig)


def flatness_fig(S, out):
    t = pd.read_csv(f'{S}/sims_flatness.csv'); t = t[t.pair_noise == 0.0]
    fig, axs = plt.subplots(1, 2, figsize=(5.2, 2.2), constrained_layout=True)
    order = [('cyl', 'axial'), ('cyl', 'mixed'), ('cyl', 'rotate'), ('sheet', 'axial'), ('sheet', 'rotate')]
    lab = ['S²×ℝ\naxial', 'S²×ℝ\nmixed', 'S²×ℝ\nrotation', 'slab\naxial', 'slab\nrotation']
    x = np.arange(len(order))
    r = [t[(t.support == a) & (t.field == b)].iloc[0] for a, b in order]
    ax = axs[0]
    ax.bar(x, [q.rho_glob for q in r], 0.6, color=SER[0])
    ax.scatter(x, [q.rho_true for q in r], s=10, color=INK, zorder=3, label='true value')
    ax.set_xticks(x, lab); ax.set_ylim(0, 1.08); ax.set_ylabel('ρ̂_glob (cross-pair)'); ax.legend(frameon=False, loc='upper center')
    ax.set_title('Globality of the causal field'); tag(ax, 'A')
    ax = axs[1]; w = 0.36
    ax.bar(x - w / 2, [q.curv_along_field for q in r], w, color=SER[1], label='along the field')
    ax.bar(x + w / 2, [q.curv_random_tangent for q in r], w, color=GREY, label='random tangent direction')
    ax.set_xticks(x, lab); ax.set_ylabel('normal curvature |II(v, v)| (estimated)')
    ax.set_title('Curvature of the support'); ax.legend(frameon=False, loc='upper left'); tag(ax, 'B')
    fig.savefig(f'{out}/figS_flatness.pdf'); fig.savefig(f'{out}/figS_flatness.png', dpi=200); plt.close(fig)


def grads_fig(S, out):
    D = pd.read_csv(f'{S}/grads_layers.csv'); A = pd.read_csv(f'{S}/grads_arms.csv')
    lev = D[(np.maximum(D.frac_global, D.frac_local) >= 0.5) & ~D.cf_ci0.astype(bool)]
    fig, axs = plt.subplots(1, 4, figsize=(7.0, 2.3), constrained_layout=True)
    mk = {d: m for d, m in zip(DS_ORDER, ['o', 's', '^', 'D', 'v'])}
    for j, d in enumerate(DS_ORDER):
        g = lev[lev.dataset == d]
        axs[0].scatter(g.G_pred, g.G_obs, s=7, marker=mk[d], color=SER[j], lw=0, label=DS_LAB[d])
        axs[1].scatter(g.dR2_pred, g.dR2_obs, s=7, marker=mk[d], color=SER[j], lw=0)
    for ax, lab in [(axs[0], 'Mean gap, local − global'), (axs[1], 'Per-unit ΔR², local − global')]:
        lo, hi = ax.get_xlim(); lo2, hi2 = ax.get_ylim(); a, b = min(lo, lo2), max(hi, hi2)
        ax.plot([a, b], [a, b], color=INK2, lw=0.6, ls=':'); ax.axhline(0, color=INK2, lw=0.4); ax.axvline(0, color=INK2, lw=0.4)
        ax.set_xlabel('first-order prediction'); ax.set_ylabel('observed'); ax.set_title(lab)
    axs[0].legend(frameon=False, fontsize=4.8, loc='upper left'); tag(axs[0], 'A'); tag(axs[1], 'B')
    sa = A[A.suff.fillna(False).astype(bool)]
    ax = axs[2]
    for arm in ['global', 'local', 'linprobe', 'mlpgrad', 'random']:
        ax.scatter(sa[f'pred_{arm}'], sa[f'obs_{arm}'], s=7, color=ARM_COL[arm], lw=0, label=ARM_LAB[arm])
    ax.plot([0, 1.3], [0, 1.3], color=INK2, lw=0.6, ls=':')
    ax.set_xlabel('first-order ⟨g, s⟩ / cf'); ax.set_ylabel('observed ΔT / cf'); ax.set_title('Arms, steering layers')
    ax.legend(frameon=False, fontsize=4.8, loc='upper left'); tag(ax, 'C')
    ax = axs[3]
    arms = ['global', 'local', 'mlpgrad', 'linprobe', 'random']
    ax.boxplot([sa[f'cos_gbar_{a}'] for a in arms], widths=0.5, showfliers=False)
    for i, a in enumerate(arms):
        ax.scatter(np.full(len(sa), i + 1) + np.random.default_rng(i).uniform(-0.15, 0.15, len(sa)), sa[f'cos_gbar_{a}'],
                   s=4, color=ARM_COL[a], lw=0, zorder=3)
    ax.set_xticks(range(1, 6), ['glob.', 'loc.', 'MLP\ngrad', 'lin.\nprobe', 'rand.'])
    ax.set_ylabel('|cos(ḡ, arm direction)|'); ax.set_title('Readout alignment'); tag(ax, 'D')
    fig.savefig(f'{out}/fig_grads.pdf'); fig.savefig(f'{out}/fig_grads.png', dpi=200); plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='results')
    a = ap.parse_args()
    S = f'{a.root}/summary'; out = f'{a.root}/figures'
    os.makedirs(out, exist_ok=True)
    if os.path.exists(f'{S}/sims_indices.csv'):
        sims_fig(S, out)
    if os.path.exists(f'{S}/sims_flatness.csv'):
        flatness_fig(S, out)
    if os.path.exists(f'{S}/fields_by_layer.csv'):
        fields_fig(S, out)
    if os.path.exists(f'{S}/steering_alpha1_pivot.csv'):
        steer_fig(S, out)
    if os.path.exists(f'{S}/generation.csv'):
        gen_fig(S, out)
    if os.path.exists(f'{S}/scan_layers.csv'):
        scan_fig(S, out)
    if os.path.exists(f'{S}/grads_layers.csv') and os.path.exists(f'{S}/grads_arms.csv'):
        grads_fig(S, out)
    print('figures in', out)


if __name__ == '__main__':
    main()
