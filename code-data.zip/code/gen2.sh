#!/bin/bash
# Post-hoc generation check (gen_check.py --pos mid|deep with all texts saved) for every model.
# The mid run repeats the pre-registered one (greedy decoding, so refusal rates must match results/gen/).
set -u
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 MKL_NUM_THREADS=8
cd /scratch/m000251/zongminl/cma_rev
mkdir -p results/gen2
for M in Qwen/Qwen2.5-0.5B-Instruct Qwen/Qwen2.5-1.5B-Instruct Qwen/Qwen2.5-3B-Instruct Qwen/Qwen2.5-7B-Instruct \
         HuggingFaceTB/SmolLM2-1.7B-Instruct allenai/OLMo-2-0425-1B-Instruct; do
  b=$(basename $M)
  for P in deep mid; do
    [ -f results/gen2/gen_${b}_$P.json ] && continue
    echo "##### $(date +%T) gen $b $P"
    $PY -u code/gen_check.py --model $M --data_dir data --fields results/fields/fields_${b}_advbench \
        --out results/gen2/gen_${b}_$P --pos $P 2>&1 | grep -v -i --line-buffered warn || echo "FAILED $b $P"
  done
done
echo "##### $(date +%T) GEN2_DONE"
