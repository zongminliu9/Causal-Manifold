#!/usr/bin/env python3
"""Audit of the refusal substring rule on the saved generations (results/gen2, ¾-depth runs).

Draws a stratified sample (each model × {harmless unsteered, global, MLP-probe gradient, linear probe} at alpha = 1,
two items each, fixed seed) into audit/gen_audit_sample.json. If audit/gen_audit_labels.csv exists (hand labels:
decline / capability / loop), writes the rule's agreement, precision and recall to results/summary/gen_audit.json.
Also writes fluent refusal rates (rule AND not looping, word-level distinct ratio >= 0.3) for every condition to
results/summary/generation_fluent.csv."""
import argparse, glob, json, os
import numpy as np
import pandas as pd

CONDS = ['harmless_unsteered', 'global|1.0', 'mlpgrad|1.0', 'linprobe|1.0']


def looping(t):
    w = t.split()
    return len(w) > 8 and len(set(w)) / len(w) < 0.3


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='results')
    ap.add_argument('--audit', default='audit')
    a = ap.parse_args()
    os.makedirs(a.audit, exist_ok=True)
    rng = np.random.default_rng(20261030)
    rows, fl = [], []
    for f in sorted(glob.glob(f'{a.root}/gen2/gen_*_*.json')):
        g = json.load(open(f)); m = g['model'].split('/')[-1]
        for cond, r in g['results'].items():
            ok = [bool(x) and not looping(t) for t, x in zip(r['texts'], r['per_item'])]
            fl.append(dict(model=m, pos=g['pos'], layer=g['layer'], cond=cond, refusal=r['refusal'],
                           fluent_refusal=float(np.mean(ok)), looping=float(np.mean([looping(t) for t in r['texts']]))))
        if g['pos'] != 'deep':
            continue
        for cond in CONDS:
            r = g['results'][cond]
            for i in rng.choice(len(r['texts']), 2, replace=False):
                rows.append(dict(model=m, cond=cond, item=int(i), rule=bool(r['per_item'][i]), text=r['texts'][i][:200]))
    pd.DataFrame(fl).to_csv(f'{a.root}/summary/generation_fluent.csv', index=False)
    json.dump(rows, open(f'{a.audit}/gen_audit_sample.json', 'w'), indent=1, ensure_ascii=False)
    lab = f'{a.audit}/gen_audit_labels.csv'
    if os.path.exists(lab):
        L = pd.read_csv(lab).sort_values('idx')
        assert len(L) == len(rows)
        rule = np.array([r['rule'] for r in rows]); y = L.decline.values.astype(bool)
        out = dict(n=len(rows), agreement=float((rule == y).mean()), n_decline=int(y.sum()),
                   recall=float((rule & y).sum() / y.sum()), precision=float((rule & y).sum() / rule.sum()),
                   n_capability_declines=int(L.capability.sum()), n_loop=int(L.loop.sum()),
                   disagreements=[dict(idx=int(i), **{k: rows[i][k] for k in ('model', 'cond', 'rule', 'text')})
                                  for i in np.where(rule != y)[0]])
        json.dump(out, open(f'{a.root}/summary/gen_audit.tmp.json', 'w'), indent=1, ensure_ascii=False)
        os.replace(f'{a.root}/summary/gen_audit.tmp.json', f'{a.root}/summary/gen_audit.json')
        print(json.dumps(out, indent=1, ensure_ascii=False))


if __name__ == '__main__':
    main()
