#!/bin/bash
# Layer scan (PREREG_ADDENDUM.md): global and local directions at every layer, steered at alpha = 1.
# usage: scan.sh <hf model id> <batch>.  Resumable: each step is skipped if its final output exists.
set -u
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 MKL_NUM_THREADS=8
M=$1; BS=$2; b=$(basename $M)
cd /scratch/m000251/zongminl/cma_rev
mkdir -p results/scan
step() { echo "##### $(date +%T) $*"; }
runpy() { "$@" 2>&1 | grep -v -i --line-buffered warn; return ${PIPESTATUS[0]}; }
for D in cities larger_than sp_en_trans cad advbench; do
  P=results/scan/scan_${b}_$D
  if [ ! -f $P.json ]; then
    step dirs $D; runpy $PY -u code/scan_dirs.py --states results/states/${b}_$D --out $P || { echo "FAILED dirs $D"; continue; }
  fi
  if [ ! -f results/scan/steer_${b}_${D}_verify.json ]; then
    step verify $D
    runpy $PY -u code/steer.py --model $M --dataset $D --data_dir data --fields $P --out results/scan/steer_${b}_$D --verify --effect_any --alphas 1.0 || { echo "FAILED verify $D"; continue; }
  fi
  if [ ! -f results/scan/steer_${b}_$D.json ]; then
    step steer $D
    runpy $PY -u code/steer.py --model $M --dataset $D --data_dir data --fields $P --out results/scan/steer_${b}_$D --batch $BS --alphas 1.0 || echo "FAILED steer $D"
  fi
done
step SCAN_DONE $b
