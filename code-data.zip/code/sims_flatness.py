#!/usr/bin/env python3
"""Directional flatness (THEORY.md, Theorem C): whether a causal field is global is a different question from
whether the representation is curved.

Supports in R^32 (random orthogonal embedding, ambient noise sigma = 0.01, n = 2048):
  cyl    S^2(1) x [0, 3]: intrinsically curved (sectional curvature 1 on the sphere factor)
  sheet  a flat 3-d slab [-1, 1]^2 x [0, 3]
Fields (tangent):
  axial    0.75 along the [0, 3] factor (constant in ambient space)
  rotate   rotation about the sphere's z axis on cyl; planar rotation about the slab's centre on sheet
  mixed    axial + 0.5 * rotate
For each seed (0-29), field and pair noise (0, 0.3): the cross-pair indices rho_glob and lambda_1 (k = 32, fixed,
as in sims.py), the naive orientation index, cross-fitted held-out reproduction, and the normal curvature along
the field, |II(v, v)| with v the unit tangent part of the field, estimated by a local quadratic fit
(k_c = 96 neighbours, local PCA with m = 3), against a random unit tangent direction at the same points.
Truth: on cyl, |II| = 0 along axial, 1 along rotate, and 2/3 on average for a random tangent direction;
on sheet, |II| = 0 everywhere.  Output: results/sims/flatness_seed_results.json."""
import argparse, json, os, sys, time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fieldstats as FS  # noqa: E402

D_AMB = 32
SEEDS = list(range(30))
N = 2048
SIGMA = 0.01
K_IDX = 32
K_CURV = 96
N_QUERY = 200
PAIR_NOISE = [0.0, 0.3]


def support(kind, n, rng):
    """Points Y (n x 4 intrinsic-ambient coordinates) and tangent fields in those coordinates."""
    z = rng.uniform(0, 3, n)
    if kind == 'cyl':
        p = rng.standard_normal((n, 3)); p /= np.linalg.norm(p, axis=1, keepdims=True)
        Y = np.c_[p, z]
        rot = np.c_[-p[:, 1], p[:, 0], np.zeros(n), np.zeros(n)]
    else:
        xy = rng.uniform(-1, 1, (n, 2))
        Y = np.c_[xy, np.zeros(n), z]
        rot = np.c_[-xy[:, 1], xy[:, 0], np.zeros(n), np.zeros(n)]
    ax = np.tile([0, 0, 0, 0.75], (n, 1))
    return Y, {'axial': ax, 'rotate': rot, 'mixed': ax + 0.5 * rot}


def curvature_along(X, Vq, q_idx, rng):
    """|II(v,v)| for v = unit tangent part of Vq at the query points, and for a random unit tangent direction."""
    nb = FS.knn_indices(X[q_idx], X, K_CURV)
    out_f, out_r = [], []
    for a, i in enumerate(q_idx):
        P = X[nb[a]]; c = P.mean(0)
        _, _, Vt = np.linalg.svd(P - c, full_matrices=False)
        U = Vt[:3].T                                      # D x 3 tangent basis
        Yt = (P - c) @ U                                  # k x 3 tangent coordinates
        Rn = (P - c) - Yt @ U.T                           # k x D normal residuals
        quad = np.stack([Yt[:, 0] ** 2, Yt[:, 1] ** 2, Yt[:, 2] ** 2, 2 * Yt[:, 0] * Yt[:, 1],
                         2 * Yt[:, 0] * Yt[:, 2], 2 * Yt[:, 1] * Yt[:, 2]], 1) / 2
        A = np.c_[np.ones(len(Yt)), Yt, quad]
        coef, *_ = np.linalg.lstsq(A, Rn, rcond=None)     # (1+3+6) x D
        B = coef[4:]                                       # 6 x D: B11 B22 B33 B12 B13 B23
        def II(v):
            w = np.array([v[0] ** 2, v[1] ** 2, v[2] ** 2, 2 * v[0] * v[1], 2 * v[0] * v[2], 2 * v[1] * v[2]])
            return float(np.linalg.norm(w @ B))
        vf = U.T @ Vq[a]
        out_f.append(II(vf / np.linalg.norm(vf)) if np.linalg.norm(vf) > 1e-9 else np.nan)
        vr = rng.standard_normal(3); out_r.append(II(vr / np.linalg.norm(vr)))
    return float(np.nanmean(out_f)), float(np.mean(out_r))


def run_seed(seed):
    rng = np.random.default_rng(seed)
    rows = []
    for kind in ['cyl', 'sheet']:
        Y, fields = support(kind, N, rng)
        Q, _ = np.linalg.qr(rng.standard_normal((D_AMB, 4)))
        X = Y @ Q.T + SIGMA * rng.standard_normal((N, D_AMB))
        q_idx = rng.choice(N, N_QUERY, replace=False)
        folds = np.arange(N) % 5
        for name, F in fields.items():
            V = F @ Q.T
            rho_true = float(V.mean(0) @ V.mean(0) / (V * V).sum(1).mean())
            lam1_true = FS.lam1_from_M(V.T @ V / N)
            curv_f, curv_r = curvature_along(X, V[q_idx], q_idx, rng)
            for sd in PAIR_NOISE:
                Dm = V + sd * rng.standard_normal(V.shape)
                ri = FS.regime_indices(X, Dm, K_IDX)
                sc = {'global': [], 'local': []}
                for f in range(5):
                    trn, tst = folds != f, folds == f
                    g = Dm[trn].mean(0); g /= np.linalg.norm(g)
                    nbr = FS.knn_indices(X[tst], X[trn], K_IDX)
                    Lf = Dm[trn][nbr].mean(1); Lf /= np.linalg.norm(Lf, axis=1, keepdims=True)
                    sc['global'].append(V[tst] @ g); sc['local'].append((Lf * V[tst]).sum(1))
                rows.append(dict(seed=seed, support=kind, field=name, pair_noise=sd, rho_true=rho_true,
                                 lam1_true=lam1_true, curv_along_field=curv_f, curv_random_tangent=curv_r,
                                 repro_true_global=float(np.concatenate(sc['global']).mean()),
                                 repro_true_local=float(np.concatenate(sc['local']).mean()),
                                 field_rms=float(np.sqrt((V * V).sum(1).mean())), **ri))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    t0 = time.time()
    rows = []
    for s in SEEDS:
        rows += run_seed(s)
        print(f'[{time.time() - t0:6.1f}s] seed {s}', flush=True)
    p = f'{a.out}/flatness_seed_results.json'
    json.dump(dict(settings=dict(D_AMB=D_AMB, SEEDS=SEEDS, N=N, SIGMA=SIGMA, K_IDX=K_IDX, K_CURV=K_CURV,
                                 N_QUERY=N_QUERY, PAIR_NOISE=PAIR_NOISE), rows=rows), open(p + '.tmp', 'w'))
    os.replace(p + '.tmp', p)
    print('DONE', time.time() - t0, flush=True)


if __name__ == '__main__':
    main()
