#!/usr/bin/env python3
"""Collect simulation, field, steering and generation outputs into tables and the
pre-registered tests (PREREG.md).  Writes results/summary/{*.csv, summary.json, SUMMARY.md}."""
import argparse, glob, json, os, sys
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fieldstats as FS  # noqa: E402

KM = 16


def field_rows(root):
    rows = []
    for f in sorted(glob.glob(f'{root}/fields/fields_*.json')):
        r = json.load(open(f))
        m, ds = r['meta']['model'].split('/')[-1], r['meta']['dataset']
        for row in r['layers']:
            uk = row[f'u_knn_k{KM}']
            rows.append(dict(model=m, dataset=ds, behaviour=r['meta']['behaviour'], n=r['meta']['n'],
                             layer=row['layer'], depth=row['depth'], steer=row['layer'] in r['steer_layers'],
                             rho_glob=row[f'rho_glob_k{KM}'], rho_glob_k8=row['rho_glob_k8'], rho_glob_k32=row['rho_glob_k32'],
                             rho_glob_xg=row.get('rho_glob_xg', np.nan), lam1_xg=row.get('lam1_xg', np.nan),
                             lam1=row[f'lam1_k{KM}'], lam_naive=row[f'lam_naive_k{KM}'], Eu_naive=row[f'Eu_naive_k{KM}'],
                             delta_z=row['delta_z'], delta_p=row['delta_perm_p'], field_rms=np.sqrt(max(uk, 0)),
                             mean_norm_d=row['mean_norm_d'],
                             repro_global=row['repro_global'], repro_local=row['repro_local'],
                             repro_linprobe=row['repro_linprobe'], repro_mlpgrad=row.get('repro_mlpgrad', np.nan),
                             repro_random=row['repro_random'],
                             lmg=row['repro_local_minus_global'], lmg_lo=row['repro_lmg_lo'], lmg_hi=row['repro_lmg_hi'],
                             gain_norm=row['repro_local_minus_global'] / np.sqrt(max(uk, 1e-30)),
                             mle_dim=(row.get('mle_dim') or {}).get('20', np.nan),
                             tangent_instability=row.get('tangent_instability', np.nan),
                             chart_nrmse=row.get('chart_nrmse', np.nan),
                             tangent_frac=row.get('local_field_tangent_frac', np.nan),
                             random_tangent_frac=row.get('random_tangent_frac', np.nan),
                             mlp_val_acc=np.mean([d['val_acc'] for d in row['mlp_diag']]) if row.get('mlp_diag') else np.nan))
    return pd.DataFrame(rows)


def steer_rows(root):
    rows = []
    for f in sorted(glob.glob(f'{root}/steer/steer_*.json')):
        if f.endswith('_verify.json'):
            continue
        meta = json.load(open(f))
        m, ds = meta['model'].split('/')[-1], meta['dataset']
        S = np.load(f.replace('.json', '.npz'))
        st = np.load(f'{root}/states/{m}_{ds}.npz')
        g, Ta, Tb = st['groups'], st['Ta'], st['Tb']
        cf = Tb - Ta
        T0 = S['T0']
        # the cached unsteered score must reproduce the extraction-time score
        t0_check = float(np.abs(T0 - Ta).max())
        cfm, cflo, cfhi = FS.group_bootstrap_mean(cf, g, 1000, 0)
        for L in meta['layers']:
            for arm in meta['arms']:
                for al in meta['alphas']:
                    key = f'{L}|{arm}|{al}'
                    dT = S[f'{key}|T'] - T0
                    mu, lo, hi = FS.group_bootstrap_mean(dT, g, 1000, 1)
                    rows.append(dict(model=m, dataset=ds, layer=L, arm=arm, alpha=al, dT=mu, dT_lo=lo, dT_hi=hi,
                                     cf=cfm, cf_lo=cflo, cf_hi=cfhi, frac_cf=mu / cfm if cfm != 0 else np.nan,
                                     kl=float(S[f'{key}|kl'].mean()), kl_off=float(S[f'{key}|kl_off'].mean()),
                                     T0_check=t0_check))
    return pd.DataFrame(rows)


def block_boot_spearman(df, x, y, n_boot=2000, seed=0):
    d = df[[x, y, 'model', 'dataset']].dropna()
    if len(d) < 5:
        return dict(rho=np.nan, lo=np.nan, hi=np.nan, n=len(d))
    rho = spearmanr(d[x], d[y]).correlation
    blocks = [b for _, b in d.groupby(['model', 'dataset'])]
    rng = np.random.default_rng(seed)
    bs = []
    for _ in range(n_boot):
        s = pd.concat([blocks[i] for i in rng.integers(0, len(blocks), len(blocks))])
        if s[x].nunique() > 2:
            bs.append(spearmanr(s[x], s[y]).correlation)
    return dict(rho=float(rho), lo=float(np.nanpercentile(bs, 2.5)), hi=float(np.nanpercentile(bs, 97.5)),
                n=int(len(d)), n_blocks=len(blocks))


def sims_tables(root):
    out = {}
    p = f'{root}/sims'
    if not os.path.exists(f'{p}/indices_seed_results.json'):
        return out
    t = pd.DataFrame(json.load(open(f'{p}/tangent_seed_results.json')))
    out['tangent'] = t.groupby(['manifold', 'n', 'sigma']).agg(k=('k', 'first'), mean=('proj_err', 'mean'), sd=('proj_err', 'std')).reset_index()
    tr = pd.DataFrame(json.load(open(f'{p}/transition_seed_results.json')))
    out['transition'] = tr.groupby(['manifold', 'sigma']).agg(nrmse=('nrmse', 'mean'), nrmse_sd=('nrmse', 'std'),
                                                              roundtrip=('roundtrip', 'mean'), overlaps=('n_overlaps', 'mean')).reset_index()
    fd = pd.DataFrame(json.load(open(f'{p}/field_seed_results.json')))
    out['field'] = fd.groupby(['n', 'sigma']).agg(k=('k', 'first'), cos_local=('cos_local', 'mean'), cos_local_sd=('cos_local', 'std'),
                                                  relerr=('relerr_local', 'mean'), leak=('normal_leak', 'mean'),
                                                  cos_global_signed=('cos_global_signed', 'mean'),
                                                  cos_global_abs=('cos_global_abs', 'mean')).reset_index()
    rr = json.load(open(f'{p}/radius_seed_results.json'))
    rad = np.array(rr[0]['radii']); sl = {}
    for sg in sorted({x['sigma'] for x in rr}):
        E = np.array([x['err'] for x in rr if x['sigma'] == sg], float)
        m = np.nanmean(E, 0); ok = np.isfinite(m) & (rad <= 0.4)
        per = [np.polyfit(np.log(rad[ok]), np.log(e[ok]), 1)[0] for e in E if np.all(np.isfinite(e[ok]))]
        sl[sg] = dict(slope=float(np.polyfit(np.log(rad[ok]), np.log(m[ok]), 1)[0]), slope_sd=float(np.std(per)), n_seeds=len(per))
    out['radius'] = pd.DataFrame([dict(sigma=k, **v) for k, v in sl.items()])
    c = json.load(open(f'{p}/controls_seed_results.json'))
    out['controls'] = pd.DataFrame([dict(control=k, global_mean=np.mean([x[k]['global_auroc'] for x in c]),
                                         global_sd=np.std([x[k]['global_auroc'] for x in c]),
                                         local_mean=np.mean([x[k]['local_auroc'] for x in c]),
                                         local_sd=np.std([x[k]['local_auroc'] for x in c]), n_seeds=len(c))
                                    for k in ['alternating', 'linear', 'random', 'template_iid', 'template_family']])
    if os.path.exists(f'{p}/flatness_seed_results.json'):
        fl = pd.DataFrame(json.load(open(f'{p}/flatness_seed_results.json'))['rows'])
        out['flatness'] = fl.groupby(['support', 'field', 'pair_noise']).agg(
            n_seeds=('seed', 'nunique'), rho_true=('rho_true', 'mean'), rho_glob=('rho_glob', 'mean'),
            rho_sd=('rho_glob', 'std'), lam1=('lam1', 'mean'), lam_naive=('lam_naive', 'mean'),
            curv_along_field=('curv_along_field', 'mean'), curv_along_field_sd=('curv_along_field', 'std'),
            curv_random_tangent=('curv_random_tangent', 'mean'), repro_true_global=('repro_true_global', 'mean'),
            repro_true_local=('repro_true_local', 'mean'), field_rms=('field_rms', 'mean')).reset_index()
    ix = pd.DataFrame(json.load(open(f'{p}/indices_seed_results.json')))
    out['indices'] = ix.groupby(['field', 'pair_noise'])[['rho_true', 'rho_glob', 'lam1_true', 'lam1', 'lam_naive', 'Eu_naive',
                                                          'repro_global', 'repro_true_global', 'repro_local', 'repro_true_local',
                                                          'repro_oracle']].mean().reset_index()
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='results')
    a = ap.parse_args()
    out = f'{a.root}/summary'
    os.makedirs(out, exist_ok=True)
    summ = {}
    for name, t in sims_tables(a.root).items():
        t.to_csv(f'{out}/sims_{name}.csv', index=False)
    F = field_rows(a.root)
    S = steer_rows(a.root)
    if len(F):
        F.to_csv(f'{out}/fields_by_layer.csv', index=False)
        summ['P1'] = dict(n_cells=int(len(F)), frac_delta_p_lt_0_05=float((F.delta_p < 0.05).mean()),
                          rho_glob_quantiles=F.rho_glob.quantile([0, .1, .25, .5, .75, .9, 1]).round(3).to_dict())
        summ['P2'] = block_boot_spearman(F, 'rho_glob', 'gain_norm')
        st = F[F.steer]
        summ['P3'] = dict(n_cells=int(len(st)), frac_linprobe_below_global=float((st.repro_linprobe < st.repro_global).mean()),
                          frac_mlpgrad_below_global=float((st.repro_mlpgrad < st.repro_global).mean()),
                          median_ratio_linprobe=float((st.repro_linprobe / st.repro_global).median()),
                          median_ratio_mlpgrad=float((st.repro_mlpgrad / st.repro_global).median()))
    if len(S):
        piv = S[S.alpha == 1.0].pivot_table(index=['model', 'dataset', 'layer'], columns='arm', values='dT').reset_index()
        cfv = S[S.alpha == 1.0].groupby(['model', 'dataset', 'layer']).cf.first().reset_index()
        piv = piv.merge(cfv, on=['model', 'dataset', 'layer'])
        piv['beh_gain'] = (piv['local'] - piv['global']) / piv['cf'].abs()
        if len(F):
            piv = piv.merge(F[['model', 'dataset', 'layer', 'rho_glob', 'lam1']], on=['model', 'dataset', 'layer'], how='left')
            summ['P4'] = block_boot_spearman(piv, 'rho_glob', 'beh_gain')
        rnd = S[(S.arm == 'random') & (S.alpha == 1.0)].merge(S[(S.arm == 'global') & (S.alpha == 1.0)],
                                                               on=['model', 'dataset', 'layer'], suffixes=('_r', '_g'))
        ci0 = (rnd.dT_lo_r <= 0) & (rnd.dT_hi_r >= 0)
        small = rnd.dT_r.abs() * 10 < rnd.dT_g.abs()
        summ['P4_random'] = dict(frac_ci_includes_0=float(ci0.mean()), frac_10x_smaller=float(small.mean()),
                                 n_cells_criterion_met=int((ci0 | small).sum()), n=int(len(rnd)),
                                 cells_failing=rnd[~(ci0 | small)][['model', 'dataset', 'layer', 'frac_cf_r', 'frac_cf_g']]
                                 .round(4).to_dict('records'))
        summ['P5'] = dict(frac_mlpgrad_below_global=float((piv['mlpgrad'] < piv['global']).mean()),
                          frac_linprobe_below_global=float((piv['linprobe'] < piv['global']).mean()), n=int(len(piv)))
        summ['T0_check_max'] = float(S.T0_check.max())
        piv.to_csv(f'{out}/steering_alpha1_pivot.csv', index=False)
        # Exploratory (after the tests above): which steering depth carries behaviour, and the
        # dose / off-target trade-off at the deepest steering layer.
        S['pos'] = S.groupby(['model', 'dataset']).layer.rank(method='dense').astype(int)
        S.to_csv(f'{out}/steering.csv', index=False)
        dep = S[S.alpha == 1.0].groupby(['pos', 'arm']).frac_cf.describe()[['count', '25%', '50%', '75%']]
        dep.reset_index().to_csv(f'{out}/steering_by_depth.csv', index=False)
        summ['depth_median_frac_cf_alpha1'] = {f'{p}|{arm}': float(v) for (p, arm), v in dep['50%'].items()}
        deep = S[S.pos == S.pos.max()].groupby(['arm', 'alpha']).agg(frac_cf=('frac_cf', 'median'),
                                                                       kl_off=('kl_off', 'median')).reset_index()
        deep.to_csv(f'{out}/steering_deep_dose.csv', index=False)
        summ['deep_dose'] = deep.round(4).to_dict('records')
    if len(F):
        summ['naive_vs_crosspair'] = dict(frac_naive_below_lam1=float((F.lam_naive < F.lam1).mean()),
                                          ratio_quantiles=(F.lam_naive / F.lam1).quantile([.05, .25, .5, .75, .95]).round(3).to_dict(),
                                          xg_minus_rho_quantiles=(F.rho_glob_xg - F.rho_glob).quantile([.05, .5, .95]).round(3).to_dict(),
                                          k8_vs_k32_abs_diff_median=float((F.rho_glob_k32 - F.rho_glob_k8).abs().median()))
        F['ident'] = 1 - np.sqrt(F.rho_glob.clip(lower=0))
        summ['P2_identity_check'] = dict(spearman_gain_norm_vs_1_minus_sqrt_rho=float(spearmanr(F.gain_norm, F.ident).correlation),
                                         residual_quantiles=(F.gain_norm - F.ident).quantile([.05, .5, .95]).round(3).to_dict())
    # Generation: results/gen is the pre-registered middle-layer run (rates only); results/gen2 repeats it
    # with every text saved and adds the deepest steering layer.  Greedy decoding, so mid rates must match.
    gens = []
    for sub, pat in [('gen', 'gen_*.json'), ('gen2', 'gen_*_*.json')]:
        for f in sorted(glob.glob(f'{a.root}/{sub}/{pat}')):
            g = json.load(open(f))
            for k, v in g['results'].items():
                gens.append(dict(run=sub, model=g['model'].split('/')[-1], pos=g.get('pos', 'mid'), layer=g['layer'],
                                 cond=k, refusal=v['refusal'], degenerate=v['degenerate']))
    if gens:
        G = pd.DataFrame(gens)
        G.to_csv(f'{out}/generation.csv', index=False)
        m = G[G.run == 'gen'].merge(G[(G.run == 'gen2') & (G.pos == 'mid')], on=['model', 'layer', 'cond'], suffixes=('_1', '_2'))
        if len(m):
            summ['gen_mid_rerun_max_abs_diff'] = float((m.refusal_1 - m.refusal_2).abs().max())
            summ['gen_mid_rerun_n'] = int(len(m))
    json.dump(summ, open(f'{out}/summary.json', 'w'), indent=1, default=float)
    print(json.dumps(summ, indent=1, default=float))


if __name__ == '__main__':
    main()
