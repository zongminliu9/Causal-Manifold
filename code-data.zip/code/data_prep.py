#!/usr/bin/env python3
"""Build paired counterfactual datasets.  Each pair (a, b) differs only in the concept:
a = source condition, b = target condition.  The paired displacement is H(b) - H(a).

  cad          sentiment   a = positive review, b = its human minimal edit to negative
                           (Kaushik et al. 2020 counterfactually augmented IMDb, all splits)
  cities       truth       a = true statement, b = same city with the false country
                           (Marks & Tegmark 2023); group = correct country
  larger_than  truth       a = true comparison, b = operands swapped; group = decade of the smaller
                           number (leave-one-decade-out folds)
  sp_en_trans  truth       a = true translation, b = the same Spanish word with another word's
                           translation (fixed seed); group = Spanish word
  advbench     refusal     a = harmless minimal rewrite, b = the AdvBench harmful request
                           (built by gen_refusal_pairs.py, then filtered here)
Groups additionally merge near-duplicate sources (TF-IDF cosine >= 0.5) so that no family is
split across folds.
"""
import json, os, re, sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fieldstats as FS  # noqa: E402

RAW = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'raw')
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')


def write(name, rows, natural_keys=None, tfidf=True):
    texts = [r['a'] for r in rows]
    if tfidf:
        g = FS.tfidf_groups(texts, 0.5, extra_keys=natural_keys)
    else:
        uniq = {k: i for i, k in enumerate(dict.fromkeys(natural_keys))}
        g = np.array([uniq[k] for k in natural_keys])
    for r, gi in zip(rows, g):
        r['group'] = int(gi)
    with open(os.path.join(OUT, f'pairs_{name}.jsonl'), 'w') as f:
        for r in rows:
            f.write(json.dumps(r) + '\n')
    print(name, len(rows), 'pairs', len(set(g)), 'groups')


def cad():
    rows = []
    for split in ['train', 'dev', 'test']:
        d = pd.read_csv(os.path.join(RAW, f'cad_{split}_paired.tsv'), sep='\t')
        for bid, sub in d.groupby('batch_id'):
            if len(sub) != 2 or set(sub.Sentiment) != {'Positive', 'Negative'}:
                continue
            pos = sub[sub.Sentiment == 'Positive'].Text.iloc[0]
            neg = sub[sub.Sentiment == 'Negative'].Text.iloc[0]
            clean = lambda s: re.sub(r'<br\s*/?>', ' ', s).strip()
            rows.append(dict(id=f'cad_{split}_{bid}', a=clean(pos), b=clean(neg), meta=dict(split=split)))
    write('cad', rows)


def cities():
    d = pd.read_csv(os.path.join(RAW, 'got_cities.csv'))
    rows, keys = [], []
    for city, sub in d.groupby('city', sort=False):
        t = sub[sub.label == 1].statement.iloc[0]
        f = sub[sub.label == 0].statement.iloc[0]
        rows.append(dict(id=f'cities_{city}', a=t, b=f, meta=dict(country=sub.correct_country.iloc[0])))
        keys.append(sub.correct_country.iloc[0])
    write('cities', rows, keys, tfidf=False)


def larger_than():
    d = pd.read_csv(os.path.join(RAW, 'got_larger_than.csv'))
    d['lo'] = d[['n1', 'n2']].min(1); d['hi'] = d[['n1', 'n2']].max(1)
    rows, keys = [], []
    for (lo, hi), sub in d.groupby(['lo', 'hi'], sort=True):
        t = sub[sub.label == 1].statement.iloc[0]
        f = sub[sub.label == 0].statement.iloc[0]
        rows.append(dict(id=f'gt_{lo}_{hi}', a=t, b=f, meta=dict(lo=int(lo), hi=int(hi))))
        keys.append(int(lo) // 10)
    write('larger_than', rows, keys, tfidf=False)


def sp_en_trans():
    d = pd.read_csv(os.path.join(RAW, 'got_sp_en_trans.csv'))
    d = d[d.label == 1].copy()
    d['w'] = d.statement.str.extract(r"word '(.+?)' means")
    d['e'] = d.statement.str.extract(r"means '(.+?)'\.")
    d = d.drop_duplicates('w').reset_index(drop=True)
    rng = np.random.default_rng(20261030)
    eng = d.e.tolist()
    rows = []
    for i, r in d.iterrows():
        j = i
        while eng[j] == r.e:
            j = int(rng.integers(len(d)))
        rows.append(dict(id=f'sp_{r.w}', a=r.statement,
                         b=f"The Spanish word '{r.w}' means '{eng[j]}'.", meta=dict(word=r.w)))
    write('sp_en_trans', rows, [r['meta']['word'] for r in rows], tfidf=False)


def advbench(gen_path, sim_min=0.4):
    import difflib
    gen = [json.loads(l) for l in open(gen_path)]
    rows, drop = [], dict(not_harmless=0, not_harmful=0, low_overlap=0, empty=0)
    for g in gen:
        b, a = g['harmful'], g['rewrite'].strip().strip('"').strip()
        if not a:
            drop['empty'] += 1; continue
        sim = difflib.SequenceMatcher(None, b.lower().split(), a.lower().split()).ratio()
        if sim < sim_min:
            drop['low_overlap'] += 1; continue
        if g['harm_score_rewrite'] >= 0:
            drop['not_harmless'] += 1; continue
        if g['harm_score_harmful'] <= 0:
            drop['not_harmful'] += 1; continue
        rows.append(dict(id=f"adv_{g['idx']}", a=a, b=b,
                         meta=dict(word_overlap=sim, harm_b=g['harm_score_harmful'], harm_a=g['harm_score_rewrite'])))
    # near-duplicate families are defined on the harmful source, which AdvBench repeats heavily
    texts = [r['b'] for r in rows]
    g = FS.tfidf_groups(texts, 0.5)
    for r, gi in zip(rows, g):
        r['group'] = int(gi)
    with open(os.path.join(OUT, 'pairs_advbench.jsonl'), 'w') as f:
        for r in rows:
            f.write(json.dumps(r) + '\n')
    print('advbench', len(rows), 'pairs', len(set(g)), 'groups', 'dropped', drop)


if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'base'
    if what == 'base':
        cad(); cities(); larger_than(); sp_en_trans()
    else:
        advbench(what)
