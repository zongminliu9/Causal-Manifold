#!/usr/bin/env python3
"""Ground-truth simulations for the causal manifold atlas (re-implementation, 2026-10).

The original simulation archive is lost, so every number here is produced afresh from
raw seeds.  Neighbourhood sizes are tuned on pilot seeds 1000-1004 and frozen before the
evaluation seeds 0-29 are run.

Blocks
  tangent      local-PCA tangent-projector error, circle and torus in R^32
  transition   held-out affine chart-transition and round-trip error on chart overlaps
  field        paired local recovery of the rotating circle field (speed 0.75 + 0.35 sin 2t)
  radius       local linearisation error versus chart radius (predicted O(r^2))
  controls     alternating / linear / random-label / template-shortcut classification controls
  indices      noise-robust regime indices versus the naive orientation spectrum, and
               cross-fitted reproduction of local versus global fields
Usage: python sims.py --out results/sims   (no other arguments; all settings are below)
"""
import argparse, json, os, sys, time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fieldstats as FS  # noqa: E402

D_AMB = 32
EVAL_SEEDS = list(range(30))
PILOT_SEEDS = list(range(1000, 1005))
NS = [256, 512, 1024, 2048]
SIGMAS = [0.0, 0.01, 0.03]
K_GRID = [8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512, 768]
DELTA = 0.1
N_QUERY = 200


# --------------------------------------------------------------------------- manifolds
def embed(dim, rng):
    Q, _ = np.linalg.qr(rng.standard_normal((D_AMB, dim)))
    return Q


def sample(manifold, n, sigma, rng, Q=None):
    if manifold == 'circle':
        Q = embed(2, rng) if Q is None else Q
        t = rng.uniform(0, 2 * np.pi, n)
        Y = np.c_[np.cos(t), np.sin(t)]
        T = np.c_[-np.sin(t), np.cos(t)][:, :, None]          # n x 2 x 1
        lat = t[:, None]
    else:
        Q = embed(3, rng) if Q is None else Q
        R, r = 2.0, 0.65
        u, v = rng.uniform(0, 2 * np.pi, n), rng.uniform(0, 2 * np.pi, n)
        Y = np.c_[(R + r * np.cos(v)) * np.cos(u), (R + r * np.cos(v)) * np.sin(u), r * np.sin(v)]
        du = np.c_[-np.sin(u), np.cos(u), np.zeros(n)]
        dv = np.c_[-np.sin(v) * np.cos(u), -np.sin(v) * np.sin(u), np.cos(v)]
        T = np.stack([du, dv], 2)                               # orthonormal already
        lat = np.c_[u, v]
    X0 = Y @ Q.T
    Tamb = np.einsum('ij,njk->nik', Q, T)                      # n x D x m
    X = X0 + sigma * rng.standard_normal(X0.shape)
    return X, X0, Tamb, lat, Q


def local_pca(X, nbr, m):
    P = X[nbr]                                                # q x k x D
    P = P - P.mean(1, keepdims=True)
    _, _, Vt = np.linalg.svd(P, full_matrices=False)
    return np.transpose(Vt[:, :m, :], (0, 2, 1))              # q x D x m


def proj_err(Uhat, Utrue):
    """Spectral norm of P_hat - P = sine of the largest principal angle."""
    C = np.einsum('qdm,qdn->qmn', Uhat, Utrue)
    s = np.linalg.svd(C, compute_uv=False)
    return np.sqrt(np.clip(1 - s.min(1) ** 2, 0, 1))


# --------------------------------------------------------------------------- blocks
def tangent_err(manifold, n, sigma, k, seed):
    rng = np.random.default_rng(seed)
    X, X0, Tamb, lat, Q = sample(manifold, n, sigma, rng)
    m = Tamb.shape[2]
    q = rng.choice(n, min(N_QUERY, n), replace=False)
    nbr = FS.knn_indices(X[q], X, k)
    return float(proj_err(local_pca(X, nbr, m), Tamb[q]).mean())


def tune_k(fun, n, *args):
    """k from K_GRID (k <= n/4) minimising the mean pilot-seed error."""
    errs = {k: np.mean([fun(*args, k, s) for s in PILOT_SEEDS]) for k in K_GRID if k <= n // 4}
    return min(errs, key=errs.get), errs


def transition_err(manifold, n, sigma, seed, n_charts):
    rng = np.random.default_rng(seed)
    X, X0, Tamb, lat, Q = sample(manifold, n, sigma, rng)
    m = Tamb.shape[2]
    # farthest point sampling for chart centres
    cen = [int(rng.integers(n))]
    dmin = np.linalg.norm(X - X[cen[0]], axis=1)
    for _ in range(n_charts - 1):
        c = int(np.argmax(dmin)); cen.append(c)
        dmin = np.minimum(dmin, np.linalg.norm(X - X[c], axis=1))
    rad = 1.5 * dmin.max()
    Dc = np.linalg.norm(X[:, None, :] - X[cen][None, :, :], axis=2)
    memb = Dc <= rad
    coords = {}
    for i in range(n_charts):
        Pi = X[memb[:, i]]
        mu = Pi.mean(0)
        _, _, Vt = np.linalg.svd(Pi - mu, full_matrices=False)
        coords[i] = (mu, Vt[:m].T)
    nr, rt = [], []
    for i in range(n_charts):
        for j in range(i + 1, n_charts):
            idx = np.nonzero(memb[:, i] & memb[:, j])[0]
            if len(idx) < 40:
                continue
            rng.shuffle(idx)
            a, b = idx[: len(idx) // 2], idx[len(idx) // 2:]
            xi = (X - coords[i][0]) @ coords[i][1]
            xj = (X - coords[j][0]) @ coords[j][1]
            A1 = np.c_[xi[a], np.ones(len(a))]
            Wij = np.linalg.lstsq(A1, xj[a], rcond=None)[0]
            Wji = np.linalg.lstsq(np.c_[xj[a], np.ones(len(a))], xi[a], rcond=None)[0]
            pj = np.c_[xi[b], np.ones(len(b))] @ Wij
            sd = np.sqrt(((xj[b] - xj[b].mean(0)) ** 2).sum(1).mean())
            nr.append(np.sqrt(((pj - xj[b]) ** 2).sum(1).mean()) / sd)
            back = np.c_[pj, np.ones(len(b))] @ Wji
            sdi = np.sqrt(((xi[b] - xi[b].mean(0)) ** 2).sum(1).mean())
            rt.append(np.sqrt(((back - xi[b]) ** 2).sum(1).mean()) / sdi)
    return float(np.median(nr)), float(np.median(rt)), len(nr)


def speed(t):
    return 0.75 + 0.35 * np.sin(2 * t)


def paired_circle(n, sigma, rng):
    X, X0, Tamb, lat, Q = sample('circle', n, sigma, rng)
    t = lat[:, 0]
    t2 = t + DELTA * speed(t)
    X1 = np.c_[np.cos(t2), np.sin(t2)] @ Q.T + sigma * rng.standard_normal(X.shape)
    Dm = (X1 - X) / DELTA
    Vtrue = speed(t)[:, None] * Tamb[:, :, 0]
    return X, Dm, Vtrue, Tamb


def field_rec(n, sigma, k, seed, k_tan=None):
    rng = np.random.default_rng(seed)
    X, Dm, Vtrue, Tamb = paired_circle(n, sigma, rng)
    q = rng.choice(n, min(N_QUERY, n), replace=False)
    nbr = FS.knn_indices(X[q], X, k)
    Vloc = Dm[nbr].mean(1)
    Ut = local_pca(X, FS.knn_indices(X[q], X, k_tan or k), 1)[:, :, 0]
    leak = np.linalg.norm(Vloc - (Vloc * Ut).sum(1, keepdims=True) * Ut, axis=1) / np.linalg.norm(Vloc, axis=1)
    Vproj = (Vloc * Ut).sum(1, keepdims=True) * Ut
    Vq = Vtrue[q]
    cos = lambda A, B: (A * B).sum(1) / np.linalg.norm(A, axis=1) / np.linalg.norm(B, axis=1)
    g = Dm.mean(0)
    cg = (Vq @ g) / np.linalg.norm(Vq, axis=1) / np.linalg.norm(g)
    return dict(cos_local=float(cos(Vproj, Vq).mean()),
                relerr_local=float((np.linalg.norm(Vproj - Vq, axis=1) / np.linalg.norm(Vq, axis=1)).mean()),
                normal_leak=float(leak.mean()),
                cos_global_signed=float(cg.mean()), cos_global_abs=float(np.abs(cg).mean()))


def field_relerr(n, sigma, k, seed):
    return field_rec(n, sigma, k, seed)['relerr_local']


def radius_law(sigma, seed, radii):
    rng = np.random.default_rng(seed)
    X, X0, Tamb, lat, Q = sample('circle', 20000, sigma, rng)
    base = rng.choice(len(X), 64, replace=False)
    out = []
    for r in radii:
        res = []
        for b in base:
            idx = np.nonzero(np.linalg.norm(X - X[b], axis=1) <= r)[0]
            if len(idx) < 5:
                continue
            P = X[idx] - X[idx].mean(0)
            _, s, Vt = np.linalg.svd(P, full_matrices=False)
            resid = P - (P @ Vt[:1].T) @ Vt[:1]
            res.append(np.sqrt((resid ** 2).sum(1).mean()))
        out.append(float(np.mean(res)))
    return out


def controls(seed):
    rng = np.random.default_rng(seed)
    res = {}
    # (a) alternating labels on a noisy circle: local should win
    X, X0, Tamb, lat, Q = sample('circle', 1024, 0.01, rng)
    y = (np.sin(3 * lat[:, 0]) > 0).astype(int)
    tr, te = np.arange(512), np.arange(512, 1024)
    w = FS.fit_logistic(X[tr], y[tr])
    res['alternating'] = (FS.auroc(FS.predict_logistic(w, X[te]), y[te]),
                          FS.auroc(FS.knn_score(X[tr], y[tr], X[te]), y[te]))
    # (b) linear ground truth on a flat 8-dimensional support: global should win
    Q8 = embed(8, rng)
    z = rng.standard_normal((768, 8))
    X = z @ Q8.T + 0.1 * rng.standard_normal((768, D_AMB))
    y = (z[:, 0] + 0.3 * rng.standard_normal(768) > 0).astype(int)
    tr, te = np.arange(256), np.arange(256, 768)
    w = FS.fit_logistic(X[tr], y[tr])
    res['linear'] = (FS.auroc(FS.predict_logistic(w, X[te]), y[te]),
                     FS.auroc(FS.knn_score(X[tr], y[tr], X[te]), y[te]))
    # (c) random labels: both at chance
    X, X0, Tamb, lat, Q = sample('circle', 1024, 0.01, rng)
    y = rng.integers(0, 2, 1024)
    tr, te = np.arange(512), np.arange(512, 1024)
    w = FS.fit_logistic(X[tr], y[tr])
    res['random'] = (FS.auroc(FS.predict_logistic(w, X[te]), y[te]),
                     FS.auroc(FS.knn_score(X[tr], y[tr], X[te]), y[te]))
    # (d) template shortcut: 40 families, family-level labels
    F, per = 40, 30
    C = rng.standard_normal((F, D_AMB))
    yf = rng.permutation(np.r_[np.zeros(F // 2), np.ones(F // 2)]).astype(int)
    fam = np.repeat(np.arange(F), per)
    X = C[fam] + 0.5 * rng.standard_normal((F * per, D_AMB))
    y = yf[fam]
    perm = rng.permutation(len(X)); tr, te = perm[: len(X) // 2], perm[len(X) // 2:]
    w = FS.fit_logistic(X[tr], y[tr])
    res['template_iid'] = (FS.auroc(FS.predict_logistic(w, X[te]), y[te]),
                           FS.auroc(FS.knn_score(X[tr], y[tr], X[te]), y[te]))
    trf = rng.permutation(F)[: F // 2]
    msk = np.isin(fam, trf); tr, te = np.nonzero(msk)[0], np.nonzero(~msk)[0]
    w = FS.fit_logistic(X[tr], y[tr])
    res['template_family'] = (FS.auroc(FS.predict_logistic(w, X[te]), y[te]),
                              FS.auroc(FS.knn_score(X[tr], y[tr], X[te]), y[te]))
    return {k: dict(global_auroc=float(v[0]), local_auroc=float(v[1])) for k, v in res.items()}


FIELDS = ['constant', 'rotating', 'signflip', 'mixed_b0.5', 'mixed_b1', 'mixed_b2']
PAIR_NOISE = [0.0, 0.1, 0.3, 1.0]


def make_field(name, X, Tamb, lat, rng):
    t = lat[:, 0]
    v0 = rng.standard_normal(D_AMB); v0 /= np.linalg.norm(v0)
    tan = Tamb[:, :, 0]
    if name == 'constant':
        return np.tile(0.75 * v0, (len(X), 1))
    if name == 'rotating':
        return speed(t)[:, None] * tan
    if name == 'signflip':
        return np.cos(t)[:, None] * v0[None, :]
    b = float(name.split('_b')[1])
    return v0[None, :] + b * tan


def index_block(seed, k=32, n=2048):
    rng = np.random.default_rng(seed)
    rows = []
    X, X0, Tamb, lat, Q = sample('circle', n, 0.01, rng)
    folds = np.arange(n) % 5
    for name in FIELDS:
        V = make_field(name, X, Tamb, lat, rng)
        EV = V.mean(0)
        rho_true = float(EV @ EV / (V * V).sum(1).mean())
        lam1_true = FS.lam1_from_M(V.T @ V / n)
        for sd in PAIR_NOISE:
            Dm = V + sd * rng.standard_normal(V.shape)
            ri = FS.regime_indices(X, Dm, k)
            # cross-fitted reproduction: E <c_hat/|c_hat|, d_test>, unbiased for <c_hat/|c_hat|, V_test>
            sc = {'global': [], 'local': [], 'oracle': []}
            truth = {'global': [], 'local': []}
            for f in range(5):
                trn, tst = folds != f, folds == f
                g = Dm[trn].mean(0); g /= np.linalg.norm(g)
                nb = FS.knn_indices(X[tst], X[trn], k)
                L = Dm[trn][nb].mean(1); L /= np.linalg.norm(L, axis=1, keepdims=True)
                sc['global'].append(Dm[tst] @ g); truth['global'].append(V[tst] @ g)
                sc['local'].append((L * Dm[tst]).sum(1)); truth['local'].append((L * V[tst]).sum(1))
                sc['oracle'].append(np.linalg.norm(V[tst], axis=1))
            row = dict(seed=seed, field=name, pair_noise=sd, rho_true=rho_true, lam1_true=lam1_true, **ri)
            for a in sc:
                row['repro_' + a] = float(np.concatenate(sc[a]).mean())
            for a in truth:
                row['repro_true_' + a] = float(np.concatenate(truth[a]).mean())
            rows.append(row)
    return rows


# --------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    t0 = time.time()
    log = lambda *a: print(f'[{time.time() - t0:7.1f}s]', *a, flush=True)
    settings = dict(D_AMB=D_AMB, EVAL_SEEDS=EVAL_SEEDS, PILOT_SEEDS=PILOT_SEEDS, NS=NS, SIGMAS=SIGMAS,
                    K_GRID=K_GRID, DELTA=DELTA, N_QUERY=N_QUERY, FIELDS=FIELDS, PAIR_NOISE=PAIR_NOISE)
    summary = dict(settings=settings)

    # tangent recovery
    rows, ktab = [], {}
    for man in ['circle', 'torus']:
        for n in NS:
            for sg in SIGMAS:
                k, errs = tune_k(tangent_err, n, man, n, sg)
                ktab[f'{man}_{n}_{sg}'] = dict(k=k, pilot_err={str(a): b for a, b in errs.items()})
                for s in EVAL_SEEDS:
                    rows.append(dict(manifold=man, n=n, sigma=sg, k=k, seed=s, proj_err=tangent_err(man, n, sg, k, s)))
            log('tangent', man, n)
    json.dump(rows, open(f'{args.out}/tangent_seed_results.json', 'w'))
    summary['tangent_k'] = ktab

    # transitions
    rows = []
    for man, C in [('circle', 12), ('torus', 96)]:
        for sg in SIGMAS:
            for s in EVAL_SEEDS:
                nr, rt, no = transition_err(man, 2048, sg, s, C)
                rows.append(dict(manifold=man, n=2048, sigma=sg, seed=s, nrmse=nr, roundtrip=rt, n_overlaps=no))
        log('transition', man)
    json.dump(rows, open(f'{args.out}/transition_seed_results.json', 'w'))

    # field recovery
    rows, kf = [], {}
    for n in [512, 2048]:
        for sg in SIGMAS:
            k, errs = tune_k(field_relerr, n, n, sg)
            kt = ktab[f'circle_{n}_{sg}']['k']
            kf[f'{n}_{sg}'] = dict(k=k, pilot_relerr={str(a): b for a, b in errs.items()})
            for s in EVAL_SEEDS:
                rows.append(dict(n=n, sigma=sg, k=k, k_tan=kt, seed=s, **field_rec(n, sg, k, s, kt)))
        log('field', n)
    json.dump(rows, open(f'{args.out}/field_seed_results.json', 'w'))
    summary['field_k'] = kf

    # radius law
    radii = list(np.geomspace(0.05, 0.8, 12))
    rows = []
    for sg in [0.0, 0.01]:
        for s in EVAL_SEEDS[:10]:
            rows.append(dict(sigma=sg, seed=s, radii=radii, err=radius_law(sg, s, radii)))
    json.dump(rows, open(f'{args.out}/radius_seed_results.json', 'w'))
    log('radius')

    # controls
    rows = [dict(seed=s, **controls(s)) for s in EVAL_SEEDS]
    json.dump(rows, open(f'{args.out}/controls_seed_results.json', 'w'))
    log('controls')

    # regime indices
    rows = []
    for s in EVAL_SEEDS:
        rows.extend(index_block(s))
    json.dump(rows, open(f'{args.out}/indices_seed_results.json', 'w'))
    log('indices')
    json.dump(summary, open(f'{args.out}/settings_and_tuning.json', 'w'), indent=1)
    log('DONE')


if __name__ == '__main__':
    main()
