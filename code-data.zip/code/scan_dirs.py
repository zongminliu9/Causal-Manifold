#!/usr/bin/env python3
"""Cross-fitted global and local steering directions at every layer (layer scan, PREREG_ADDENDUM.md).

Uses the same folds, inner-CV choice of k and local-field estimator as analyze_fields.py, so the directions
at the three original steering layers are identical to the ones steered before.  Writes <out>.json (with
steer_layers = all layers, read by steer.py) and <out>_dirs.npz (folds, L{L}_global, L{L}_local, L{L}_nu)."""
import argparse, json, os, sys, time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fieldstats as FS  # noqa: E402
from analyze_fields import N_FOLDS, unit, local_field, choose_k  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--states', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    t0 = time.time()
    meta = json.load(open(a.states + '.json'))
    S = np.load(a.states + '.npz')
    Ha, Hb, groups = S['Ha'], S['Hb'], S['groups']
    N, nL, d = Ha.shape
    folds = FS.group_folds(groups, N_FOLDS, seed=0)
    saved, kch = {}, {}
    for j in range(nL):
        L = j + 1
        H = Ha[:, j].astype(np.float32)
        Dm = (Hb[:, j].astype(np.float32) - H).astype(np.float64)
        Z, _ = FS.center_cosine_feats(H.astype(np.float64))
        g_dir = np.zeros((N, d), np.float32); l_dir = np.zeros((N, d), np.float32); ks = []
        for f in range(N_FOLDS):
            tr, te = folds != f, folds == f
            g_dir[te] = unit(Dm[tr].mean(0))[None, :]
            k, _ = choose_k(Z[tr], Dm[tr], groups[tr], seed=f)
            ks.append(k)
            l_dir[te] = unit(local_field(Z[tr], Dm[tr], Z[te], k))
        saved[f'L{L}_global'] = g_dir.astype(np.float16)
        saved[f'L{L}_local'] = l_dir.astype(np.float16)
        saved[f'L{L}_nu'] = np.array([np.median(np.linalg.norm(Dm[folds != f], axis=1)) for f in range(N_FOLDS)])
        kch[L] = ks
        print(f'[{time.time() - t0:6.0f}s] L={L} k={ks}', flush=True)
    np.savez(a.out + '_dirs.tmp.npz', folds=folds, **saved)
    os.replace(a.out + '_dirs.tmp.npz', a.out + '_dirs.npz')
    json.dump(dict(meta=meta, steer_layers=list(range(1, nL + 1)), k_local=kch, seconds=time.time() - t0),
              open(a.out + '.tmp.json', 'w'), indent=1)
    os.replace(a.out + '.tmp.json', a.out + '.json')
    print('DONE', time.time() - t0, flush=True)


if __name__ == '__main__':
    main()
