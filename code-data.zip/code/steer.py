#!/usr/bin/env python3
"""Behavioural steering with out-of-fold directions from analyze_fields.py.

For every source prompt a_i, steering layer L, arm and strength alpha, the unit direction is
added at layer L at the readout position with norm alpha * nu (nu = median training-fold
paired-displacement norm at L, so alpha = 1 is a typical counterfactual displacement).  We
record the target score T and the next-token KL to the unsteered distribution, split into
target and off-target parts.  The counterfactual effect T(b_i) - T(a_i) comes from extract.py.

Speed: the prompt minus its last token is run once with a KV cache; each (L, arm, alpha) is a
single-token forward through a cropped copy of that cache.  --verify checks, on a few prompts,
that this path matches a full forward pass with a last-position hook (and with no hook).
With --nocache (used for the bfloat16 replication) every (L, arm, alpha) is a full forward instead, and
--verify checks that the hook is exact, that repeated full forwards agree, and that steering has an effect.
"""
import argparse, json, os, sys, time
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402

ALPHAS = [0.5, 1.0, 2.0]


class LastPosAdd:
    def __init__(self):
        self.vec = None              # (B, d) or None

    def __call__(self, module, inp, out):
        if self.vec is None:
            return out
        h = out[0] if isinstance(out, tuple) else out
        h = h.clone()
        h[:, -1, :] += self.vec.to(device=h.device, dtype=h.dtype)
        return (h,) + tuple(out[1:]) if isinstance(out, tuple) else h


def kl_parts(lp_s, lp_0, tgt):
    """KL(p_s || p_0) total, and the KL between the renormalised off-target distributions."""
    p_s = lp_s.exp()
    kl = (p_s * (lp_s - lp_0)).sum(-1)
    mask = torch.ones(lp_s.shape[-1], dtype=torch.bool, device=lp_s.device); mask[tgt] = False
    a = torch.log_softmax(lp_s[:, mask], -1); b = torch.log_softmax(lp_0[:, mask], -1)
    kl_off = (a.exp() * (a - b)).sum(-1)
    return kl, kl_off


@torch.no_grad()
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--dataset', required=True)
    ap.add_argument('--data_dir', required=True)
    ap.add_argument('--fields', required=True, help='prefix of analyze_fields.py output')
    ap.add_argument('--out', required=True)
    ap.add_argument('--batch', type=int, default=16)
    ap.add_argument('--verify', action='store_true')
    ap.add_argument('--device', default='cuda')
    ap.add_argument('--dtype', default='float32', choices=['float32', 'bfloat16'])
    ap.add_argument('--tol', type=float, default=None, help='verify tolerance on log-probs (default 1e-3 for float32, 5e-2 for bfloat16)')
    ap.add_argument('--effect_any', action='store_true', help='verify: require a steering effect at some layer, not every layer '
                    '(layer scan: the paired displacement is ~0 in the first layers)')
    ap.add_argument('--alphas', default=','.join(map(str, ALPHAS)), help='comma-separated strengths (layer scan: 1.0)')
    ap.add_argument('--nocache', action='store_true', help='full forward for every (L, arm, alpha) instead of a cropped KV '
                    'cache (E2 amendment A1: in bfloat16 the cached and full paths differ by kernel-order noise)')
    a = ap.parse_args()
    t0 = time.time()
    beh = C.BEHAVIOUR[a.dataset]
    pairs = C.load_pairs(os.path.join(a.data_dir, f'pairs_{a.dataset}.jsonl'))
    F = json.load(open(a.fields + '.json'))
    Dz = np.load(a.fields + '_dirs.npz')
    folds = Dz['folds']
    layers = F['steer_layers']
    alphas = [float(x) for x in a.alphas.split(',')]
    arms = [k.split('_', 1)[1] for k in Dz.files if k.startswith(f'L{layers[0]}_') and k != f'L{layers[0]}_nu']
    tok, model = C.load_model(a.model, a.device, a.dtype)
    ids = C.target_ids(tok, beh)
    tgt = sorted(set((ids[0] or []) + ids[1]))
    hook = LastPosAdd()                                        # used by --verify only
    handles = {L: C.decoder_layers(model)[L - 1] for L in layers}
    prompts = [C.fmt(tok, beh, p['a']) for p in pairs]
    dev = model.device

    def vecs(L, arm, alpha, idx):
        u = torch.tensor(Dz[f'L{L}_{arm}'][idx].astype(np.float32), device=dev)
        nu = torch.tensor(Dz[f'L{L}_nu'][folds[idx]].astype(np.float32), device=dev)
        return u * (alpha * nu)[:, None]

    def prefix(idx):
        enc = tok([prompts[i] for i in idx], return_tensors='pt', padding=True).to(dev)
        ids_, am = enc.input_ids, enc.attention_mask
        out = model(input_ids=ids_[:, :-1], attention_mask=am[:, :-1], use_cache=True)
        return ids_, am, out.past_key_values, ids_.shape[1] - 1

    def last(ids_, am, cache, plen):
        if a.nocache:
            return torch.log_softmax(model(input_ids=ids_, attention_mask=am).logits[:, -1].float(), -1)
        out = model(input_ids=ids_[:, -1:], attention_mask=am, past_key_values=cache, use_cache=True)
        cache.crop(plen)
        return torch.log_softmax(out.logits[:, -1].float(), -1)

    if a.nocache:
        def prefix(idx):                                       # no cache: only tokenise
            enc = tok([prompts[i] for i in idx], return_tensors='pt', padding=True).to(dev)
            return enc.input_ids, enc.attention_mask, None, None

    if a.verify:
        idx = np.arange(min(6, len(prompts)))
        rep = {}
        for L in layers:
            h = handles[L].register_forward_hook(hook)
            v = vecs(L, 'global', 1.0, idx)
            ids_, am, cache, plen = prefix(idx)
            hook.vec = None; lp0c = last(ids_, am, cache, plen)
            hook.vec = v; lpsc = last(ids_, am, cache, plen)
            hook.vec = None
            full0 = torch.log_softmax(model(input_ids=ids_, attention_mask=am).logits[:, -1].float(), -1)
            hook.vec = v
            fulls = torch.log_softmax(model(input_ids=ids_, attention_mask=am).logits[:, -1].float(), -1)
            hook.vec = None
            # hidden_states[L] must equal the output of decoder block L-1 at the last position
            cap = {}
            h2 = handles[L].register_forward_hook(lambda m, i, o: cap.__setitem__('h', (o[0] if isinstance(o, tuple) else o)[:, -1].clone()))
            hs = model(input_ids=ids_, attention_mask=am, output_hidden_states=True).hidden_states[L][:, -1]
            h2.remove(); h.remove()
            rep[L] = dict(nohook_cache_vs_full=float((lp0c - full0).abs().max()),
                          hook_cache_vs_full=float((lpsc - fulls).abs().max()),
                          steer_effect=float((fulls - full0).abs().max()),
                          layer_index_check=float((cap['h'] - hs).abs().max()))
            if a.nocache:                                      # lp0c/lpsc are full forwards here
                full1 = torch.log_softmax(model(input_ids=ids_, attention_mask=am).logits[:, -1].float(), -1)
                rep[L]['repeat_full'] = float((lp0c - full0).abs().max())        # two identical full forwards
                rep[L]['inert_hook_vs_no_hook'] = float((full1 - full0).abs().max())  # all hooks removed above
                rep[L]['steer_effect_T'] = float((C.target_score(fulls, beh, ids) - C.target_score(full0, beh, ids)).abs().max())
        print(json.dumps(rep), flush=True)
        tol = a.tol if a.tol is not None else (1e-3 if a.dtype == 'float32' else 5e-2)
        ok = all(r['nohook_cache_vs_full'] < tol and r['hook_cache_vs_full'] < tol and r['layer_index_check'] == 0
                 for r in rep.values())
        eff = [r['steer_effect'] > 1e-2 for r in rep.values()]
        ok = ok and (any(eff) if a.effect_any else all(eff))
        if a.nocache:
            ok = ok and all(r['repeat_full'] < tol and r['inert_hook_vs_no_hook'] < tol for r in rep.values())
        json.dump(dict(verify=rep, ok=ok, tol=tol, dtype=a.dtype, nocache=a.nocache), open(a.out + '_verify.json', 'w'), indent=1)
        sys.exit(0 if ok else 'VERIFY FAILED')

    N = len(prompts)
    T0 = np.zeros(N)
    res = {f'{L}|{arm}|{al}': dict(T=np.zeros(N), kl=np.zeros(N), kl_off=np.zeros(N))
           for L in layers for arm in arms for al in alphas}
    hooks = {L: LastPosAdd() for L in layers}                 # one hook per layer; at most one active
    for L in layers:
        handles[L].register_forward_hook(hooks[L])
    order = np.argsort([len(p) for p in prompts])[::-1]
    for s in range(0, N, a.batch):
        idx = order[s:s + a.batch]
        ids_, am, cache, plen = prefix(idx)
        lp0 = last(ids_, am, cache, plen)
        T0[idx] = C.target_score(lp0, beh, ids).cpu().numpy()
        for L in layers:
            for arm in arms:
                for al in alphas:
                    hooks[L].vec = vecs(L, arm, al, idx)
                    lps = last(ids_, am, cache, plen)
                    hooks[L].vec = None
                    r = res[f'{L}|{arm}|{al}']
                    r['T'][idx] = C.target_score(lps, beh, ids).cpu().numpy()
                    kl, klo = kl_parts(lps, lp0, tgt)
                    r['kl'][idx] = kl.cpu().numpy(); r['kl_off'][idx] = klo.cpu().numpy()
        if (s // a.batch) % 10 == 0:
            print(f'[{time.time() - t0:6.0f}s] {s}/{N}', flush=True)
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    flat = {'T0': T0, 'folds': folds}
    for key, r in res.items():
        for m, v in r.items():
            flat[f'{key}|{m}'] = v
    np.savez(a.out + '.tmp.npz', **flat)
    os.replace(a.out + '.tmp.npz', a.out + '.npz')
    json.dump(dict(model=a.model, dataset=a.dataset, layers=layers, arms=arms, alphas=alphas, n=N, dtype=a.dtype,
                   nocache=a.nocache, seconds=time.time() - t0), open(a.out + '.json', 'w'), indent=1)
    print('DONE', time.time() - t0, flush=True)


if __name__ == '__main__':
    main()
