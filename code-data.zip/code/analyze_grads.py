#!/usr/bin/env python3
"""Tests P6-P8 of PREREG_2.md with readout gradients (results/grads, computed on Sherlock by grads.py).
Run after aggregate.py, explore_unitfidelity.py and analyze_scan.py.
Writes results/summary/grads_layers.csv, grads_arms.csv and grads.json."""
import argparse, glob, json, os, sys
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from aggregate import block_boot_spearman  # noqa: E402

ARMS = ['global', 'local', 'linprobe', 'mlpgrad', 'random']


def r2(x, cf):
    return 1 - float(((x - cf) ** 2).sum() / ((cf - cf.mean()) ** 2).sum())


def unit(x):
    return x / max(np.linalg.norm(x), 1e-30)


def steer_vecs(Dz, folds, L, arm, alpha=1.0):
    return Dz[f'L{L}_{arm}'].astype(np.float64) * (alpha * Dz[f'L{L}_nu'][folds])[:, None]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='results')
    a = ap.parse_args()
    R, gates = [], []
    arms_rows = []
    for gf in sorted(glob.glob(f'{a.root}/grads/grads_*.json')):
        meta = json.load(open(gf))
        m, ds = meta['model'].split('/')[-1], meta['dataset']
        Gz = np.load(gf.replace('.json', '.npz'))
        st = np.load(f'{a.root}/states/{m}_{ds}.npz')
        cf = st['Tb'] - st['Ta']; cfm = cf.mean()
        Ha, Hb = st['Ha'], st['Hb']                  # load once: npz members are re-read on every access
        gates.append(dict(model=m, dataset=ds, G1_max_abs_dT=float(np.abs(Gz['T'] - st['Ta']).max()),
                          G2_fd_ok=bool(meta['fd_ok']), G2_max_rel_err=float(meta['max_fd_rel_err']),
                          device=meta.get('device'), torch=meta.get('torch'), transformers=meta.get('transformers')))
        g_all, sc_all = Gz['g'], Gz['scale']
        # layer scan: global and local arms at every layer
        Sz = np.load(f'{a.root}/scan/scan_{m}_{ds}_dirs.npz'); St = np.load(f'{a.root}/scan/steer_{m}_{ds}.npz')
        Sm = json.load(open(f'{a.root}/scan/steer_{m}_{ds}.json'))
        folds = Sz['folds']
        for L in Sm['layers']:
            g = g_all[:, L - 1].astype(np.float64) * sc_all[:, L - 1][:, None]
            d = Hb[:, L - 1].astype(np.float64) - Ha[:, L - 1].astype(np.float64)
            sg, sl = steer_vecs(Sz, folds, L, 'global'), steer_vecs(Sz, folds, L, 'local')
            pg, pl = (g * sg).sum(1), (g * sl).sum(1)
            dTg = St[f'{L}|global|1.0|T'] - St['T0']; dTl = St[f'{L}|local|1.0|T'] - St['T0']
            gbar = g.mean(0)
            Mterm = float(gbar @ (sl.mean(0) - sg.mean(0))) / abs(cfm)
            Cterm = float(((g - gbar) * (sl - sl.mean(0))).sum(1).mean()) / abs(cfm)
            q = (g * d).sum(1)
            R.append(dict(model=m, dataset=ds, layer=L, cf=cfm,
                          r_first_order_global=float(np.corrcoef(pg, dTg)[0, 1]) if dTg.std() > 0 and pg.std() > 0 else np.nan,
                          G_obs=float((dTl - dTg).mean()) / abs(cfm), G_pred=float((pl - pg).mean()) / abs(cfm),
                          M=Mterm, C=Cterm, C_foldvar=float((pl - pg).mean()) / abs(cfm) - Mterm - Cterm,
                          dR2_obs=r2(dTl, cf) - r2(dTg, cf), dR2_pred=r2(pl, cf) - r2(pg, cf),
                          frac_pred_global=float(pg.mean() / cfm), frac_obs_global=float(dTg.mean() / cfm),
                          q_share=float(q.mean() / cfm), gnorm=float(np.linalg.norm(g, axis=1).mean())))
        # original steering layers: all five arms
        Fz = np.load(f'{a.root}/fields/fields_{m}_{ds}_dirs.npz'); Fs = np.load(f'{a.root}/steer/steer_{m}_{ds}.npz')
        Fm = json.load(open(f'{a.root}/steer/steer_{m}_{ds}.json'))
        for L in Fm['layers']:
            g = g_all[:, L - 1].astype(np.float64) * sc_all[:, L - 1][:, None]
            gbar = g.mean(0)
            rec = dict(model=m, dataset=ds, layer=L)
            for arm in ARMS:
                s = steer_vecs(Fz, Fz['folds'], L, arm)
                rec[f'pred_{arm}'] = float((g * s).sum(1).mean() / cfm)
                rec[f'obs_{arm}'] = float((Fs[f'{L}|{arm}|1.0|T'] - Fs['T0']).mean() / cfm)
                rec[f'cos_gbar_{arm}'] = float(abs(unit(gbar) @ unit(Fz[f'L{L}_{arm}'].astype(np.float64).mean(0))))
            arms_rows.append(rec)
    out = {}
    if not R:
        print('no gradient files'); return
    D = pd.DataFrame(R)
    D = D.merge(pd.read_csv(f'{a.root}/summary/scan_layers.csv')[['model', 'dataset', 'layer', 'rho_glob', 'frac_global', 'frac_local', 'cf_ci0']],
                on=['model', 'dataset', 'layer'], how='left')
    D.to_csv(f'{a.root}/summary/grads_layers.csv', index=False)
    A = pd.DataFrame(arms_rows)
    W = pd.read_csv(f'{a.root}/summary/unit_fidelity_wide.csv')[['model', 'dataset', 'layer', 'suff']]
    A = A.merge(W, on=['model', 'dataset', 'layer'], how='left')
    A.to_csv(f'{a.root}/summary/grads_arms.csv', index=False)
    Gt = pd.DataFrame(gates)
    out['gates'] = dict(n_cells=int(len(Gt)), G1_max=float(Gt.G1_max_abs_dT.max()), G1_pass=bool((Gt.G1_max_abs_dT <= 5e-3).all()),
                        G2_pass=bool(Gt.G2_fd_ok.all()), G2_max_rel_err=float(Gt.G2_max_rel_err.max()),
                        per_cell=Gt.to_dict('records'))
    lev = D[(np.maximum(D.frac_global, D.frac_local) >= 0.5) & ~D.cf_ci0.astype(bool)]
    out['n_leverage_cells'] = int(len(lev)); out['n_models'] = int(D.model.nunique())
    out['P6_median_r_first_order_global'] = float(lev.r_first_order_global.median())
    out['P6_spearman_Gpred_Gobs'] = block_boot_spearman(lev, 'G_pred', 'G_obs')
    out['P7_spearman_dR2pred_dR2obs'] = block_boot_spearman(lev, 'dR2_pred', 'dR2_obs')
    out['median_abs_M'] = float(lev.M.abs().median()); out['median_abs_C'] = float(lev.C.abs().median())
    out['median_abs_C_foldvar'] = float(lev.C_foldvar.abs().median())
    out['median_q_share'] = float(lev.q_share.median())
    out['median_frac_pred_vs_obs_global'] = [float(lev.frac_pred_global.median()), float(lev.frac_obs_global.median())]
    sa = A[A.suff.fillna(False).astype(bool)]
    rhos = [spearmanr([r[f'pred_{x}'] for x in ARMS], [r[f'obs_{x}'] for x in ARMS]).correlation for _, r in sa.iterrows()]
    out['P8_n_cells'] = int(len(sa)); out['P8_median_within_cell_spearman'] = float(np.nanmedian(rhos)) if rhos else None
    out['P8_frac_probes_below_global_cos'] = float(((sa.cos_gbar_linprobe < sa.cos_gbar_global) & (sa.cos_gbar_mlpgrad < sa.cos_gbar_global)).mean()) if len(sa) else None
    out['P8_median_cos'] = {x: float(sa[f'cos_gbar_{x}'].median()) for x in ARMS} if len(sa) else None
    json.dump(out, open(f'{a.root}/summary/grads.tmp.json', 'w'), indent=1, default=float)
    os.replace(f'{a.root}/summary/grads.tmp.json', f'{a.root}/summary/grads.json')
    print(json.dumps({k: v for k, v in out.items() if k != 'gates'}, indent=1, default=float))
    print(json.dumps({k: v for k, v in out['gates'].items() if k != 'per_cell'}, indent=1))


if __name__ == '__main__':
    main()
