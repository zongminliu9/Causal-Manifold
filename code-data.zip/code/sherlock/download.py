#!/usr/bin/env python3
"""Fetch model snapshots at the exact revisions used on Marlowe (refs/main there), into $HF_HOME/hub."""
import sys
from huggingface_hub import snapshot_download

REVS = {
    'Qwen/Qwen2.5-0.5B-Instruct': '7ae557604adf67be50417f59c2c2f167def9a775',
    'Qwen/Qwen2.5-1.5B-Instruct': '989aa7980e4cf806f80c7fef2b1adb7bc71aa306',
    'Qwen/Qwen2.5-3B-Instruct': 'aa8e72537993ba99e69dfaafa59ed015b17504d1',
    'Qwen/Qwen2.5-7B-Instruct': 'a09a35458c702b33eeacc393d103063234e8bc28',
    'HuggingFaceTB/SmolLM2-1.7B-Instruct': '31b70e2e869a7173562077fd711b654946d38674',
    'allenai/OLMo-2-0425-1B-Instruct': '48d788eca847d4d7548f375ad03d3c9312f6139e',
}
for repo, rev in REVS.items():
    p = snapshot_download(repo, revision=rev, allow_patterns=['*.json', '*.safetensors', '*.txt', '*.model', 'tokenizer*'])
    print(repo, rev, p, flush=True)
print('DOWNLOAD_DONE')
