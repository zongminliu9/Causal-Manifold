# Sherlock environment for the CMA GPU stages (modules only; no environment is built).
ml purge >/dev/null 2>&1
ml math
ml py-pytorch/2.10.0_py314 py-transformers/4.57.3_py314 py-scipy/1.16.3_py314 py-pandas/2.3.3_py314
export HF_HOME=$SCRATCH/hf PIP_CACHE_DIR=$SCRATCH/.cache/pip XDG_CACHE_HOME=$SCRATCH/.cache TOKENIZERS_PARALLELISM=false
export CMA_CODE=$HOME/cma_rev/code CMA_RUN=$SCRATCH/cma_rev
