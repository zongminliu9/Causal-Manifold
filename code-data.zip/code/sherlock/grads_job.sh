#!/bin/bash
# usage (sbatch): grads_job.sh <batch> <hf model id> [<hf model id> ...]; all five datasets per model.
set -u
source $HOME/cma_rev/code/sherlock/env.sh
export HF_HUB_OFFLINE=1 OMP_NUM_THREADS=${SLURM_CPUS_PER_TASK:-4}
echo "host $(hostname) job ${SLURM_JOB_ID:-none} $(nvidia-smi --query-gpu=name,memory.total --format=csv,noheader)"
python3 -c "import torch, transformers; print('torch', torch.__version__, 'cuda', torch.version.cuda, 'transformers', transformers.__version__, torch.cuda.get_arch_list())"
BS=$1; shift
fail=0
for M in "$@"; do
  b=$(basename $M)
  for D in cities larger_than sp_en_trans cad advbench; do
    O=$CMA_RUN/results/grads/grads_${b}_$D
    [ -f $O.json ] && continue
    echo "##### $(date +%T) $b $D"
    python3 -u $CMA_CODE/grads.py --model $M --dataset $D --data_dir $CMA_RUN/data --out $O --batch $BS || { echo "FAILED $b $D"; fail=1; }
  done
done
echo "##### $(date +%T) GRADS_DONE fail=$fail"
exit $fail
