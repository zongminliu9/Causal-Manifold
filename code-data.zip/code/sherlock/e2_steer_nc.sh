#!/bin/bash
# E2 amendment A1 (PREREG_E2.md): steering and layer scan without the KV-cache shortcut, one dataset per job.
# usage: e2_steer_nc.sh <hf model id> <dtype> <batch> <hub cache dir> <dataset>
# Resumable: a step is skipped when its final output (written atomically) exists. Exits 1 if any step fails.
set -u
source $HOME/cma_rev/code_v2/sherlock/env.sh
CODE=$HOME/cma_rev/code_v2
M=$1; DT=$2; BS=$3; export HF_HUB_CACHE=$4; D=$5
export HF_HUB_OFFLINE=1 OMP_NUM_THREADS=${SLURM_CPUS_PER_TASK:-4}
b=$(basename $M); R=$CMA_RUN/results; DATA=$CMA_RUN/data
mkdir -p $R/steer_nc $R/scan_nc
step() { echo "##### $(date +%T) $*"; }
echo "host $(hostname) job ${SLURM_JOB_ID:-none} model $M dtype $DT dataset $D batch $BS"
nvidia-smi --query-gpu=name,memory.total --format=csv,noheader
python3 -c "import torch, transformers; print('torch', torch.__version__, 'transformers', transformers.__version__)"
fail=0
F=$R/fields/fields_${b}_$D; P=$R/scan/scan_${b}_$D
O=$R/steer_nc/steer_${b}_$D; Q=$R/scan_nc/steer_${b}_$D
if [ ! -f ${O}_verify.json ]; then
  step verify $D
  python3 -u $CODE/steer.py --model $M --dataset $D --data_dir $DATA --fields $F --out $O --verify --nocache --dtype $DT || { echo "FAILED verify $D"; exit 1; }
fi
if [ ! -f $O.json ]; then
  step steer $D
  python3 -u $CODE/steer.py --model $M --dataset $D --data_dir $DATA --fields $F --out $O --batch $BS --nocache --dtype $DT || { echo "FAILED steer $D"; fail=1; }
fi
if [ ! -f ${Q}_verify.json ]; then
  step scan_verify $D
  python3 -u $CODE/steer.py --model $M --dataset $D --data_dir $DATA --fields $P --out $Q --verify --effect_any --alphas 1.0 --nocache --dtype $DT || { echo "FAILED scan_verify $D"; exit 1; }
fi
if [ ! -f $Q.json ]; then
  step scan_steer $D
  python3 -u $CODE/steer.py --model $M --dataset $D --data_dir $DATA --fields $P --out $Q --batch $BS --alphas 1.0 --nocache --dtype $DT || { echo "FAILED scan_steer $D"; fail=1; }
fi
step DONE $b $D fail=$fail
exit $fail
