#!/bin/bash
# E2 (PLAN_STRONGEST.md): the full CMA pipeline for one larger model on Sherlock, one stage per job.
# usage: e2_stage.sh <stage: extract|analyse|steer> <hf model id> <dtype> <device: cuda|auto> <batch> <hub cache dir>
# Stages are resumable: a step is skipped when its final output (written atomically) exists.
set -u
source $HOME/cma_rev/code_v2/sherlock/env.sh
CODE=$HOME/cma_rev/code_v2
STAGE=$1; M=$2; DT=$3; DEV=$4; BS=$5; export HF_HUB_CACHE=$6
export HF_HUB_OFFLINE=1 OMP_NUM_THREADS=${SLURM_CPUS_PER_TASK:-4}
b=$(basename $M); R=$CMA_RUN/results; DATA=$CMA_RUN/data
mkdir -p $R/states $R/fields $R/steer $R/scan $R/gen2
step() { echo "##### $(date +%T) $*"; }
echo "host $(hostname) job ${SLURM_JOB_ID:-none} stage $STAGE model $M dtype $DT device $DEV"
[ "$STAGE" != analyse ] && nvidia-smi --query-gpu=name,memory.total --format=csv,noheader
python3 -c "import torch, transformers; print('torch', torch.__version__, 'transformers', transformers.__version__)"
DS="cities larger_than sp_en_trans cad advbench"
fail=0
for D in $DS; do
  case $STAGE in
  extract)
    [ -f $R/states/${b}_$D.json ] && continue
    step extract $D
    python3 -u $CODE/extract.py --model $M --dataset $D --data_dir $DATA --out $R/states/${b}_$D --batch $BS --device $DEV --dtype $DT || { echo "FAILED extract $D"; fail=1; } ;;
  analyse)
    if [ ! -f $R/fields/fields_${b}_$D.json ]; then
      step analyse $D
      python3 -u $CODE/analyze_fields.py --states $R/states/${b}_$D --out $R/fields/fields_${b}_$D --threads ${SLURM_CPUS_PER_TASK:-8} || { echo "FAILED analyse $D"; fail=1; continue; }
    fi
    if [ ! -f $R/scan/scan_${b}_$D.json ]; then
      step scan_dirs $D
      python3 -u $CODE/scan_dirs.py --states $R/states/${b}_$D --out $R/scan/scan_${b}_$D || { echo "FAILED scan_dirs $D"; fail=1; }
    fi ;;
  steer)
    F=$R/fields/fields_${b}_$D; P=$R/scan/scan_${b}_$D
    if [ ! -f $R/steer/steer_${b}_${D}_verify.json ]; then
      step verify $D
      python3 -u $CODE/steer.py --model $M --dataset $D --data_dir $DATA --fields $F --out $R/steer/steer_${b}_$D --verify --device $DEV --dtype $DT || { echo "FAILED verify $D"; fail=1; continue; }
    fi
    if [ ! -f $R/steer/steer_${b}_$D.json ]; then
      step steer $D
      python3 -u $CODE/steer.py --model $M --dataset $D --data_dir $DATA --fields $F --out $R/steer/steer_${b}_$D --batch $BS --device $DEV --dtype $DT || { echo "FAILED steer $D"; fail=1; }
    fi
    if [ ! -f $R/scan/steer_${b}_${D}_verify.json ]; then
      step scan_verify $D
      python3 -u $CODE/steer.py --model $M --dataset $D --data_dir $DATA --fields $P --out $R/scan/steer_${b}_$D --verify --effect_any --alphas 1.0 --device $DEV --dtype $DT || { echo "FAILED scan_verify $D"; fail=1; continue; }
    fi
    if [ ! -f $R/scan/steer_${b}_$D.json ]; then
      step scan_steer $D
      python3 -u $CODE/steer.py --model $M --dataset $D --data_dir $DATA --fields $P --out $R/scan/steer_${b}_$D --batch $BS --alphas 1.0 --device $DEV --dtype $DT || { echo "FAILED scan_steer $D"; fail=1; }
    fi ;;
  esac
done
if [ "$STAGE" = steer ]; then
  for POS in deep mid; do
    [ -f $R/gen2/gen_${b}_$POS.json ] && continue
    step gen $POS
    python3 -u $CODE/gen_check.py --model $M --data_dir $DATA --fields $R/fields/fields_${b}_advbench --out $R/gen2/gen_${b}_$POS --pos $POS --device $DEV --dtype $DT || { echo "FAILED gen $POS"; fail=1; }
  done
fi
step STAGE_DONE $STAGE $b fail=$fail
exit $fail
