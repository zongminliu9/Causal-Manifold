#!/bin/bash
# Stream Sherlock result files to Marlowe through this machine (nothing is written to the local disk), then compare
# md5 sums on both ends. Run locally: pull_to_marlowe.sh <results subdir> <glob>, e.g. pull_to_marlowe.sh grads 'grads_Qwen2.5-0.5B*'
# Only finished files (no *.tmp.*) are sent; files already on Marlowe with the same md5 are skipped.
set -eu
SUB=$1; PAT=$2
MR=/scratch/m000251/zongminl/cma_rev/results
list=$(ssh -o BatchMode=yes sherlock "bash -lc 'cd \$SCRATCH/cma_rev/results/$SUB && ls $PAT 2>/dev/null | grep -v \"\\.tmp\\.\"'" 2>/dev/null | grep -v Automated || true)
[ -z "$list" ] && { echo "nothing matches $SUB/$PAT"; exit 1; }
ssh -o BatchMode=yes mlw2 "mkdir -p $MR/$SUB"
fail=0
for f in $list; do
  s=$(ssh -o BatchMode=yes sherlock "bash -lc 'md5sum \$SCRATCH/cma_rev/results/$SUB/$f'" 2>/dev/null | grep -v Automated | cut -d' ' -f1)
  m=$(ssh -o BatchMode=yes mlw2 "md5sum $MR/$SUB/$f 2>/dev/null | cut -d' ' -f1" || true)
  if [ "$s" = "$m" ]; then echo "same  $f"; continue; fi
  ssh -o BatchMode=yes sherlock "bash -lc 'cat \$SCRATCH/cma_rev/results/$SUB/$f'" 2>/dev/null | ssh -o BatchMode=yes mlw2 "cat > $MR/$SUB/$f.part && mv $MR/$SUB/$f.part $MR/$SUB/$f"
  m=$(ssh -o BatchMode=yes mlw2 "md5sum $MR/$SUB/$f | cut -d' ' -f1")
  if [ "$s" = "$m" ]; then echo "ok    $f $s"; else echo "BAD   $f sherlock=$s marlowe=$m"; fail=1; fi
done
exit $fail
