#!/usr/bin/env python3
"""Fetch the E2 model that is not cached on Sherlock yet; prints the revision actually downloaded (pin it)."""
from huggingface_hub import snapshot_download, HfApi

for repo in ['allenai/OLMo-2-1124-13B-Instruct']:
    rev = HfApi().model_info(repo).sha
    p = snapshot_download(repo, revision='main', allow_patterns=['*.json', '*.safetensors', '*.txt', '*.model', 'tokenizer*'])
    print(repo, 'main =', rev, p, flush=True)
print('DOWNLOAD_DONE')
