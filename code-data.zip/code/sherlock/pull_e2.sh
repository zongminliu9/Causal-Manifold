#!/bin/bash
# Stream Sherlock result files to Marlowe through this machine (nothing is written to the local disk) and compare
# md5 sums on both ends. usage: pull_e2.sh <Sherlock results subdir> <Marlowe dir under cma_rev> <glob>
# e.g. pull_e2.sh steer_nc results_e2/steer 'steer_phi-4_*'. Files already on Marlowe with the same md5 are skipped.
set -u
SUB=$1; DST=/scratch/m000251/zongminl/cma_rev/$2; PAT=$3
list=$(ssh -o BatchMode=yes sherlock "bash -lc 'cd \$SCRATCH/cma_rev/results/$SUB && ls $PAT 2>/dev/null | grep -v \"\\.tmp\\.\"'" 2>/dev/null | grep -v Automated || true)
[ -z "$list" ] && { echo "nothing matches $SUB/$PAT"; exit 1; }
ssh -o BatchMode=yes mlw2 "mkdir -p $DST"
smd=$(ssh -o BatchMode=yes sherlock "bash -lc 'cd \$SCRATCH/cma_rev/results/$SUB && md5sum $PAT'" 2>/dev/null | grep -v Automated)
mmd=$(ssh -o BatchMode=yes mlw2 "cd $DST && md5sum $PAT 2>/dev/null" || true)
fail=0
for f in $list; do
  s=$(echo "$smd" | awk -v f="$f" '$2==f{print $1}')
  m=$(echo "$mmd" | awk -v f="$f" '$2==f{print $1}')
  if [ -n "$s" ] && [ "$s" = "$m" ]; then echo "same  $f"; continue; fi
  ssh -o BatchMode=yes sherlock "bash -lc 'cat \$SCRATCH/cma_rev/results/$SUB/$f'" 2>/dev/null | ssh -o BatchMode=yes mlw2 "cat > $DST/$f.part && mv $DST/$f.part $DST/$f"
  m=$(ssh -o BatchMode=yes mlw2 "md5sum $DST/$f | cut -d' ' -f1")
  if [ "$s" = "$m" ]; then echo "ok    $f"; else echo "BAD   $f sherlock=$s marlowe=$m"; fail=1; fi
done
exit $fail
