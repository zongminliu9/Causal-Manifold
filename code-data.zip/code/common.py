"""Prompt formats, target scores and hooks shared by extract.py, steer.py and gen_check.py.

Layer convention: layer L (1 <= L <= n_layers-1) means hidden_states[L] in Hugging Face
output, i.e. the residual stream leaving decoder block L-1, before the final norm.
All states, fields and steering vectors live at the readout position, which is the last
prompt token (the assistant turn start), so the answer is the next token.
"""
import json
import torch

BEHAVIOUR = {'cad': 'sentiment', 'cities': 'truth', 'larger_than': 'truth', 'sp_en_trans': 'truth',
             'advbench': 'refusal'}

TEMPLATES = {
    'sentiment': ("Here is a movie review.\n\n{x}\n\nIs the sentiment of this review positive or negative? "
                  "Answer with one word."),
    'truth': "Is the following statement true or false?\n\n{x}\n\nAnswer with one word: True or False.",
    'refusal': "{x}",
}
# a-side and b-side answer words.  T = logsumexp(logp[b]) - logsumexp(logp[a]) for sentiment/truth;
# for refusal T = log P(R) - log(1 - P(R)) with R the refusal-start tokens (Arditi et al. 2024 style).
WORDS = {
    'sentiment': (['Positive', 'positive'], ['Negative', 'negative']),
    'truth': (['True', 'true'], ['False', 'false']),
    'refusal': (None, ['I', 'As', 'Sorry', 'Unfortunately']),
}


def load_pairs(path):
    return [json.loads(l) for l in open(path)]


def fmt(tok, behaviour, x):
    return tok.apply_chat_template([{'role': 'user', 'content': TEMPLATES[behaviour].format(x=x)}],
                                   tokenize=False, add_generation_prompt=True)


def word_ids(tok, words):
    ids = set()
    for w in words:
        for v in (w, ' ' + w):
            t = tok.encode(v, add_special_tokens=False)
            if t:
                ids.add(t[0])
    return sorted(ids)


def target_ids(tok, behaviour):
    a, b = WORDS[behaviour]
    return (word_ids(tok, a) if a else None), word_ids(tok, b)


def target_score(logits, behaviour, ids):
    """logits: (B, V) at the readout position -> T (B,)"""
    lp = torch.log_softmax(logits.float(), -1)
    a_ids, b_ids = ids
    if behaviour == 'refusal':
        lr = torch.logsumexp(lp[:, b_ids], -1)
        return lr - torch.log1p(-torch.exp(lr).clamp(max=1 - 1e-7))
    return torch.logsumexp(lp[:, b_ids], -1) - torch.logsumexp(lp[:, a_ids], -1)


def decoder_layers(model):
    return model.model.layers


DTYPES = {'float32': torch.float32, 'bfloat16': torch.bfloat16}


def load_model(name, device='cuda', dtype=torch.float32):
    """dtype: a torch dtype or a DTYPES key. device='auto' spreads the model over all visible GPUs."""
    import os
    from transformers import AutoModelForCausalLM, AutoTokenizer
    dtype = DTYPES[dtype] if isinstance(dtype, str) else dtype
    if os.environ.get('HF_HUB_OFFLINE') == '1' and not os.path.isdir(name):
        # Offline: load from the pinned local snapshot (refs/main of the hub cache). transformers 4.57 otherwise
        # calls the Hub API while loading some tokenizers (_patch_mistral_regex) and fails in offline mode.
        from huggingface_hub import snapshot_download
        name = snapshot_download(name, local_files_only=True)
        print('model snapshot', name, flush=True)
    tok = AutoTokenizer.from_pretrained(name)
    tok.padding_side = 'left'
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    if device == 'auto':
        model = AutoModelForCausalLM.from_pretrained(name, torch_dtype=dtype, device_map='auto').eval()
    else:
        model = AutoModelForCausalLM.from_pretrained(name, torch_dtype=dtype).to(device).eval()
    return tok, model
