"""Estimators shared by the simulations and the language-model analyses.

Notation follows the manuscript.  For pair i we observe a pre-state h_i and a paired
displacement d_i = (H_i^{a,delta} - H_i) / delta = V(h_i) + e_i, where e_i has conditional
mean zero and is independent across pairs (assumption A3).

Regime indices
  rho_glob = ||E V||^2 / E||V||^2         fraction of field energy a constant vector reproduces
  lam_1    = lambda_max(M) / tr(M),  M = E[V V^T]
                                           fraction captured by one direction with a state-
                                           dependent (signed) gain
  rho_glob <= lam_1 <= 1.
Both are estimated without noise bias by cross-pair U-statistics: for i != j,
E<d_i, d_j> = E<V(h_i), V(h_j)>.  The denominators use neighbour pairs (j in the k nearest
pre-states of i), which converge to E||V||^2 as the neighbourhood shrinks.
The naive orientation spectrum lambda_max(E[u u^T]) with u = d/||d|| is biased downwards by
the pair noise e; it is reported for comparison only.
"""
import numpy as np


# --------------------------------------------------------------------------- neighbours
def center_cosine_feats(H, mu=None):
    """Mean-centre and L2-normalise rows; Euclidean distance on the result is a monotone
    function of centred cosine distance.  Used for all kNN searches on real activations."""
    if mu is None:
        mu = H.mean(0, keepdims=True)
    Z = H - mu
    Z = Z / np.maximum(np.linalg.norm(Z, axis=1, keepdims=True), 1e-12)
    return Z, mu


def knn_indices(Q, X, k, exclude_self=False, block=2048):
    """Indices of the k nearest rows of X for each row of Q (Euclidean)."""
    X2 = (X * X).sum(1)
    k = min(k, X.shape[0] - (1 if exclude_self else 0))
    out = np.empty((Q.shape[0], k), dtype=np.int64)
    for s in range(0, Q.shape[0], block):
        q = Q[s:s + block]
        D = (q * q).sum(1)[:, None] + X2[None, :] - 2.0 * q @ X.T
        if exclude_self:
            idx = np.arange(s, s + q.shape[0])
            D[np.arange(q.shape[0]), idx] = np.inf
        kk = min(k, X.shape[0] - (1 if exclude_self else 0))
        part = np.argpartition(D, kk - 1, axis=1)[:, :kk]
        order = np.take_along_axis(D, part, 1).argsort(1)
        out[s:s + q.shape[0], :kk] = np.take_along_axis(part, order, 1)
    return out


def knn_indices_other_groups(Z, groups, k):
    """k nearest rows of Z for each row, restricted to rows of a different group (dense)."""
    n = Z.shape[0]
    Z2 = (Z * Z).sum(1)
    out = np.empty((n, k), dtype=np.int64)
    g = np.asarray(groups)
    for s in range(0, n, 1024):
        q = Z[s:s + 1024]
        D = Z2[s:s + 1024, None] + Z2[None, :] - 2.0 * q @ Z.T
        D[g[s:s + 1024, None] == g[None, :]] = np.inf
        part = np.argpartition(D, k - 1, axis=1)[:, :k]
        out[s:s + 1024] = part
    return out


# --------------------------------------------------------------------------- indices
def u_all(Dm):
    """Unbiased estimate of ||E V||^2: mean of <d_i, d_j> over i != j."""
    n = Dm.shape[0]
    s = Dm.sum(0)
    return float((s @ s - (Dm * Dm).sum()) / (n * (n - 1)))


def nbr_mean(Dm, nbr):
    """Row i: mean of Dm over the neighbours nbr[i] (sparse product, no n x k x d gather)."""
    from scipy.sparse import csr_matrix
    n, k = nbr.shape
    A = csr_matrix((np.full(n * k, 1.0 / k), (np.repeat(np.arange(n), k), nbr.ravel())), shape=(n, Dm.shape[0]))
    return A @ Dm


def u_knn(Dm, nbr):
    """Mean of <d_i, d_j> over neighbour pairs (j in nbr[i], j != i)."""
    return float((Dm * nbr_mean(Dm, nbr)).sum() / nbr.shape[0])


def m_knn(Dm, nbr):
    """Symmetrised neighbour cross-moment, an estimate of M = E[V V^T] free of pair noise."""
    G = Dm.T @ nbr_mean(Dm, nbr) / Dm.shape[0]
    return 0.5 * (G + G.T)


def lam1_from_M(M):
    w = np.linalg.eigvalsh(M)
    tr = w.sum()
    return float(w[-1] / tr) if tr > 0 else float('nan')


def lam1_lowrank(Dm, nbr, r=64):
    """lambda_max(M)/tr(M) for M = sym(Dm^T Nbar)/n without forming a d x d matrix when d is
    large: power iteration on the operator x -> M x."""
    n = Dm.shape[0]
    Nb = nbr_mean(Dm, nbr)
    tr = float(np.einsum('id,id->', Dm, Nb) / n)
    rng = np.random.default_rng(0)
    x = rng.standard_normal(Dm.shape[1]); x /= np.linalg.norm(x)
    lam = 0.0
    for _ in range(300):
        y = 0.5 * (Dm.T @ (Nb @ x) + Nb.T @ (Dm @ x)) / n
        lam_new = float(x @ y)
        nrm = np.linalg.norm(y)
        if nrm == 0:
            break
        x = y / nrm
        if abs(lam_new - lam) < 1e-10 * max(1.0, abs(lam_new)):
            lam = lam_new
            break
        lam = lam_new
    return lam / tr if tr > 0 else float('nan'), tr


def naive_orientation(Dm):
    """Naive orientation spectrum of normalised displacements: lambda_max(E[u u^T]) and ||E u||."""
    U = Dm / np.maximum(np.linalg.norm(Dm, axis=1, keepdims=True), 1e-12)
    # lambda_max of U^T U / n via the smaller Gram matrix
    if U.shape[0] <= U.shape[1]:
        w = np.linalg.eigvalsh(U @ U.T / U.shape[0])
    else:
        w = np.linalg.eigvalsh(U.T @ U / U.shape[0])
    return float(w[-1]), float(np.linalg.norm(U.mean(0)))


def regime_indices(H, Dm, k, feats=None):
    """All regime indices for one cell.  H: pre-states (n x p), Dm: displacements (n x d)."""
    Z = feats if feats is not None else H
    nbr = knn_indices(Z, Z, k, exclude_self=True)
    ua, uk = u_all(Dm), u_knn(Dm, nbr)
    if Dm.shape[1] <= 512:
        lam1 = lam1_from_M(m_knn(Dm, nbr))
    else:
        lam1, _ = lam1_lowrank(Dm, nbr)
    lam_naive, eu_naive = naive_orientation(Dm)
    return dict(u_all=ua, u_knn=uk, rho_glob=ua / uk if uk > 0 else float('nan'),
                lam1=lam1, lam_naive=lam_naive, Eu_naive=eu_naive,
                mean_sq_norm=float((Dm * Dm).sum(1).mean()))


def perm_null_rho(H, Dm, k, n_perm=200, seed=0, feats=None):
    """Permutation null for rho_glob: shuffle displacements across pre-states."""
    Z = feats if feats is not None else H
    nbr = knn_indices(Z, Z, k, exclude_self=True)
    ua = u_all(Dm)
    rng = np.random.default_rng(seed)
    out = np.empty(n_perm)
    for b in range(n_perm):
        p = rng.permutation(Dm.shape[0])
        out[b] = ua / u_knn(Dm[p], nbr)
    return out


# --------------------------------------------------------------------------- folds / groups
def tfidf_groups(texts, thr=0.5, extra_keys=None):
    """Connected components of the graph 'TF-IDF cosine >= thr' (near-duplicate families),
    merged with any natural family key.  Returns integer group labels."""
    import re
    toks = [re.findall(r"[a-z0-9']+", t.lower()) for t in texts]
    vocab = {}
    for ts in toks:
        for w in set(ts):
            vocab[w] = vocab.get(w, 0) + 1
    vid = {w: i for i, w in enumerate(vocab)}
    n = len(texts)
    idf = np.log((1 + n) / (1 + np.array([vocab[w] for w in vid]))) + 1.0
    rows = np.zeros((n, len(vid)), dtype=np.float32) if len(vid) * n < 4e8 else None
    if rows is None:
        raise MemoryError('vocabulary too large for dense TF-IDF')
    for i, ts in enumerate(toks):
        for w in ts:
            rows[i, vid[w]] += 1.0
    rows *= idf[None, :].astype(np.float32)
    rows /= np.maximum(np.linalg.norm(rows, axis=1, keepdims=True), 1e-12)
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for s in range(0, n, 1024):
        S = rows[s:s + 1024] @ rows.T
        ii, jj = np.nonzero(S >= thr)
        for a, b in zip(ii + s, jj):
            if a < b:
                union(int(a), int(b))
    if extra_keys is not None:
        first = {}
        for i, key in enumerate(extra_keys):
            if key in first:
                union(i, first[key])
            else:
                first[key] = i
    roots = [find(i) for i in range(n)]
    uniq = {r: g for g, r in enumerate(dict.fromkeys(roots))}
    return np.array([uniq[r] for r in roots])


def group_folds(groups, n_folds=5, seed=0):
    """Assign whole groups to folds, balancing fold sizes greedily."""
    rng = np.random.default_rng(seed)
    ug, cnt = np.unique(groups, return_counts=True)
    order = rng.permutation(len(ug))
    order = order[np.argsort(-cnt[order], kind='stable')]
    load = np.zeros(n_folds)
    gfold = {}
    for gi in order:
        f = int(np.argmin(load))
        gfold[ug[gi]] = f
        load[f] += cnt[gi]
    return np.array([gfold[g] for g in groups])


def group_bootstrap_mean(values, groups, n_boot=2000, seed=0):
    """Percentile CI for the mean of per-item values, resampling groups."""
    values = np.asarray(values, float)
    ug, inv = np.unique(groups, return_inverse=True)
    sums = np.bincount(inv, weights=values, minlength=len(ug))
    cnts = np.bincount(inv, minlength=len(ug)).astype(float)
    rng = np.random.default_rng(seed)
    bs = np.empty(n_boot)
    for b in range(n_boot):
        s = rng.integers(0, len(ug), len(ug))
        bs[b] = sums[s].sum() / cnts[s].sum()
    return float(values.mean()), float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))


# --------------------------------------------------------------------------- classifiers
def auroc(score, y):
    score = np.asarray(score, float); y = np.asarray(y).astype(bool)
    n1, n0 = y.sum(), (~y).sum()
    if n1 == 0 or n0 == 0:
        return float('nan')
    from scipy.stats import rankdata
    r = rankdata(score)
    return float((r[y].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def fit_logistic(X, y, l2=1e-2):
    from scipy.optimize import minimize
    Xb = np.c_[X, np.ones(len(X))]
    y = np.asarray(y, float)

    def f(w):
        z = Xb @ w
        ll = np.logaddexp(0, z) - y * z
        g = Xb.T @ (1 / (1 + np.exp(-z)) - y) / len(y)
        pen = 0.5 * l2 * (w[:-1] @ w[:-1])
        g[:-1] += l2 * w[:-1]
        return ll.mean() + pen, g

    w = minimize(f, np.zeros(Xb.shape[1]), jac=True, method='L-BFGS-B',
                 options=dict(maxiter=2000)).x
    return w


def predict_logistic(w, X):
    return np.c_[X, np.ones(len(X))] @ w


def knn_score(Xtr, ytr, Xte, k=15):
    nb = knn_indices(Xte, Xtr, k)
    return np.asarray(ytr, float)[nb].mean(1)
