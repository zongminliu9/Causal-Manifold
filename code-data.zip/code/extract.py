#!/usr/bin/env python3
"""Paired readout-position residual states for every layer, for both members of each pair.

Output npz: Ha, Hb (N x (n_layers-1) x d, float16; index j is layer L = j+1), Ta, Tb (target
score of each prompt), lens, ids, groups, and a canary block: the first pair is re-run at the
end and must agree bit for bit with its first run (otherwise the batch is rejected).
"""
import argparse, json, os, sys, time
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402


@torch.no_grad()
def run(tok, model, prompts, behaviour, ids, batch, max_tokens):
    H, T, lens = [], [], []
    order = np.argsort([len(p) for p in prompts])[::-1]          # long first, stable memory
    outH = [None] * len(prompts); outT = [None] * len(prompts); outL = [None] * len(prompts)
    for s in range(0, len(prompts), batch):
        idx = order[s:s + batch]
        enc = tok([prompts[i] for i in idx], return_tensors='pt', padding=True, truncation=True,
                  max_length=max_tokens).to(model.device)
        out = model(**enc, output_hidden_states=True)
        hs = torch.stack(out.hidden_states[1:-1], 1)[:, :, -1, :]   # B x (n_layers-1) x d
        sc = C.target_score(out.logits[:, -1], behaviour, ids)
        for r, i in enumerate(idx):
            outH[i] = hs[r].half().cpu().numpy(); outT[i] = float(sc[r]); outL[i] = int(enc.attention_mask[r].sum())
    return np.stack(outH), np.array(outT), np.array(outL)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--dataset', required=True)
    ap.add_argument('--data_dir', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--batch', type=int, default=16)
    ap.add_argument('--max_tokens', type=int, default=1024)
    ap.add_argument('--device', default='cuda')
    ap.add_argument('--dtype', default='float32', choices=['float32', 'bfloat16'])
    a = ap.parse_args()
    t0 = time.time()
    beh = C.BEHAVIOUR[a.dataset]
    pairs = C.load_pairs(os.path.join(a.data_dir, f'pairs_{a.dataset}.jsonl'))
    tok, model = C.load_model(a.model, a.device, a.dtype)
    ids = C.target_ids(tok, beh)
    pa = [C.fmt(tok, beh, p['a']) for p in pairs]
    pb = [C.fmt(tok, beh, p['b']) for p in pairs]
    canary0 = run(tok, model, [pa[0], pb[0]], beh, ids, 2, a.max_tokens)
    Ha, Ta, La = run(tok, model, pa, beh, ids, a.batch, a.max_tokens)
    Hb, Tb, Lb = run(tok, model, pb, beh, ids, a.batch, a.max_tokens)
    canary1 = run(tok, model, [pa[0], pb[0]], beh, ids, 2, a.max_tokens)
    ok = bool(np.array_equal(canary0[0], canary1[0]) and np.array_equal(canary0[1], canary1[1]))
    # batch-composition check: pair 0 inside its full batch vs alone (padding must not move it much)
    rel = float(np.abs(Ha[0].astype(np.float32) - canary0[0][0].astype(np.float32)).max()
                / max(1e-6, np.abs(canary0[0][0].astype(np.float32)).max()))
    meta = dict(model=a.model, dataset=a.dataset, behaviour=beh, n=len(pairs), n_layers_saved=int(Ha.shape[1]),
                d=int(Ha.shape[2]), target_ids=[ids[0], ids[1]], canary_bitwise_equal=ok,
                canary_batch_rel_maxdiff=rel, truncated=int(((La >= a.max_tokens) | (Lb >= a.max_tokens)).sum()),
                mean_T_a=float(Ta.mean()), mean_T_b=float(Tb.mean()),
                frac_Tb_gt_Ta=float((Tb > Ta).mean()), seconds=time.time() - t0, dtype=a.dtype,
                torch=torch.__version__)
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    np.savez(a.out + '.tmp.npz', Ha=Ha, Hb=Hb, Ta=Ta, Tb=Tb, La=La, Lb=Lb,
             groups=np.array([p['group'] for p in pairs]), ids=np.array([p['id'] for p in pairs]))
    os.replace(a.out + '.tmp.npz', a.out + '.npz')
    json.dump(meta, open(a.out + '.json', 'w'), indent=1)
    print(json.dumps(meta), flush=True)
    if not ok:
        sys.exit('CANARY FAILED')


if __name__ == '__main__':
    main()
