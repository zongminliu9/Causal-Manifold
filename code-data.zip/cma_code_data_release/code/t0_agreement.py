#!/usr/bin/env python3
"""Agreement of the unsteered score from the steering pass (T0) with the extraction-time score (Ta), pooled over
all units and cells of a results root. Writes <root>/summary/t0_agreement.json. Used for the bfloat16 replication,
where the two passes use different batch compositions and so differ by rounding."""
import argparse, glob, json, os
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument('--root', default='results')
a = ap.parse_args()
d, rel = [], []
for f in sorted(glob.glob(f'{a.root}/steer/steer_*.json')):
    if f.endswith('_verify.json'):
        continue
    m = json.load(open(f)); b = m['model'].split('/')[-1]
    S = np.load(f.replace('.json', '.npz')); st = np.load(f'{a.root}/states/{b}_{m["dataset"]}.npz')
    x = np.abs(S['T0'] - st['Ta']); d.append(x)
    rel.append(float(np.median(x) / np.median(np.abs(st['Tb'] - st['Ta']))))
d = np.concatenate(d)
out = dict(n_units=int(d.size), median_abs=float(np.median(d)), q95_abs=float(np.quantile(d, .95)), max_abs=float(d.max()),
           median_rel_to_cf=float(np.median(rel)))
json.dump(out, open(f'{a.root}/summary/t0_agreement.json', 'w'), indent=1)
print(out)
