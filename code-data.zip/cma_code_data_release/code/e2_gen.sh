#!/bin/bash
# Generation check (mid and deep steering layers) for one E2 model, as in e2_stage_v2.sh's steer stage.
# usage: e2_gen.sh <hf model id> <dtype> <hub cache dir>
set -u
source $HOME/cma_rev/code_v2/sherlock/env.sh
CODE=$HOME/cma_rev/code_v2
M=$1; DT=$2; export HF_HUB_CACHE=$3; export HF_HUB_OFFLINE=1
b=$(basename $M); R=$CMA_RUN/results; DATA=$CMA_RUN/data
echo "host $(hostname) job ${SLURM_JOB_ID:-none} model $M dtype $DT"; nvidia-smi --query-gpu=name,memory.total --format=csv,noheader
fail=0
for POS in deep mid; do
  [ -f $R/gen2/gen_${b}_$POS.json ] && continue
  echo "##### $(date +%T) gen $POS"
  python3 -u $CODE/gen_check.py --model $M --data_dir $DATA --fields $R/fields/fields_${b}_advbench --out $R/gen2/gen_${b}_$POS --pos $POS --dtype $DT || { echo "FAILED gen $POS"; fail=1; }
done
echo "##### $(date +%T) DONE fail=$fail"; exit $fail
