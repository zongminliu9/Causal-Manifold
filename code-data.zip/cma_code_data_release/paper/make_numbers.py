#!/usr/bin/env python3
"""Write numbers.tex: every number quoted in the manuscripts, as LaTeX macros, computed from results/summary.

usage: make_numbers.py <results/summary dir> <out .tex> [prefix]
The manuscripts never type a result by hand; they use these macros.  Re-run after aggregate.py.
With a prefix (letters only), every macro is named \\N<prefix><name>; this is used for the replication on larger
models (prefix E) and for the pooled analysis (prefix All). Sections whose input files are absent are skipped.
"""
import json, os, sys
import numpy as np
import pandas as pd

S = sys.argv[1]
OUT = sys.argv[2]
PREFIX = sys.argv[3] if len(sys.argv) > 3 else ''
assert PREFIX.isalpha() or PREFIX == '', PREFIX
HAS = lambda f: os.path.exists(os.path.join(S, f))
J = lambda f: json.load(open(os.path.join(S, f)))
CSV = lambda f: pd.read_csv(os.path.join(S, f))
M = {}


def put(name, val):
    name = PREFIX + name
    assert name.isalpha(), name
    assert name not in M, name
    M[name] = val


def f(x, d=2):
    s = f'{x:.{d}f}'
    return s.replace('-', '$-$') if s.startswith('-') else s


def ci(d, k='rho', d_=2):
    return f'{f(d[k], d_)} [{f(d["lo"], d_)}, {f(d["hi"], d_)}]'


def pct(x, d=0):
    return f'{100 * x:.{d}f}\\%'


sm, uf, sc = J('summary.json'), J('unit_fidelity.json'), J('scan.json')
gr = J('grads.json') if HAS('grads.json') else None
ga = J('gen_audit.json') if HAS('gen_audit.json') else None
DS = ['cad', 'cities', 'larger_than', 'sp_en_trans', 'advbench']
DSNAME = dict(cad='sentiment', cities='cities', larger_than='larger-than', sp_en_trans='translation', advbench='refusal')

# P1 and field geometry
p1 = sm['P1']
put('PoneCells', f"{p1['n_cells']}")
put('PoneHits', f"{round(p1['frac_delta_p_lt_0_05'] * p1['n_cells'])}")
put('PoneFrac', pct(p1['frac_delta_p_lt_0_05'], 1))
q = p1['rho_glob_quantiles']
put('RhoMin', f(q['0.0'])); put('RhoMax', f(q['1.0'])); put('RhoMed', f(q['0.5']))
put('PtwoRho', ci(sm['P2'])); put('PtwoIdentity', f(sm['P2_identity_check']['spearman_gain_norm_vs_1_minus_sqrt_rho']))
put('PthreeLin', pct(sm['P3']['frac_linprobe_below_global'])); put('PthreeMlp', pct(sm['P3']['frac_mlpgrad_below_global']))
put('PthreeRatioLin', f(sm['P3']['median_ratio_linprobe'])); put('PthreeRatioMlp', f(sm['P3']['median_ratio_mlpgrad']))
put('PfourRho', ci(sm['P4']))
put('PfourRandomMet', f"{sm['P4_random']['n_cells_criterion_met']}"); put('PfourRandomN', f"{sm['P4_random']['n']}")
put('PfiveMlp', pct(sm['P5']['frac_mlpgrad_below_global'])); put('PfiveLin', pct(sm['P5']['frac_linprobe_below_global']))
st = CSV('steering.csv')
deep = st[(st.pos == 3) & (st.alpha == 1.0)].pivot_table(index=['model', 'dataset'], columns='arm', values='dT')
put('PfiveDeep', pct(float(((deep.mlpgrad < deep['global']) & (deep.linprobe < deep['global'])).mean())))
put('NModelsEone', f"{st.model.nunique()}"); put('NModels', f"{st.model.nunique()}")
put('TzeroCheck', f"{sm['T0_check_max']:.1e}")
dm = sm['depth_median_frac_cf_alpha1']
for k, nm in [(1, 'One'), (2, 'Two'), (3, 'Three')]:
    put(f'Depth{nm}Global', f(dm[f'{k}|global'], 3)); put(f'Depth{nm}Local', f(dm[f'{k}|local'], 3))
dd = {(r['arm'], r['alpha']): r for r in sm['deep_dose']}
AR = dict(global_='Global', local='Local', mlpgrad='Mlp', linprobe='Lin', random='Rand')
for arm, nm in [('global', 'Global'), ('local', 'Local'), ('mlpgrad', 'Mlp'), ('linprobe', 'Lin'), ('random', 'Rand')]:
    for al, an in [(0.5, 'Half'), (1.0, 'One'), (2.0, 'Two')]:
        put(f'Dose{nm}{an}', f(dd[(arm, al)]['frac_cf'])); put(f'Kl{nm}{an}', f(dd[(arm, al)]['kl_off']))
nv = sm['naive_vs_crosspair']
put('NaiveBelowFrac', pct(nv['frac_naive_below_lam1'])); put('NaiveRatioMed', f(nv['ratio_quantiles']['0.5']))
put('NaiveRatioLow', f(nv['ratio_quantiles']['0.05']))
put('XgMed', f(nv['xg_minus_rho_quantiles']['0.5'], 3)); put('XgHigh', f(nv['xg_minus_rho_quantiles']['0.95']))
put('KeightKthirtytwo', f(nv['k8_vs_k32_abs_diff_median'], 3))

fl = CSV('fields_by_layer.csv')
fl['band'] = pd.cut(fl.depth, [0, 1 / 3, 2 / 3, 1.0001], labels=['early', 'mid', 'late'])
for d in DS:
    g = fl[fl.dataset == d].groupby('band', observed=True).rho_glob.median()
    nm = ''.join(w.capitalize() for w in DSNAME[d].split('-'))
    put(f'Rho{nm}', f"{f(g['early'])} / {f(g['mid'])} / {f(g['late'])}")
sl = fl[fl.steer == True]  # noqa: E712
put('IdMed', f"{sl.mle_dim.median():.0f}"); put('IdLow', f"{sl.mle_dim.min():.0f}"); put('IdHigh', f"{sl.mle_dim.max():.0f}")
put('TanInst', f(sl.tangent_instability.median())); put('ChartNrmse', f(sl.chart_nrmse.median()))
put('TanFrac', f(sl.tangent_frac.median())); put('TanFracRand', f(sl.random_tangent_frac.median(), 3))
put('RefusalMaxRho', f(fl[fl.dataset == 'advbench'].groupby(['depth']).rho_glob.median().max()))
put('SentimentMaxRho', f(fl[fl.dataset == 'cad'].groupby(['depth']).rho_glob.median().max()))

if HAS('t0_agreement.json'):
    t0 = J('t0_agreement.json')
    put('TzeroMed', f(t0['median_abs'])); put('TzeroQ', f(t0['q95_abs'])); put('TzeroRel', pct(t0['median_rel_to_cf'], 1))

# per-unit fidelity at the steering layers (exploratory)
put('UfCells', f"{uf['n_sufficient']}"); put('UfRhoMed', f(uf['rho_glob_sufficient']['50%']))
for arm, nm in [('global', 'Global'), ('local', 'Local'), ('mlpgrad', 'Mlp'), ('linprobe', 'Lin'), ('random', 'Rand')]:
    put(f'Uf{nm}R', f(uf[f'median_r_{arm}'])); put(f'Uf{nm}Rsq', f(uf[f'median_R2cf_{arm}'], 1 if arm in ('mlpgrad', 'linprobe', 'random') else 2))
put('UfLocalBetter', f"{round(uf['frac_local_r_gt_global'] * uf['n_sufficient'])}")
put('UfdRsqRho', ci(uf['spearman_dR2_vs_rho'])); put('UfdrNaive', ci(uf['spearman_dr_vs_lam_naive']))
put('UfKlGlobal', f(uf['median_kl_off_global'])); put('UfKlLocal', f(uf['median_kl_off_local']))

# layer scan
s1 = sc['S1']
on = CSV('scan_onset.csv').dropna(subset=['d_onset'])
put('SoneMed', f(s1['median'], 3)); put('SoneMin', f(s1['min'])); put('SoneMax', f(s1['max']))
put('SoneDefined', f"{s1['n_defined']}"); put('SoneCells', f"{s1['n_cells']}")
put('SonePos', f"{int((on.d_onset > 0).sum())}"); put('SoneRhoStart', f(s1['max_rho_start']))
put('LevCells', f"{sc['n_leverage_cells']}"); put('LevRhoMed', f(sc['leverage_rho_glob']['50%'])); put('LevRhoMin', f(sc['leverage_rho_glob']['min']))
put('StwoRho', ci(sc['S2'])); put('StwoGain', f(sc['S2_median_gain'], 3))
put('SthreeRho', ci(sc['S3'])); put('SthreeNaive', ci(sc['S3_naive']))
put('SthreeFrac', pct(sc['S3_frac_local_better'])); put('SthreedRsq', f(sc['S3_median_dR2'], 3))
put('SfourdKl', f(sc['S4_median_dklo'], 3)); put('SfourKlGlobal', f(sc['S4_median_klo_global']))
sl2 = CSV('scan_layers.csv')
lev = sl2[(np.maximum(sl2.frac_global, sl2.frac_local) >= 0.5) & (~sl2.cf_ci0.astype(bool))]
assert len(lev) == sc['n_leverage_cells'], (len(lev), sc['n_leverage_cells'])
for d in DS:
    g = lev[lev.dataset == d]
    nm = ''.join(w.capitalize() for w in DSNAME[d].split('-'))
    put(f'Lev{nm}dRsq', f(g.dR2.median(), 3)); put(f'Lev{nm}Frac', pct(float((g.dR2 > 0).mean())))
    put(f'Lev{nm}N', f"{len(g)}")
    put(f'Lev{nm}Gain', f(g.gain.median(), 3)); put(f'Lev{nm}GainFrac', pct(float((g.gain > 0).mean())))
    put(f'Lev{nm}Rho', f(g.rho_glob.median()))
ref = lev[lev.dataset == 'advbench']
put('LevRefusalRsqG', f(ref.R2_global.median())); put('LevRefusalRsqL', f(ref.R2_local.median()))
put('LevRefusalGainMax', f(ref.gain.max(), 2))
mg = ref.groupby('model').gain.median()
put('LevRefusalModelsPos', f"{int((mg > 0).sum())}"); put('LevRefusalModels', f"{len(mg)}")

# readout gradients (six-model study only)
if gr is not None:
    g0 = gr['gates']
    put('GoneMax', f"{g0['G1_max']:.1e}"); put('GtwoMax', f"{g0['G2_max_rel_err']:.1e}")
    put('PsixR', f(gr['P6_median_r_first_order_global'])); put('PsixMean', ci(gr['P6_spearman_Gpred_Gobs']))
    put('PredObsPred', f(gr['median_frac_pred_vs_obs_global'][0])); put('PredObsObs', f(gr['median_frac_pred_vs_obs_global'][1]))
    put('Qshare', pct(gr['median_q_share']))
    put('PsevenRho', ci(gr['P7_spearman_dR2pred_dR2obs']))
    put('PeightRho', f(gr['P8_median_within_cell_spearman'])); put('PeightCells', f"{gr['P8_n_cells']}")
    put('PeightBelow', f"{round(gr['P8_frac_probes_below_global_cos'] * gr['P8_n_cells'])}")
    for arm, nm in [('global', 'Global'), ('local', 'Local'), ('mlpgrad', 'Mlp'), ('linprobe', 'Lin'), ('random', 'Rand')]:
        put(f'Cos{nm}', f(gr['P8_median_cos'][arm], 3 if arm in ('linprobe', 'random') else 2))
    put('AbsC', f(gr['median_abs_C'], 3)); put('AbsM', f(gr['median_abs_M'], 3))
    al = CSV('grads_alpha.csv')
    for arm, nm in [('global', 'Global'), ('mlpgrad', 'Mlp'), ('linprobe', 'Lin'), ('random', 'Rand')]:
        m = al[al.arm == arm].groupby('alpha').r.median()
        put(f'Lin{nm}', ' / '.join(f(m[a]) for a in (0.5, 1.0, 2.0)))
    m = al[al.arm == 'global'].groupby('alpha').obs_over_pred.median()
    put('ObsPredGlobal', ' / '.join(f(m[a]) for a in (0.5, 1.0, 2.0)))

# generation (fluent refusal at 3/4 depth) and the rule audit
LAB = lambda m: (m.replace('-Instruct', '').replace('-0425', '').replace('-1124', '').replace('-2501', ''))
ORDER = ['Qwen2.5-0.5B-Instruct', 'Qwen2.5-1.5B-Instruct', 'Qwen2.5-3B-Instruct', 'Qwen2.5-7B-Instruct', 'SmolLM2-1.7B-Instruct',
         'OLMo-2-0425-1B-Instruct', 'Qwen2.5-14B-Instruct', 'Qwen2.5-32B-Instruct', 'phi-4', 'Mistral-Small-24B-Instruct-2501',
         'OLMo-2-1124-13B-Instruct']
if HAS('generation_fluent.csv'):
    gf = CSV('generation_fluent.csv')
    dg = gf[gf.pos == 'deep']
    rows, rows_rule = [], []
    order_ok = order_ok_rule = 0
    present = [m for m in ORDER if m in set(dg.model)]
    for m_ in present:
        for col, out, cnt in (('fluent_refusal', rows, 'f'), ('refusal', rows_rule, 'r')):
            x = dg[dg.model == m_].set_index('cond')[col]
            v = [x['harmless_unsteered']] + [x[f'{a}|1.0'] for a in ('global', 'local', 'mlpgrad', 'linprobe', 'random')]
            out.append(LAB(m_) + ' & ' + ' & '.join(f'{y:.2f}' for y in v) + r' \\')
            ok = int(min(v[1], v[2]) > v[3] > max(v[4], v[5]) - 0.05)
            if cnt == 'f':
                order_ok += ok
            else:
                order_ok_rule += ok
    put('GenTableRows', '\n'.join(rows)); put('GenTableRowsRule', '\n'.join(rows_rule))
    put('GenOrderOk', f'{order_ok}'); put('GenOrderOkRule', f'{order_ok_rule}'); put('GenModels', f'{len(present)}')
    if ga is not None:
        put('AuditN', f"{ga['n']}"); put('AuditAgree', f"{round(ga['agreement'] * ga['n'])}")
        put('AuditRecall', f(ga['recall'])); put('AuditPrecision', f(ga['precision']))
        put('AuditDeclines', f"{ga['n_decline']}"); put('AuditCapability', f"{ga['n_capability_declines']}")
    o2 = dg[(dg.model == 'OLMo-2-0425-1B-Instruct') & (dg.cond == 'global|2.0')]
    if len(o2):
        put('OlmoTwoFluent', f(o2.iloc[0].fluent_refusal)); put('OlmoTwoRule', f(o2.iloc[0].refusal))
if 'gen_mid_rerun_n' in sm:
    put('GenRerun', f"{sm['gen_mid_rerun_n']}")

# simulations (six-model study root only)
if HAS('sims_flatness.csv'):
    fs = CSV('sims_flatness.csv').set_index(['support', 'field', 'pair_noise'])
    put('FlatAxialRho', f(fs.loc[('cyl', 'axial', 0.0)].rho_glob, 3)); put('FlatMixedRho', f(fs.loc[('cyl', 'mixed', 0.0)].rho_glob, 3))
    put('FlatMixedTrue', f(fs.loc[('cyl', 'mixed', 0.0)].rho_true, 3)); put('FlatRotRho', f(abs(fs.loc[('cyl', 'rotate', 0.0)].rho_glob), 3))
    put('FlatSlabRot', f(abs(fs.loc[('sheet', 'rotate', 0.0)].rho_glob), 3))
    put('CurvAxial', f(fs.loc[('cyl', 'axial', 0.0)].curv_along_field)); put('CurvRand', f(fs.loc[('cyl', 'axial', 0.0)].curv_random_tangent))
    put('CurvMixed', f(fs.loc[('cyl', 'mixed', 0.0)].curv_along_field)); put('CurvRot', f(fs.loc[('cyl', 'rotate', 0.0)].curv_along_field))
    sheet = fs.xs('sheet', level='support')
    put('CurvFloorLo', f(min(sheet.curv_along_field.min(), sheet.curv_random_tangent.min())))
    put('CurvFloorHi', f(max(sheet.curv_along_field.max(), sheet.curv_random_tangent.max())))
    put('FlatNoiseLam', f(fs.loc[('cyl', 'axial', 0.3)].lam1, 3)); put('FlatNoiseNaive', f(fs.loc[('cyl', 'axial', 0.3)].lam_naive))
    put('FlatRotReproG', f(fs.loc[('cyl', 'rotate', 0.0)].repro_true_global, 3)); put('FlatRotReproL', f(fs.loc[('cyl', 'rotate', 0.0)].repro_true_local))
    si = CSV('sims_indices.csv').set_index(['field', 'pair_noise'])
    put('NoiseConstNaive', f(si.loc[('constant', 1.0)].lam_naive, 3)); put('NoiseConstLam', f(si.loc[('constant', 1.0)].lam1))
    sf = CSV('sims_field.csv')
    r = sf[(sf.n == 2048) & (sf.sigma == 0.01)].iloc[0]
    put('FieldCosLocal', f(r.cos_local, 3)); put('FieldCosGlobalAbs', f(r.cos_global_abs)); put('FieldCosGlobalSigned', f(r.cos_global_signed, 3))
    put('RadiusSlope', f(CSV('sims_radius.csv').set_index('sigma').loc[0.0].slope, 3))
    ctl = CSV('sims_controls.csv').set_index('control')
    for c, nm in [('linear', 'Linear'), ('random', 'Random'), ('template_iid', 'Tiid'), ('alternating', 'Curved')]:
        put(f'Ctl{nm}G', f(ctl.loc[c].global_mean, 3)); put(f'Ctl{nm}L', f(ctl.loc[c].local_mean, 3))
    tg = CSV('sims_tangent.csv')
    for man, nm in [('circle', 'Circle'), ('torus', 'Torus')]:
        t = tg[(tg.manifold == man) & (tg.n == 2048) & (tg.sigma == 0.01)].iloc[0]
        put(f'Tan{nm}', f(t['mean'], 3))

with open(OUT + '.tmp', 'w') as fo:
    fo.write(f'% generated by make_numbers.py from {S}; do not edit\n')
    for k, v in M.items():
        fo.write(f'\\newcommand{{\\N{k}}}{{{v}}}\n')
os.replace(OUT + '.tmp', OUT)
print(len(M), 'macros ->', OUT)
