# Addendum: layer scan, fixed after the P1–P5 results and before the scan was run

Written 2026-10-30 04:32 (Marlowe time; the original file's mtime is 04:32:46). The first scan output, at 04:33:08, holds directions only (the identity check against the original directions), with no steering. **This is not a pre-registration in the original sense.** P1–P5 had
already been tested (results/summary/summary.json). What is fixed here is the design and the tests of an extra
experiment, chosen because of the P4 result. Nothing from the scan had been computed when this was written.

## Why
P4 failed (Spearman 0.02, 95% CI −0.16 to 0.21). The per-cell table shows the reason. Steering at the readout
position moves the target score by about 0% of the counterfactual at 1/4 and 1/2 depth for every arm (median
|ΔT/cf| < 0.005), and by about 95% at 3/4 depth, where ρ_glob is mostly ≥ 0.73. With three fixed layers, cells where
the field is local and cells where steering has behavioural leverage barely overlap. So P4 could not test its
question.

## Design
- Same models, datasets, states, folds, inner-CV k and estimators as before (`scan_dirs.py` reuses
  `analyze_fields.py`). At the three original steering layers the directions are identical to the ones steered
  before. This is checked.
- Every layer from 1 to n_layers − 1. Arms: global paired mean and local paired field only. α = 1 (× the median
  training-fold ‖d‖). Same readout-position hook, same score T, same off-target KL (`steer.py --alphas 1.0`).

## Tests (all reported, whatever the outcome)
- S1 (onset). For the three truth datasets, where ρ_glob starts below 0.2 in every model: per model × dataset,
  L_ρ is the first layer with ρ_glob ≥ 0.5 and L_s the first layer where the global arm reaches ΔT/cf ≥ 0.5.
  Report the median and range of (L_s − L_ρ)/n_layers over the 18 cells. Hypothesis: |median| ≤ 0.1 (behavioural
  leverage at the readout position appears where the field becomes near-constant).
- S2 (P4 restated on leverage-bearing layers). Keep layer cells where max(global, local) ΔT/cf ≥ 0.5 and the
  counterfactual's group-bootstrap CI excludes 0. Compute Spearman of (local − global) ΔT/|cf| against ρ_glob,
  with a block bootstrap over model × dataset. Hypothesis: Spearman < 0, CI excluding 0.
- S3 (per-unit). On the same cells, Spearman of (local − global) per-unit R² (as in `explore_unitfidelity.py`)
  against ρ_glob. Hypothesis: < 0, CI excluding 0. Also against the naive λ_max(E uuᵀ), which is reported as a
  competitor whatever the result.
- S4 (cost). Median off-target KL, local minus global, on the S2 cells.

## Falsifiers
S2 and S3 with CIs including 0 mean that, at the readout position, these models give no behavioural evidence that
the local field pays where the paired field is less constant. S1 with |median| > 0.1 means the leverage onset and
the field's collapse to a constant are separate events.
