# CMA revision: analysis plan fixed before the language-model results

Written 2026-10-30 00:00 (Marlowe time). At that point the only language-model output anyone had seen was the
field-level dev run on Qwen2.5-0.5B-Instruct / cities, used to debug `analyze_fields.py`. No steering or
generation result and no other model-dataset cell had been computed. Code: `code/`. Authoritative copy of
the results: `marlowe:<project scratch>/cma_rev/results/`.

## Design (fixed)
- Models: Qwen2.5-Instruct 0.5B / 1.5B / 3B / 7B, SmolLM2-1.7B-Instruct, OLMo-2-0425-1B-Instruct, all float32.
- Paired counterfactuals: CAD sentiment (human minimal edits, 2,440 pairs); truth (cities 748, larger_than 990,
  sp_en_trans 174, Marks & Tegmark); refusal (AdvBench requests and harmless minimal rewrites by Qwen2.5-7B,
  filtered by word overlap ≥ 0.4 and a harmfulness judgement).
- State: the residual stream leaving block L−1 at the readout position (last prompt token, assistant turn start).
  Paired displacement d_i = H_L(b_i) − H_L(a_i).
- Folds: 5 group-disjoint folds. Groups are near-duplicate families (TF-IDF cosine ≥ 0.5), merged with natural
  families: country for cities, the smaller operand's decade for larger_than, the Spanish word for sp_en_trans.
  The local field's k is chosen by inner group-disjoint CV inside each training fold.
- Steering layers are fixed in advance at relative depth 1/4, 1/2, 3/4. Strengths are α ∈ {0.5, 1, 2} times the
  median training-fold ‖d‖. Arms: global paired mean, local paired field, linear-probe direction, MLP-probe
  gradient (steering-vector-field style), and a random direction orthogonal to global.
- Field-level score: the cross-fitted ⟨ĉ_i, d_i⟩, which is unbiased for ⟨ĉ_i, V(h_i)⟩.
  Behaviour-level score: ΔT = T(steered a_i) − T(a_i), compared with the counterfactual T(b_i) − T(a_i).

## Predictions
- P1. The noise-robust regime index ρ_glob varies across layers and behaviours. The excess neighbour coherence
  Δ = u_knn − u_all is positive (permutation p < 0.05) in most cells.
- P2. Across cells (model × dataset × layer), the local-minus-global held-out field gain, normalised by
  √u_knn, falls as ρ_glob rises (Spearman < 0, 95% bootstrap CI excluding 0).
- P3. Probe directions (linear probe and MLP-probe gradient) reproduce the paired field worse than the global
  paired mean in at least 80% of steering cells.
- P4. At α = 1, the local-minus-global behavioural gain, normalised by the counterfactual effect, falls as ρ_glob
  rises (Spearman < 0). The random arm's ΔT has 95% CI including 0, or is at least 10× smaller than global's.
- P5. Probe-gradient steering moves T less than the paired global direction in most cells.

## Falsifiers
- P2 or P4 failing (Spearman ≥ 0, or CI including 0) means the regime index does not predict where locality
  pays, on fields or on behaviour respectively. That result would be reported as such.
- P3/P5 failing means the identification boundary between predictive and causal geometry has no practical
  bite in these models.

## Not decided in advance (exploratory)
- Support diagnostics: MLE intrinsic dimension, tangent stability, chart transitions, tangent fraction of the field.
- The generation check (refusal substring rule): 100 harmless prompts, middle steering layer only.
