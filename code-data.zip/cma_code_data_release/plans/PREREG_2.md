# Pre-registration 2: readout-gradient tests of the first-order decomposition (P6–P8)

Written 2026-10-30, before any readout gradient had been computed. Already seen at this point: P1–P5, the per-unit
fidelity analysis, the layer scan (S1–S4) and the generation runs (RESULTS.md). The hypotheses below come from
Prop D (THEORY.md), which was derived after those results. They are confirmatory tests of that proposition on a
quantity (the readout gradient) that none of the earlier analyses used.

## Quantities
- g_i^L = ∂T/∂h_L at the readout position for prompt a_i (the same position, layer convention and score T as the
  steering runs). Computed by `code/grads.py` on Sherlock (fp32, the same models).
- Steering vector actually applied: s_i^{arm} = α ν_{f(i)} u_i^{arm} (α = 1; u from the fields or scan direction files).
- First-order prediction p_i^{arm} = ⟨g_i^L, s_i^{arm}⟩. Observed ΔT_i^{arm} = T(steered a_i) − T(a_i).
- First-order counterfactual q_i = ⟨g_i^L, d_i⟩ with d_i = H_L(b_i) − H_L(a_i) (paired displacement).
- Leverage cells, as in S2: layer cells of the scan with max(global, local) ΔT/cf ≥ 0.5 and cf CI excluding 0.
- Decomposition of the predicted mean gap, normalised by |cf|:
  Ĝ = mean_i(p_i^local − p_i^global)/|cf| = M + C, where M = ⟨ḡ, s̄^local − s^global⟩/|cf| (mean-orientation term)
  and C = mean_i⟨g_i − ḡ, s_i^local − s̄^local⟩/|cf| (readout–field covariance term).

## Gates (they must pass before any test is read)
- G1 parity: T recomputed on Sherlock matches the Marlowe extraction T_a to max |ΔT| ≤ 5e-3 in every cell.
- G2 gradient check: for 4 prompts × 3 layers per cell, a central finite difference along v = unit(g/‖g‖ + r)
  (r a random unit vector) with step ε = 0.05/‖g‖ matches ε⟨g, v⟩ to relative error ≤ 5%.
  (Amended 2026-10-30, before anything was computed: the first version used ε = 1e-2·ν along a purely random
  direction, which puts the expected signal near float32 noise in the early layers.)

## Hypotheses
- P6 (first order holds where steering works). On leverage cells, the median within-cell Pearson r(p_i^global,
  ΔT_i^global) ≥ 0.5, and the observed mean gap G = mean(ΔT^local − ΔT^global)/|cf| is tracked by Ĝ: Spearman(Ĝ, G)
  > 0 with a 95% block-bootstrap CI (blocks = model × dataset) excluding 0.
- P7 (per-unit gain is first-order). On leverage cells, the first-order per-unit gain
  ΔR̂² = R²(p^local vs cf) − R²(p^global vs cf) correlates with the observed ΔR²: Spearman > 0, CI excluding 0.
- P8 (why probes fail). At the three original steering layers, on the cells where steering reaches ≥ 50% of cf, the
  first-order mean predictions p̄^{arm} rank the five arms as the observed mean effects do (median within-cell Spearman
  over arms ≥ 0.8). Also, |cos(ḡ, linear-probe direction)| and |cos(ḡ, MLP-gradient direction)| are below
  cos(ḡ, m̂) in ≥ 80% of those cells.

## Reported whatever happens
Median |C| and |M| on leverage cells (Prop D predicts that small C is why P4 and S2 are null), the share of the
counterfactual captured to first order (mean q_i / mean cf), and every gate value.

## Falsifiers
P6 failing means the behavioural results are not first-order, so Prop D cannot be the explanation. P7 failing means
the per-unit gain has some other source. P8 failing means probe directions do not fail through misalignment with the
readout gradient.
