# Pre-registration E2: replication on five larger models (no new hypotheses)

Written 2026-10-30 19:25 (original file mtime 19:25:15, md5 b99cc22f…; this edit only corrects the stated time), before any E2 steering, scan or generation result existed (the Sherlock steer directory was empty at 19:25:17). Already seen at this
point: the E2 Qwen-14B extraction summaries (canary, mean T per dataset) and the progress lines of its field analysis
for the first eight layers of its first dataset (ρ_glob, λ₁, naive index, held-out reproduction scores). No other E2 output.

## Models
Qwen2.5-14B-Instruct, Qwen2.5-32B-Instruct, microsoft/phi-4, Mistral-Small-24B-Instruct-2501 and
OLMo-2-1124-13B-Instruct (if its download completes). bfloat16, because the original float32 does not fit the free GPUs.
24B and 32B are split over two GPUs (device_map auto). Revisions are pinned in STATUS.md. The data, folds, estimators,
steering layers (¼, ½, ¾), α grid, arms, layer scan and generation check are unchanged (code_v2 differs from the
Marlowe code only in the --dtype/--device options, the bf16 verify tolerance of 5e-2 and the offline snapshot loader).

## Tests
Identical to PREREG.md (P1–P5), PREREG_ADDENDUM.md (S1–S4) and the generation analysis in RESULTS.md, with the same
thresholds. They are reported three ways: E2 alone, the original six models alone (unchanged), and all models pooled
(block bootstrap over model × dataset). P6–P8 (PREREG_2.md) stay confirmatory on the original six float32 models only.
Readout gradients for E2 models, if computed, are exploratory.

## What would count against generality
If the E2 models do not reproduce the main pattern (behavioural leverage only at late depth; ρ_glob ≥ 0.7 where steering
works; global ≈ local on the mean; probes well below the paired mean at matched norm), the paper states that the pattern
is limited to ≤ 7B or to float32, whichever the evidence supports.

## Amendment A1 (2026-10-31, written before any E2 steering or scan effect was computed or inspected)
The pre-registered bfloat16 verify gate (tolerance 5e-2 on the maximum absolute log-probability difference over the
whole vocabulary) failed in all four finished E2 models: the cached single-token path of steer.py and a full forward
differ by 0.2–1.0 in some vocabulary entries, with or without the hook, because bfloat16 kernels reduce in a different
order for different input shapes. phi-4 cities passed (0.0) and produced one steering file; its contents have not been
read. The generation step (gen_check.py, which does not use this shortcut) completed; the last three progress lines of
each model's generation log (MLP-gradient and random arms) were seen while reading the failure logs. Nothing else.

Change: for E2 only, steering and the layer scan use `steer.py --nocache`, i.e. every (layer, arm, α) is a full
forward of the batch with the last-position hook, and the unsteered score T0 is a full forward of the same batch. This is
the quantity the shortcut was meant to reproduce, so no approximation remains. The verify gate keeps tolerance 5e-2 and
now requires (i) the layer-index check to be exactly 0, (ii) the hook with no vector to leave the output unchanged,
(iii) two repeated full forwards to agree, (iv) a steering effect > 1e-2 at every steering layer (some layer for the
scan). Outputs go to results/steer_nc and results/scan_nc; the failed outputs stay in results/steer and results/scan
for the record. All tests, thresholds and the reporting plan above are unchanged. The E2 generation results are used as
they are.
