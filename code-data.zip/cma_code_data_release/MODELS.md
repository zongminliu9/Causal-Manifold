| model | revision |
|---|---|
| Qwen/Qwen2.5-0.5B-Instruct | 7ae557604adf67be50417f59c2c2f167def9a775 |
| Qwen/Qwen2.5-1.5B-Instruct | 989aa7980e4cf806f80c7fef2b1adb7bc71aa306 |
| Qwen/Qwen2.5-3B-Instruct | aa8e72537993ba99e69dfaafa59ed015b17504d1 |
| Qwen/Qwen2.5-7B-Instruct | a09a35458c702b33eeacc393d103063234e8bc28 |
| HuggingFaceTB/SmolLM2-1.7B-Instruct | 31b70e2e869a7173562077fd711b654946d38674 |
| allenai/OLMo-2-0425-1B-Instruct | 48d788eca847d4d7548f375ad03d3c9312f6139e |
| Qwen/Qwen2.5-14B-Instruct | cf98f3b3bbb457ad9e2bb7baf9a0125b6b88caa8 |
| Qwen/Qwen2.5-32B-Instruct | 5ede1c97bbab6ce5cda5812749b4c0bdf79b18dd |
| microsoft/phi-4 | 2db69c1c3e91a05d2c64a3185acfbaf36f744e25 |
| mistralai/Mistral-Small-24B-Instruct-2501 | 9527884be6e5616bdd54de542f9ae13384489724 |
| allenai/OLMo-2-1124-13B-Instruct | 3a5c85baefbb1896a54d56fe2e76c0395627ddf4 |
