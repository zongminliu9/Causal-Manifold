#!/bin/bash
# Full pipeline for one model on one GPU: extraction, field analysis, steering (with verification), layer scan
# and generation. usage: run_model.sh <hf model id> [float32|bfloat16]
# Environment: CMA_ROOT (directory holding data/ and results/), PY (python with torch, transformers, numpy, scipy,
# pandas), HF_HOME (Hugging Face cache holding the pinned revisions in MODELS.md).
set -eu
M=$1; DT=${2:-float32}; C=$(dirname "$0")/code
: "${CMA_ROOT:?set CMA_ROOT}"; PY=${PY:-python3}
b=$(basename "$M"); R=$CMA_ROOT/results; D=$CMA_ROOT/data
mkdir -p $R/states $R/fields $R/steer $R/scan $R/gen2
NC=""; [ "$DT" = bfloat16 ] && NC=--nocache
for DS in cities larger_than sp_en_trans cad advbench; do
  [ -f $R/states/${b}_$DS.json ] || $PY $C/extract.py --model $M --dataset $DS --data_dir $D --out $R/states/${b}_$DS --dtype $DT
  [ -f $R/fields/fields_${b}_$DS.json ] || $PY $C/analyze_fields.py --states $R/states/${b}_$DS --out $R/fields/fields_${b}_$DS
  [ -f $R/scan/scan_${b}_$DS.json ] || $PY $C/scan_dirs.py --states $R/states/${b}_$DS --out $R/scan/scan_${b}_$DS
  F=$R/fields/fields_${b}_$DS; P=$R/scan/scan_${b}_$DS
  $PY $C/steer.py --model $M --dataset $DS --data_dir $D --fields $F --out $R/steer/steer_${b}_$DS --verify --dtype $DT $NC
  $PY $C/steer.py --model $M --dataset $DS --data_dir $D --fields $F --out $R/steer/steer_${b}_$DS --dtype $DT $NC
  $PY $C/steer.py --model $M --dataset $DS --data_dir $D --fields $P --out $R/scan/steer_${b}_$DS --verify --effect_any --alphas 1.0 --dtype $DT $NC
  $PY $C/steer.py --model $M --dataset $DS --data_dir $D --fields $P --out $R/scan/steer_${b}_$DS --alphas 1.0 --dtype $DT $NC
done
for POS in mid deep; do
  $PY $C/gen_check.py --model $M --data_dir $D --fields $R/fields/fields_${b}_advbench --out $R/gen2/gen_${b}_$POS --pos $POS --dtype $DT
done
